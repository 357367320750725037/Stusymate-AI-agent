import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json());

// API Health Check
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    product: 'ZAHIDA AI',
    company: 'ZAHIDA DIGITAL MARKETING',
    version: '1.0.0-phase1',
    hasGeminiKey: Boolean(process.env.GEMINI_API_KEY),
  });
});

// Server-side AI orchestration endpoint using @google/genai
app.post('/api/ai/orchestrate', async (req: Request, res: Response) => {
  const { prompt, agent = 'ZAI', clientContext, systemDirective } = req.body;

  if (!prompt || typeof prompt !== 'string') {
    return res.status(400).json({ error: 'Valid prompt is required.' });
  }

  const apiKey = process.env.GEMINI_API_KEY;

  if (!apiKey) {
    return res.json({
      success: true,
      mode: 'simulated_local',
      agent,
      message:
        'Live Gemini API key is not configured in this environment. Running in built-in agency intelligence mode.',
      content: generateFallbackResponse(agent, prompt, clientContext),
    });
  }

  try {
    const ai = new GoogleGenAI();
    const systemInstruction = `You are ZAI (ZAHIDA AI), Chief Marketing Intelligence Agent and digital marketing partner for Zahida Khan, owner of ZAHIDA DIGITAL MARKETING.
Brand: ZAHIDA AI by Zahida Digital Marketing.
Your personality is smart, strategic, confident, helpful, professional, proactive, honest, business-focused, and never unnecessarily robotic. You communicate naturally with Zahida.
Agent role for this task: ${agent}.
${clientContext ? `Client Context Memory: ${JSON.stringify(clientContext)}` : ''}
${systemDirective || ''}
Rule: Never pretend you executed an external action (like publishing an ad or sending an email) if it requires an external integration. Propose drafts and request approvals. Keep information prioritized and actionable.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    const reply = response.text || 'I have analyzed the request and prepared the strategy.';

    return res.json({
      success: true,
      mode: 'live_gemini',
      agent,
      content: reply,
    });
  } catch (error: any) {
    console.error('Gemini API execution error:', error);
    return res.json({
      success: true,
      mode: 'fallback_error',
      agent,
      error: error.message || 'Error communicating with AI model',
      content: generateFallbackResponse(agent, prompt, clientContext),
    });
  }
});

function generateFallbackResponse(agent: string, prompt: string, clientContext?: any): string {
  const clientName = clientContext?.name || 'your client';

  if (prompt.toLowerCase().includes('priority') || prompt.toLowerCase().includes('important') || prompt.toLowerCase().includes('aaj')) {
    return `Good morning Zahida. Here are the top 5 operational priorities today:

1. **Lumina Skin Co**: Meta Ads CPA increased by 28% over the last 48 hours. Recommend rotating in 3 user-generated creative hooks.
2. **Monthly Retainer Reports**: Apex Fintech and Solstice Health monthly deliverables are due for review.
3. **High-Value Lead Pipeline**: 4 hot leads (estimated $18,500 MRR potential) await follow-up audit proposals.
4. **Content Approvals**: 6 social and ad creative briefs are pending your executive sign-off in the Approval Center.
5. **Scaling Opportunity**: Nordic Roastery Google Search campaign is maintaining a 5.2x ROAS with budget headroom to scale spend by 25%.`;
  }

  if (agent === 'Strategy Agent' || prompt.toLowerCase().includes('strategy')) {
    return `### Strategic Marketing Blueprint for ${clientName}

**1. Executive Objective**:
Accelerate qualified customer acquisition while maintaining a target blended ROAS of $\\ge 3.8\\times$.

**2. Core Positioning & Angle**:
Differentiate on premium artisanal quality and proven customer outcomes, moving away from commoditized price discounts.

**3. Multichannel Funnel**:
- **Top of Funnel (60% Budget)**: High-retention short-form video hooks on Meta Ads and TikTok focusing on authentic problem-solution framing.
- **Middle of Funnel (25% Budget)**: Retargeting social viewers with customer testimonials, comparison guides, and press validation.
- **Bottom of Funnel (15% Budget)**: High-intent Google Search capture for branded and high-intent commercial keywords.

**4. 30-Day Key Milestones**:
- Milestone 1: Creative testing phase (deploy 6 creative variations across 2 distinct angles).
- Milestone 2: Landing page conversion rate optimization (target bounce rate $< 42\\%$).
- Milestone 3: Scale winner creative variations with 20% budget expansion increments.`;
  }

  if (agent === 'Content Agent' || prompt.toLowerCase().includes('content') || prompt.toLowerCase().includes('caption')) {
    return `### AI Content Studio Brief for ${clientName}

**Hook Option 1**: "The biggest mistake brands make with digital marketing in 2026? Focusing on volume instead of retention."
**Hook Option 2**: "Here is the exact framework we used to scale customer acquisition by 180% without doubling ad spend."

**Body**:
Most teams burn their marketing budget driving traffic to pages that don't convert, with messaging that sounds like everyone else.
True growth comes from three pillars:
1. Sharp customer positioning that calls out your exact buyer.
2. High-converting creative assets that speak to friction points.
3. Rapid testing cycles to double down on winning hooks.

**Call to Action (CTA)**: "Book a complimentary 15-minute growth audit with Zahida Digital Marketing. Link in bio."
**Recommended Visual**: Clean high-contrast carousel with minimal editorial typography and real case study metrics.`;
  }

  return `I have reviewed your request regarding "${prompt}" for ${clientName}. 

The data indicates steady progress across your agency operations. All client memory parameters, campaign guidelines, and safety policies are active. Would you like me to generate a complete workflow draft or push action items to your Approval Center?`;
}

// Development with Vite vs Production static serving
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`ZAHIDA AI server listening on port ${port} (mode: ${isProd ? 'production' : 'development'})`);
  });
}

startServer();
