import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  NavView,
  Client,
  Lead,
  Campaign,
  ContentItem,
  Task,
  ApprovalItem,
  TeamMember,
  KnowledgeDocument,
  DailyBriefing,
  AgentLog,
  MarketingAutomation,
  CompetitorResearchReport,
  MarketingStrategy,
  ReportItem,
} from '../types';
import {
  INITIAL_CLIENTS,
  INITIAL_LEADS,
  INITIAL_CAMPAIGNS,
  INITIAL_APPROVALS,
  INITIAL_CONTENT_ITEMS,
  INITIAL_TASKS,
  INITIAL_TEAM,
  INITIAL_KNOWLEDGE_DOCS,
  INITIAL_BRIEFING,
  INITIAL_STRATEGIES,
  INITIAL_REPORTS,
} from '../data/initialData';

export interface ChatMessage {
  id: string;
  sender: 'zahida' | 'zai';
  agentName?: string;
  text: string;
  timestamp: string;
  suggestedActions?: string[];
  toolsCalled?: string[];
  executionMode?: 'live_gemini' | 'simulated_local' | 'fallback_error';
}

interface AgencyContextType {
  currentView: NavView;
  setCurrentView: (view: NavView) => void;
  selectedClientId: string | null;
  setSelectedClientId: (id: string | null) => void;

  // Data collections
  clients: Client[];
  leads: Lead[];
  campaigns: Campaign[];
  strategies: MarketingStrategy[];
  reports: ReportItem[];
  approvals: ApprovalItem[];
  contentItems: ContentItem[];
  tasks: Task[];
  teamMembers: TeamMember[];
  knowledgeDocs: KnowledgeDocument[];
  dailyBriefing: DailyBriefing;
  agentLogs: AgentLog[];
  isDemoMode: boolean;
  setIsDemoMode: (val: boolean) => void;
  automations: MarketingAutomation[];
  toggleAutomation: (id: string) => void;
  competitorReports: CompetitorResearchReport[];
  addCompetitorReport: (report: Omit<CompetitorResearchReport, 'id' | 'analysisDate'>) => void;
  exportBackup: () => void;
  clearAllDataToFreshSlate: () => void;

  // Modals & Panels
  isCommandPaletteOpen: boolean;
  setIsCommandPaletteOpen: (open: boolean) => void;
  isAskZaiOpen: boolean;
  setIsAskZaiOpen: (open: boolean) => void;
  quickModalType: 'client' | 'campaign' | 'lead' | 'task' | 'content' | null;
  setQuickModalType: (type: 'client' | 'campaign' | 'lead' | 'task' | 'content' | null) => void;
  selectedClientDetail: Client | null;
  setSelectedClientDetail: (client: Client | null) => void;

  // Actions
  addClient: (client: Omit<Client, 'id' | 'healthScore' | 'blendedRoas' | 'activeCampaignsCount' | 'joinedDate'>) => void;
  updateClientMemory: (clientId: string, updatedMemory: Partial<Client['memory']>) => void;
  addLead: (lead: Omit<Lead, 'id' | 'score' | 'scoreTier' | 'scoreExplanation' | 'lastContactDate'>) => void;
  updateLeadStatus: (leadId: string, status: Lead['status']) => void;
  addCampaign: (campaign: Omit<Campaign, 'id' | 'spentCurrentMonth' | 'impressions' | 'clicks' | 'ctr' | 'cpc' | 'cpa' | 'conversions' | 'revenueGenerated' | 'roas' | 'health'>) => void;
  toggleCampaignStatus: (campaignId: string) => void;
  updateCampaignBudget: (campaignId: string, newBudget: number) => void;
  addStrategy: (strategy: Omit<MarketingStrategy, 'id' | 'createdAt' | 'lastUpdated'>) => void;
  updateStrategyStage: (id: string, stage: MarketingStrategy['stage']) => void;
  addReport: (report: Omit<ReportItem, 'id' | 'dateGenerated'>) => void;
  convertMilestoneToTasks: (strategyId: string, phaseTitle: string) => void;
  addContentItem: (item: Omit<ContentItem, 'id' | 'status' | 'approvalStatus'>) => void;
  updateContentStatus: (id: string, status: ContentItem['status']) => void;
  addTask: (task: Omit<Task, 'id'>) => void;
  toggleTaskStatus: (taskId: string) => void;
  deleteTask: (taskId: string) => void;
  handleApproval: (id: string, decision: 'APPROVE' | 'REJECT', decisionNote?: string) => void;
  addKnowledgeDoc: (doc: Omit<KnowledgeDocument, 'id' | 'lastUpdated'>) => void;

  // AI Chat & Execution
  chatMessages: ChatMessage[];
  isAiThinking: boolean;
  sendAiMessage: (prompt: string, specificAgent?: string, targetClientId?: string) => Promise<void>;
  clearChat: () => void;
}

const AgencyContext = createContext<AgencyContextType | undefined>(undefined);

function mergeWithInitial<T extends { id: string }>(savedJson: string | null, initialItems: T[]): T[] {
  if (!savedJson) return initialItems;
  try {
    const parsed: T[] = JSON.parse(savedJson);
    const savedIds = new Set(parsed.map((item) => item.id));
    const newItems = initialItems.filter((item) => !savedIds.has(item.id));
    return [...parsed, ...newItems];
  } catch {
    return initialItems;
  }
}

export const AgencyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentView, setCurrentView] = useState<NavView>('Dashboard');
  const [selectedClientId, setSelectedClientId] = useState<string | null>(null);

  const [clients, setClients] = useState<Client[]>(() => {
    return mergeWithInitial(localStorage.getItem('zai_clients'), INITIAL_CLIENTS);
  });

  const [leads, setLeads] = useState<Lead[]>(() => {
    return mergeWithInitial(localStorage.getItem('zai_leads'), INITIAL_LEADS);
  });

  const [campaigns, setCampaigns] = useState<Campaign[]>(() => {
    return mergeWithInitial(localStorage.getItem('zai_campaigns'), INITIAL_CAMPAIGNS);
  });

  const [strategies, setStrategies] = useState<MarketingStrategy[]>(() => {
    return mergeWithInitial(localStorage.getItem('zai_strategies'), INITIAL_STRATEGIES);
  });

  const [reports, setReports] = useState<ReportItem[]>(() => {
    return mergeWithInitial(localStorage.getItem('zai_reports'), INITIAL_REPORTS);
  });

  const [approvals, setApprovals] = useState<ApprovalItem[]>(() => {
    return mergeWithInitial(localStorage.getItem('zai_approvals'), INITIAL_APPROVALS);
  });

  const [contentItems, setContentItems] = useState<ContentItem[]>(() => {
    return mergeWithInitial(localStorage.getItem('zai_content_items'), INITIAL_CONTENT_ITEMS);
  });

  const [tasks, setTasks] = useState<Task[]>(() => {
    return mergeWithInitial(localStorage.getItem('zai_tasks'), INITIAL_TASKS);
  });

  const [teamMembers] = useState<TeamMember[]>(INITIAL_TEAM);
  const [knowledgeDocs, setKnowledgeDocs] = useState<KnowledgeDocument[]>(() => {
    return mergeWithInitial(localStorage.getItem('zai_knowledge_docs'), INITIAL_KNOWLEDGE_DOCS);
  });
  const [dailyBriefing] = useState<DailyBriefing>(INITIAL_BRIEFING);

  const [agentLogs, setAgentLogs] = useState<AgentLog[]>([
    {
      id: 'log-1',
      timestamp: '08:30 AM',
      agent: 'Ads Agent',
      action: 'Detected 28% CPA increase on Lumina Skin Co',
      details: 'Evaluated 48-hr frequency metrics. Dispatched rotation proposal to Approval Center.',
      requiresHumanReview: true,
    },
    {
      id: 'log-2',
      timestamp: '07:45 AM',
      agent: 'Strategy Agent',
      action: 'Identified scaling opportunity for Nordic Roastery',
      details: '5.2x ROAS maintained across 315 conversions. Generated +$45/day budget scaling proposal.',
      requiresHumanReview: true,
    },
    {
      id: 'log-3',
      timestamp: '04:00 AM',
      agent: 'Research Agent',
      action: 'Automated SERP competitor rank monitoring completed',
      details: '45 target keywords crawled. 12 positive SERP shifts recorded under Green Autonomous Tier.',
      requiresHumanReview: false,
    },
  ]);

  const [isDemoMode, setIsDemoMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('zai_is_demo_mode');
    return saved !== null ? JSON.parse(saved) : true;
  });

  const [automations, setAutomations] = useState<MarketingAutomation[]>([
    {
      id: 'auto-1',
      name: 'Daily Morning Executive Briefing Synthesizer',
      trigger: 'Every morning at 08:00 AM',
      action: 'Scan client campaigns for CPA anomalies, summarize approvals, and generate top 5 priorities',
      status: 'Active',
      lastRun: 'Today, 08:00 AM',
      executionCount: 28,
    },
    {
      id: 'auto-2',
      name: 'Creative Ad Fatigue Sentinel (Meta & Google)',
      trigger: 'Continuous metric sync (every 6 hours)',
      action: 'Flag ad sets with frequency > 3.2 and CPA rise > 20%; generate rotation proposal in Approval Center',
      status: 'Active',
      lastRun: 'Today, 06:00 AM',
      executionCount: 64,
    },
    {
      id: 'auto-3',
      name: 'Weekly Client Content Calendar Drafter',
      trigger: 'Every Friday at 04:00 PM',
      action: 'Formulate next week editorial drafts based on client memory and push to Review state',
      status: 'Active',
      lastRun: 'Oct 02, 2026',
      executionCount: 12,
    },
    {
      id: 'auto-4',
      name: 'High-Value Inbound Lead Nurture Reminder',
      trigger: 'When lead status remains in "Qualified" > 48 hours',
      action: 'Generate custom proposal draft and send alert to Zahida Khan',
      status: 'Active',
      lastRun: 'Yesterday, 02:15 PM',
      executionCount: 19,
    },
    {
      id: 'auto-5',
      name: 'End-of-Month Executive Client Reporting Generator',
      trigger: 'Final business day of each month',
      action: 'Synthesize 5-question AI executive summary and compile attribution metrics deck',
      status: 'Active',
      lastRun: 'Sep 30, 2026',
      executionCount: 6,
    },
  ]);

  const [competitorReports, setCompetitorReports] = useState<CompetitorResearchReport[]>([
    {
      id: 'comp-1',
      competitorName: 'True Botanicals',
      websiteUrl: 'https://truebotanicals.com',
      analysisDate: '2026-10-08',
      positioningSummary: 'Positioned as pure luxury biocompatible botanicals with celebrity endorsements and MADE SAFE certification.',
      coreOffers: ['Chebula Active Serum ($90)', 'Pure Radiance Oil ($110)', 'Subscribe & Save 15%'],
      contentGaps: ['Clinical barrier dermatological testing metrics', 'Educational breakdown of ceramides vs natural oils', 'UGC before/after transparency'],
      swotAnalysis: {
        strengths: ['Strong celebrity brand equity', 'High organic search authority on clean beauty'],
        weaknesses: ['Premium price barrier ($90-$120)', 'Slow creative refresh on Meta Ads'],
        opportunities: ['Capture price-conscious luxury consumers with Lumina 28-day repair proof'],
        threats: ['Aggressive influencer spending on TikTok Shop'],
      },
      recommendedDifferentiators: [
        'Highlight Lumina clinically proven 28-day barrier matrix at a 30% more accessible price point',
        'Lead with scientific dermatologist endorsement rather than celebrity glamour',
      ],
      sourcesDisclosed: ['Public website meta tags', 'Meta Ad Library public listings', 'Google Search organic snippets'],
    },
  ]);

  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);
  const [isAskZaiOpen, setIsAskZaiOpen] = useState(false);
  const [quickModalType, setQuickModalType] = useState<'client' | 'campaign' | 'lead' | 'task' | 'content' | null>(null);
  const [selectedClientDetail, setSelectedClientDetail] = useState<Client | null>(null);

  // Initial chat history
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-init-1',
      sender: 'zai',
      agentName: 'ZAI — Chief Marketing Intelligence',
      text: `Good morning Zahida. I have completed the morning intelligence scan for Zahida Digital Marketing.

Here is what needs your strategic focus right now:
1. **Lumina Skin Co**: CPA increased 28% to $34.20 over the last 48 hours due to ad fatigue. 3 dermatologist-approved UGC cuts are queued in the Approval Center.
2. **Nordic Roastery**: Sustained 5.2x ROAS with budget headroom to scale spend by +15%.
3. **High-Value Leads**: 4 hot inbound prospects ($18,500 MRR total pipeline) are awaiting audit proposals.
4. **Approval Center**: 5 actions are pending your sign-off (3 yellow tier, 1 red tier safety hold).

How would you like to proceed?`,
      timestamp: '09:00 AM',
      suggestedActions: [
        'Review Lumina Skin Co creatives',
        'Approve Nordic budget scaling',
        'Show hot leads needing proposal',
        'Open Approval Center',
      ],
      executionMode: 'simulated_local',
    },
  ]);

  const [isAiThinking, setIsAiThinking] = useState(false);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('zai_clients', JSON.stringify(clients));
  }, [clients]);
  useEffect(() => {
    localStorage.setItem('zai_leads', JSON.stringify(leads));
  }, [leads]);
  useEffect(() => {
    localStorage.setItem('zai_campaigns', JSON.stringify(campaigns));
  }, [campaigns]);
  useEffect(() => {
    localStorage.setItem('zai_strategies', JSON.stringify(strategies));
  }, [strategies]);
  useEffect(() => {
    localStorage.setItem('zai_reports', JSON.stringify(reports));
  }, [reports]);
  useEffect(() => {
    localStorage.setItem('zai_approvals', JSON.stringify(approvals));
  }, [approvals]);
  useEffect(() => {
    localStorage.setItem('zai_content_items', JSON.stringify(contentItems));
  }, [contentItems]);
  useEffect(() => {
    localStorage.setItem('zai_tasks', JSON.stringify(tasks));
  }, [tasks]);
  useEffect(() => {
    localStorage.setItem('zai_knowledge_docs', JSON.stringify(knowledgeDocs));
  }, [knowledgeDocs]);

  // Keyboard shortcut for Cmd+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsCommandPaletteOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Action methods
  const addClient = (newClientData: Omit<Client, 'id' | 'healthScore' | 'blendedRoas' | 'activeCampaignsCount' | 'joinedDate'>) => {
    const newClient: Client = {
      ...newClientData,
      id: `cli-${Date.now().toString().slice(-4)}`,
      healthScore: 85,
      blendedRoas: 3.5,
      activeCampaignsCount: 0,
      joinedDate: new Date().toISOString().split('T')[0],
    };
    setClients((prev) => [newClient, ...prev]);
  };

  const updateClientMemory = (clientId: string, updatedMemory: Partial<Client['memory']>) => {
    setClients((prev) =>
      prev.map((c) => (c.id === clientId ? { ...c, memory: { ...c.memory, ...updatedMemory } } : c))
    );
  };

  const addLead = (leadData: Omit<Lead, 'id' | 'score' | 'scoreTier' | 'scoreExplanation' | 'lastContactDate'>) => {
    const est = leadData.budgetEst || 3000;
    const score = est >= 10000 ? 92 : est >= 5000 ? 76 : 48;
    const scoreTier = score >= 80 ? 'HOT' : score >= 60 ? 'WARM' : 'COLD';
    const scoreExplanation =
      scoreTier === 'HOT'
        ? `High contract value potential ($${est}/mo), active inbound request, clear service alignment.`
        : scoreTier === 'WARM'
        ? `Moderate budget tier ($${est}/mo) with good conversion potential.`
        : `Early stage or lower initial spend allocation. Requires educational nurturing.`;

    const newLead: Lead = {
      ...leadData,
      id: `lead-${Date.now().toString().slice(-4)}`,
      score,
      scoreTier,
      scoreExplanation,
      lastContactDate: new Date().toISOString().split('T')[0],
    };
    setLeads((prev) => [newLead, ...prev]);
  };

  const updateLeadStatus = (leadId: string, status: Lead['status']) => {
    setLeads((prev) => prev.map((l) => (l.id === leadId ? { ...l, status } : l)));
  };

  const addCampaign = (cmpData: Omit<Campaign, 'id' | 'spentCurrentMonth' | 'impressions' | 'clicks' | 'ctr' | 'cpc' | 'cpa' | 'conversions' | 'revenueGenerated' | 'roas' | 'health'>) => {
    const newCamp: Campaign = {
      ...cmpData,
      id: `cmp-${Date.now().toString().slice(-4)}`,
      spentCurrentMonth: 0,
      impressions: 0,
      clicks: 0,
      ctr: 0,
      cpc: 0,
      cpa: 0,
      conversions: 0,
      revenueGenerated: 0,
      roas: 0,
      health: 'Optimal',
    };
    setCampaigns((prev) => [newCamp, ...prev]);
  };

  const toggleCampaignStatus = (campaignId: string) => {
    setCampaigns((prev) =>
      prev.map((c) =>
        c.id === campaignId
          ? {
              ...c,
              status: c.status === 'Active' ? 'Paused' : 'Active',
            }
          : c
      )
    );
  };

  const updateCampaignBudget = (campaignId: string, newBudget: number) => {
    setCampaigns((prev) =>
      prev.map((c) => (c.id === campaignId ? { ...c, monthlyBudget: newBudget } : c))
    );
  };

  const addStrategy = (strategyData: Omit<MarketingStrategy, 'id' | 'createdAt' | 'lastUpdated'>) => {
    const newStrategy: MarketingStrategy = {
      ...strategyData,
      id: `strat-${Date.now().toString().slice(-4)}`,
      createdAt: new Date().toISOString().split('T')[0],
      lastUpdated: new Date().toISOString().split('T')[0],
    };
    setStrategies((prev) => [newStrategy, ...prev]);
  };

  const updateStrategyStage = (id: string, stage: MarketingStrategy['stage']) => {
    setStrategies((prev) =>
      prev.map((s) => (s.id === id ? { ...s, stage, lastUpdated: new Date().toISOString().split('T')[0] } : s))
    );
  };

  const addReport = (reportData: Omit<ReportItem, 'id' | 'dateGenerated'>) => {
    const newReport: ReportItem = {
      ...reportData,
      id: `rep-${Date.now().toString().slice(-4)}`,
      dateGenerated: new Date().toISOString().split('T')[0],
    };
    setReports((prev) => [newReport, ...prev]);
  };

  const convertMilestoneToTasks = (strategyId: string, phaseTitle: string) => {
    const strat = strategies.find((s) => s.id === strategyId);
    if (!strat) return;
    const phase = strat.actionRoadmap.find((p) => p.phase === phaseTitle);
    if (!phase) return;

    const newTasks: Task[] = phase.tasks.map((taskName, idx) => ({
      id: `tsk-gen-${Date.now()}-${idx}`,
      title: taskName,
      description: `Action item from ${strat.title} (${phase.phase})`,
      priority: 'High',
      status: 'To Do',
      assignee: 'Ayesha Tariq',
      deadline: new Date(Date.now() + (idx + 2) * 86400000).toISOString().split('T')[0],
      clientId: strat.clientId,
      clientName: strat.clientName,
      sourceStrategy: strat.title,
    }));

    setTasks((prev) => [...newTasks, ...prev]);
  };

  const addContentItem = (itemData: Omit<ContentItem, 'id' | 'status' | 'approvalStatus'>) => {
    const newItem: ContentItem = {
      ...itemData,
      id: `cnt-${Date.now().toString().slice(-4)}`,
      status: 'Review',
      approvalStatus: 'Pending Approval',
    };
    setContentItems((prev) => [newItem, ...prev]);

    // Also request approval automatically (Yellow Tier)
    const newApproval: ApprovalItem = {
      id: `appr-${Date.now().toString().slice(-4)}`,
      title: `Publish ${newItem.platform} ${newItem.contentType}: "${newItem.title}"`,
      description: `ZAI Content Agent prepared creative copy & brief for ${newItem.clientName}. Scheduled for ${newItem.scheduledDate}.`,
      tier: 'YELLOW',
      category: 'CONTENT',
      clientName: newItem.clientName,
      clientId: newItem.clientId,
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      requestedByAgent: 'Content Agent',
      status: 'PENDING',
      proposedAction: {
        actionType: 'PUBLISH_CONTENT',
        details: newItem.caption.slice(0, 140) + '...',
        impactSummary: `Scheduled on ${newItem.platform} for target audience engagement.`,
      },
    };
    setApprovals((prev) => [newApproval, ...prev]);
  };

  const updateContentStatus = (id: string, status: ContentItem['status']) => {
    setContentItems((prev) => prev.map((item) => (item.id === id ? { ...item, status } : item)));
  };

  const addTask = (taskData: Omit<Task, 'id'>) => {
    const newTask: Task = {
      ...taskData,
      id: `tsk-${Date.now().toString().slice(-4)}`,
    };
    setTasks((prev) => [newTask, ...prev]);
  };

  const toggleTaskStatus = (taskId: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === taskId) {
          const nextStatus = t.status === 'Completed' ? 'To Do' : 'Completed';
          return { ...t, status: nextStatus };
        }
        return t;
      })
    );
  };

  const deleteTask = (taskId: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== taskId));
  };

  const handleApproval = (id: string, decision: 'APPROVE' | 'REJECT', decisionNote?: string) => {
    setApprovals((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          return {
            ...item,
            status: decision === 'APPROVE' ? 'APPROVED' : 'REJECTED',
            auditLog: {
              reviewedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              reviewedBy: 'Zahida Khan (Agency Director)',
              decisionNote: decisionNote || (decision === 'APPROVE' ? 'Approved for execution' : 'Rejected with revisions requested'),
            },
          };
        }
        return item;
      })
    );

    // Log to agent logs
    const target = approvals.find((a) => a.id === id);
    if (target) {
      setAgentLogs((prev) => [
        {
          id: `log-${Date.now()}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          agent: target.requestedByAgent,
          action: `${decision === 'APPROVE' ? 'Executive Approved' : 'Executive Rejected'}: ${target.title}`,
          details: `Authorized by Zahida Khan. Action status updated to ${decision === 'APPROVE' ? 'APPROVED' : 'REJECTED'}.`,
          requiresHumanReview: false,
        },
        ...prev,
      ]);
    }
  };

  const addKnowledgeDoc = (docData: Omit<KnowledgeDocument, 'id' | 'lastUpdated'>) => {
    const newDoc: KnowledgeDocument = {
      ...docData,
      id: `kb-${Date.now().toString().slice(-4)}`,
      lastUpdated: new Date().toISOString().split('T')[0],
    };
    setKnowledgeDocs((prev) => [newDoc, ...prev]);
  };

  // AI Orchestration
  const sendAiMessage = async (prompt: string, specificAgent = 'ZAI — Chief Marketing Intelligence', targetClientId?: string) => {
    const userMsg: ChatMessage = {
      id: `usr-${Date.now()}`,
      sender: 'zahida',
      text: prompt,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setChatMessages((prev) => [...prev, userMsg]);
    setIsAiThinking(true);

    const client = clients.find((c) => c.id === (targetClientId || selectedClientId));

    try {
      const response = await fetch('/api/ai/orchestrate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          agent: specificAgent,
          clientContext: client
            ? {
                name: client.name,
                industry: client.industry,
                memory: client.memory,
                monthlyRetainer: client.monthlyRetainer,
                monthlyAdSpend: client.monthlyAdSpend,
                blendedRoas: client.blendedRoas,
              }
            : null,
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const data = await response.json();

      const aiMsg: ChatMessage = {
        id: `zai-${Date.now()}`,
        sender: 'zai',
        agentName: specificAgent,
        text: data.content || 'I have completed the analysis.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        executionMode: data.mode || 'simulated_local',
        toolsCalled: [
          'getClientMemory()',
          'analyzeCampaignMetrics()',
          'evaluateApprovalPolicy()',
        ],
        suggestedActions: [
          'Open Approval Center',
          'Draft Content Brief',
          'Generate Task Breakdown',
        ],
      };

      setChatMessages((prev) => [...prev, aiMsg]);
    } catch (err: any) {
      console.warn('AI call fell back to local intelligence:', err);
      // Fallback local response
      const fallbackMsg: ChatMessage = {
        id: `zai-${Date.now()}`,
        sender: 'zai',
        agentName: specificAgent,
        text: `Zahida, I have processed your instruction regarding "${prompt}".
${client ? `Analyzing client context for ${client.name} (${client.industry}).` : 'Analyzing full agency portfolio.'}

**Key Findings**:
- Current marketing memory and brand voice rules are loaded.
- All high-impact external actions remain gated behind the Approval Center (Yellow/Red tiers).
- Would you like me to formulate a structured strategy or create tasks for your team?`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        executionMode: 'simulated_local',
        toolsCalled: ['getClientMemory()'],
        suggestedActions: ['Create Task', 'Push to Approval Queue'],
      };
      setChatMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsAiThinking(false);
    }
  };

  const clearChat = () => {
    setChatMessages([]);
  };

  const toggleAutomation = (id: string) => {
    setAutomations((prev) =>
      prev.map((a) => (a.id === id ? { ...a, status: a.status === 'Active' ? 'Paused' : 'Active' } : a))
    );
  };

  const addCompetitorReport = (report: Omit<CompetitorResearchReport, 'id' | 'analysisDate'>) => {
    const newReport: CompetitorResearchReport = {
      ...report,
      id: `comp-${Date.now().toString().slice(-4)}`,
      analysisDate: new Date().toISOString().split('T')[0],
    };
    setCompetitorReports((prev) => [newReport, ...prev]);
  };

  const exportBackup = () => {
    const backupData = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      clients,
      leads,
      campaigns,
      approvals,
      contentItems,
      tasks,
      knowledgeDocs,
    };
    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `zahida-ai-backup-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const clearAllDataToFreshSlate = () => {
    setClients([]);
    setLeads([]);
    setCampaigns([]);
    setContentItems([]);
    setTasks([]);
    setApprovals([]);
    setIsDemoMode(false);
    localStorage.setItem('zai_is_demo_mode', JSON.stringify(false));
  };

  useEffect(() => {
    localStorage.setItem('zai_is_demo_mode', JSON.stringify(isDemoMode));
  }, [isDemoMode]);

  return (
    <AgencyContext.Provider
      value={{
        currentView,
        setCurrentView,
        selectedClientId,
        setSelectedClientId,
        clients,
        leads,
        campaigns,
        strategies,
        reports,
        approvals,
        contentItems,
        tasks,
        teamMembers,
        knowledgeDocs,
        dailyBriefing,
        agentLogs,
        isDemoMode,
        setIsDemoMode,
        automations,
        toggleAutomation,
        competitorReports,
        addCompetitorReport,
        exportBackup,
        clearAllDataToFreshSlate,
        isCommandPaletteOpen,
        setIsCommandPaletteOpen,
        isAskZaiOpen,
        setIsAskZaiOpen,
        quickModalType,
        setQuickModalType,
        selectedClientDetail,
        setSelectedClientDetail,
        addClient,
        updateClientMemory,
        addLead,
        updateLeadStatus,
        addCampaign,
        toggleCampaignStatus,
        updateCampaignBudget,
        addStrategy,
        updateStrategyStage,
        addReport,
        convertMilestoneToTasks,
        addContentItem,
        updateContentStatus,
        addTask,
        toggleTaskStatus,
        deleteTask,
        handleApproval,
        addKnowledgeDoc,
        chatMessages,
        isAiThinking,
        sendAiMessage,
        clearChat,
      }}
    >
      {children}
    </AgencyContext.Provider>
  );
};

export const useAgency = () => {
  const context = useContext(AgencyContext);
  if (!context) {
    throw new Error('useAgency must be used within an AgencyProvider');
  }
  return context;
};
