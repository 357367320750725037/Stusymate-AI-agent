import { MarketingStrategy } from '../types';

export const INITIAL_STRATEGIES: MarketingStrategy[] = [
  {
    id: 'strat-001',
    title: 'Omnichannel DTC Scaling & Creative Fatigue Defense',
    clientId: 'cli-001',
    clientName: 'Lumina Skin Co',
    category: 'Full-Funnel',
    stage: 'Active Execution',
    targetAudience: 'Skincare enthusiasts & conscious women aged 24–45 suffering from sensitized skin barrier breakdown',
    primaryObjective: 'Scale monthly revenue from $95k to $160k while defending blended ROAS ≥ 3.5x and capping CPA at $28',
    expectedRoas: '3.8x Blended ROAS',
    createdAt: '2026-09-15',
    lastUpdated: '2026-10-09',
    aiStrategicRationale:
      'Lumina has exceptional product retention (48% 60-day re-order rate) but suffers from rapid creative fatigue on single hero video ads. By establishing a continuous 3-tier UGC creator flywheel, testing 6 fresh hooks weekly, and deploying automated post-purchase email education, we solve top-of-funnel acquisition fatigue while compounding customer lifetime value.',
    channelMix: ['Meta Ads (Advantage+)', 'TikTok Organic & Spark Ads', 'Klaviyo Lifecycle Email', 'Google Brand Search'],
    budgetAllocation: [
      { channel: 'Meta Ads (Advantage+ & Retargeting)', percentage: 55, amount: 13200 },
      { channel: 'TikTok Spark Ads & Creator Sourcing', percentage: 20, amount: 4800 },
      { channel: 'Google High-Intent & Brand Search', percentage: 15, amount: 3600 },
      { channel: 'Klaviyo Retention & SMS Automation', percentage: 10, amount: 2400 },
    ],
    strategicPillars: [
      {
        title: 'Rapid Creative Rotation Engine',
        description: 'Prevent ad fatigue by testing 5 micro-budget hooks every Tuesday and scaling winning cuts into Advantage+ budget.',
        tactics: [
          'Partner with 8 micro-creators monthly for authentic unboxing & dermatologist reaction b-roll',
          'Deploy 3 hook variations for every winning angle (Sensory, Clinical Barrier Proof, Before/After)',
          'Automated pause rule in ZAI Ads Agent when ad frequency exceeds 3.4 or CPA rises > 22%',
        ],
      },
      {
        title: 'Clinical Barrier Proof Positioning',
        description: 'Differentiate from generic beauty brands by leading with the 28-day dermatological lipid barrier repair clinical study.',
        tactics: [
          'Embed interactive moisture barrier self-quiz on landing page (average 42% email capture rate)',
          'High-authority carousel ads breaking down active bio-fermented ingredients',
          'Press feature snippets and dermatologist video testimonials in middle-of-funnel retargeting',
        ],
      },
      {
        title: 'Post-Purchase LTV & Habit Formation',
        description: 'Turn one-time serum buyers into 90-day subscription routine devotees through timed ritual emails.',
        tactics: [
          'Day 3 post-delivery: Video tutorial on correct dropper application and layering order',
          'Day 14 post-delivery: "The Barrier Transition Phase" check-in email with customer support access',
          'Day 25 post-delivery: One-click SMS subscription re-order with 15% VIP discount code',
        ],
      },
    ],
    kpis: [
      { metric: 'Blended ROAS', target: '≥ 3.50x', current: '3.44x' },
      { metric: 'Customer Acquisition Cost (CPA)', target: '< $26.00', current: '$28.40' },
      { metric: '60-Day Repeat Purchase Rate', target: '> 45%', current: '48.2%' },
      { metric: 'Email Revenue Share', target: '> 30%', current: '26.8%' },
    ],
    actionRoadmap: [
      {
        phase: 'Phase 1: Creative Flywheel Setup',
        duration: 'Weeks 1–2',
        status: 'Done',
        tasks: [
          'Audit existing 12 Meta ad sets and prune bottom 4 fatigued assets',
          'Ship product packages to 8 vetted UGC skincare creators',
          'Set up Meta Conversion API (CAPI) Gateway for 100% signal capture',
        ],
      },
      {
        phase: 'Phase 2: Scale Advantage+ & UGC Testing',
        duration: 'Weeks 3–6',
        status: 'In Progress',
        tasks: [
          'Launch 6 new creator hooks against Derm-Approved angle',
          'Integrate Barrier Quiz on Shopify store with Klaviyo quiz flow',
          'Deploy VIP Early Black Friday VIP waitlist pre-launch funnel',
        ],
      },
      {
        phase: 'Phase 3: Holiday Scaling & Subscription Push',
        duration: 'Weeks 7–12',
        status: 'Upcoming',
        tasks: [
          'Scale daily ad spend to $1,100/day during Q4 promotional surge',
          'Launch Limited Holiday Barrier Restorative Kit bundle offer',
          'QBR with Sophie Vance to review annual retainer expansion',
        ],
      },
    ],
  },
  {
    id: 'strat-002',
    title: 'B2B Account-Based Demand Engine & High-Intent Pipeline Accelerator',
    clientId: 'cli-002',
    clientName: 'Apex Fintech Solutions',
    category: 'Full-Funnel',
    stage: 'Active Execution',
    targetAudience: 'CFOs, VP Treasury, Head of Finance at mid-market North American tech & manufacturing companies ($20M–$250M ARR)',
    primaryObjective: 'Generate 120+ qualified enterprise demo discovery calls per quarter at target cost per demo < $175',
    expectedRoas: '4.8x Attributed Contract Pipeline',
    createdAt: '2026-09-01',
    lastUpdated: '2026-10-09',
    aiStrategicRationale:
      'Enterprise treasury software has an average 75-day sales cycle with $45k+ ACV. Traditional broad social ads fail; high-intent Google Search captures CFOs actively seeking automated reconciliation, while LinkedIn Account-Based Marketing warms up matched enterprise accounts through authoritative research whitepapers and thought leadership.',
    channelMix: ['Google High-Intent Search', 'LinkedIn ABM & Document Ads', 'CFO Thought Leadership', 'Direct Outbound Sequences'],
    budgetAllocation: [
      { channel: 'Google Ads (Exact Match Intent)', percentage: 50, amount: 19000 },
      { channel: 'LinkedIn Matched Audiences & InMail', percentage: 35, amount: 13300 },
      { channel: 'Industry Whitepapers & Gated Reports', percentage: 10, amount: 3800 },
      { channel: 'Retargeting & Executive Video Demos', percentage: 5, amount: 1900 },
    ],
    strategicPillars: [
      {
        title: 'High-Intent Search Capture',
        description: 'Dominate exact-match commercial keywords that indicate active software replacement initiatives.',
        tactics: [
          'Target exact phrases: "automated multi-bank reconciliation software", "enterprise treasury API", "corporate cash positioning platform"',
          'Dedicated comparison landing pages vs legacy providers (Kyriba, Trovata)',
          'Strict negative keyword curation excluding consumer banking and academic finance queries',
        ],
      },
      {
        title: 'LinkedIn Seniority Account-Based Marketing',
        description: 'Surround 500 hand-picked enterprise accounts with authoritative content before sales touches them.',
        tactics: [
          'Deliver 7-page PDF Document Ads directly in CFO LinkedIn feeds with zero-click value',
          'Ghostwrite weekly LinkedIn thought leadership articles for Apex CEO and Chief Product Officer',
          'Sponsor targeted invitation-only virtual executive roundtables on corporate liquidity risk',
        ],
      },
      {
        title: 'Frictionless Demo Booking Architecture',
        description: 'Remove friction from calendar scheduling for time-starved finance executives.',
        tactics: [
          'Replace 10-field web forms with interactive 2-click qualification widget',
          'Direct integration into Sales SDR calendar with instant Slack confirmation alert',
          'Automated calendar invite SMS reminder and pre-read 2-page executive summary',
        ],
      },
    ],
    kpis: [
      { metric: 'Monthly Qualified Demos Booked', target: '≥ 90 Demos', current: '91 Demos' },
      { metric: 'Cost Per Qualified Demo (CPA)', target: '< $180.00', current: '$168.00' },
      { metric: 'Demo Attendance / Show-Up Rate', target: '> 85%', current: '89.4%' },
      { metric: 'Opportunity Pipeline Value', target: '> $1.5M/mo', current: '$1.82M' },
    ],
    actionRoadmap: [
      {
        phase: 'Phase 1: ABM Account List Ingestion',
        duration: 'Month 1',
        status: 'Done',
        tasks: [
          'Ingest list of 1,200 ICP tech accounts into LinkedIn Campaign Manager',
          'Launch Google Search campaign with $730/day budget cap',
          'Publish "2026 CFO Treasury Playbook" PDF document ad',
        ],
      },
      {
        phase: 'Phase 2: Scale Search & Retargeting',
        duration: 'Month 2',
        status: 'In Progress',
        tasks: [
          'Scale winning search ad group budget by +15% after achieving 4.8x ROAS',
          'Deploy executive customer video testimonials for mid-funnel retargeting',
          'Deliver September Executive Report to David Chen for leadership renewal',
        ],
      },
      {
        phase: 'Phase 3: Interactive ROI Calculator Launch',
        duration: 'Month 3',
        status: 'Upcoming',
        tasks: [
          'Launch embedded "Treasury Hours Saved" interactive calculator on apexfintech.io',
          'Set up automated lead scoring enrichment via Clearbit API integration',
          'Evaluate expanding campaign to European mid-market financial hubs',
        ],
      },
    ],
  },
  {
    id: 'strat-003',
    title: 'Seasonal Subscription LTV Scaling & Gifting Funnel',
    clientId: 'cli-003',
    clientName: 'Nordic Roastery Co',
    category: 'Retention & Lifecycle',
    stage: 'Active Execution',
    targetAudience: 'Third-wave coffee connoisseurs, home baristas, and upscale Scandinavian lifestyle gift buyers',
    primaryObjective: 'Grow active monthly recurring coffee subscribers from 850 to 1,500 with target LTV/CAC ratio > 4.2x',
    expectedRoas: '5.2x Blended ROAS',
    createdAt: '2026-09-20',
    lastUpdated: '2026-10-09',
    aiStrategicRationale:
      'Nordic Roastery produces world-class artisanal beans. By packaging subscriptions as an elevated morning mindfulness ritual and targeting coffee enthusiasts on TikTok and Instagram Reels with ASMR aesthetics, we achieve low acquisition costs while building durable high-margin monthly recurring revenue.',
    channelMix: ['Meta Ads (Reels & Lifestyle)', 'TikTok Organic/Paid', 'Klaviyo Coffee Club Flows', 'Substack Editorial'],
    budgetAllocation: [
      { channel: 'Meta Ads (Instagram Reels & Gift Guides)', percentage: 50, amount: 4750 },
      { channel: 'TikTok Short-Form Video & Spark Ads', percentage: 25, amount: 2375 },
      { channel: 'Klaviyo Email Segmentation & Win-Backs', percentage: 15, amount: 1425 },
      { channel: 'Micro-Influencer Roaster Collabs', percentage: 10, amount: 950 },
    ],
    strategicPillars: [
      {
        title: 'Sensory Short-Form Video Dominance',
        description: 'Show, do not tell: capture the sensory pleasure of morning artisanal brewing with crisp ASMR audio and slow-motion pours.',
        tactics: [
          'Focus on first 3 seconds hook: "If your coffee bag does not have a roast date, it’s already dead"',
          'Contrast supermarket stale beans vs 72-hour fresh bloom extraction',
          'Partner with Nordic aesthetic home interior creators for natural placement',
        ],
      },
      {
        title: 'Holiday Subscription Gifting Architecture',
        description: 'Position 3-month and 6-month prepaid gift subscriptions as the premier holiday gift for discerning tastemakers.',
        tactics: [
          'Introduce luxury embossed gift card packaging included with first shipment',
          'Bundle bespoke ceramic mug with all 6-month upfront subscriptions',
          'Create dedicated "Gifting Concierge" landing page with countdown timer',
        ],
      },
      {
        title: 'Subscription Churn Suppression System',
        description: 'Proactively prevent subscriber fatigue by rotating single-origin bean varieties and providing brewing recipes.',
        tactics: [
          'Every bag includes QR code linking to roaster Henrik Lindqvist’s grind size & water temp guide',
          'Allow 1-click subscription pause/skip in SMS flow rather than full cancellation',
          'Surprise limited-batch micro-lot sample included in month 3 of subscription',
        ],
      },
    ],
    kpis: [
      { metric: 'Monthly Recurring Subscribers', target: '≥ 1,200', current: '980' },
      { metric: 'Blended Acquisition ROAS', target: '≥ 4.50x', current: '5.20x' },
      { metric: 'Cost Per New Subscriber (CAC)', target: '< $22.00', current: '$19.50' },
      { metric: 'Average Subscriber Retention', target: '> 6.5 Months', current: '7.1 Months' },
    ],
    actionRoadmap: [
      {
        phase: 'Phase 1: Creative Production Sprint',
        duration: 'Weeks 1–2',
        status: 'Done',
        tasks: [
          'Film 12 morning ritual ASMR reels in roastery studio',
          'Deploy new mobile-first checkout with 1-click Apple Pay subscription support',
          'Configure Klaviyo churn prevention flow triggering at day 45',
        ],
      },
      {
        phase: 'Phase 2: Scale Ad Budget by +15%',
        duration: 'Weeks 3–5',
        status: 'In Progress',
        tasks: [
          'Submit budget expansion request in ZAI Approval Center from $310 to $355/day',
          'Test 2 additional Scandinavian lifestyle hooks on TikTok Ads',
          'Launch Holiday Gift Box pre-orders for VIP email subscribers',
        ],
      },
      {
        phase: 'Phase 3: Holiday Gifting Peak Surge',
        duration: 'Weeks 6–10',
        status: 'Upcoming',
        tasks: [
          'Scale ad spend to $600/day during Black Friday and December holiday gifting window',
          'Distribute press gift sets to Scandinavian lifestyle publications',
          'Implement automated subscriber referral reward flow ($15 bean credit)',
        ],
      },
    ],
  },
  {
    id: 'strat-004',
    title: 'High-Ticket Longevity Patient Acquisition & Mobile CRO Blueprint',
    clientId: 'cli-004',
    clientName: 'Solstice Health Clinic',
    category: 'Conversion Optimization',
    stage: 'Planning',
    targetAudience: 'High-net-worth executives, entrepreneurs, and health optimizers aged 35–65 in Miami, Palm Beach, and South Florida',
    primaryObjective: 'Fix mobile landing page 61% bounce rate, streamline booking flow, and generate 35+ $3,500 baseline scans monthly',
    expectedRoas: '3.8x Blended ROAS',
    createdAt: '2026-10-01',
    lastUpdated: '2026-10-09',
    aiStrategicRationale:
      'Solstice offers high-ticket $3,500 comprehensive diagnostic scans. However, paid traffic is currently leaking because the mobile scheduling form requires 9 tedious fields and fails to establish immediate medical credibility. By redesigning the mobile consultation funnel and retargeting with doctor video explainers, conversion rate can triple from 1.2% to 3.5%.',
    channelMix: ['Google High-Intent Local Search', 'Meta Video Testimonials', 'Mobile CRO & UX Redesign', 'Local Concierge Doctor Referrals'],
    budgetAllocation: [
      { channel: 'Google Search (Longevity & MRI Scan Queries)', percentage: 55, amount: 6050 },
      { channel: 'Meta Ads (Doctor Explainer & Patient Case Studies)', percentage: 30, amount: 3300 },
      { channel: 'Mobile UX & Interactive Assessment Optimization', percentage: 10, amount: 1100 },
      { channel: 'Local Executive Referral Sponsorships', percentage: 5, amount: 550 },
    ],
    strategicPillars: [
      {
        title: 'Frictionless Mobile Booking Flow',
        description: 'Eliminate form fatigue by replacing the legacy 9-step questionnaire with a high-trust 2-minute longevity assessment.',
        tactics: [
          'Sticky mobile header with direct "Book Executive Concierge Call" tap-to-call & WhatsApp link',
          'Interactive 4-question readiness survey that qualifies net worth and diagnostic goals',
          'Instant calendar slot reservation with SMS confirmation within 60 seconds',
        ],
      },
      {
        title: 'Physician Authority & Clinical Proof',
        description: 'Overcome skepticism regarding preventive longevity medicine with rigorous board-certified credibility.',
        tactics: [
          'Short video series featuring Dr. Elena Rostova explaining 3T MRI cancer & aneurysm detection data',
          'Virtual walkthrough of the state-of-the-art Miami clinic and private patient suites',
          'Featured patient stories from recognizable South Florida tech founders and executives',
        ],
      },
      {
        title: 'High-Intent Local Search Dominance',
        description: 'Capture patients actively searching for advanced preventive scans and executive physicals.',
        tactics: [
          'Exact match keywords: "full body MRI scan Miami", "executive health assessment Palm Beach", "longevity clinic doctor"',
          'Optimize Google Business Profile with 5-star patient review collection automation',
          'Target geo-fenced high-income ZIP codes in Coral Gables, Brickell, and Star Island',
        ],
      },
    ],
    kpis: [
      { metric: 'Mobile Landing Page Conversion Rate', target: '≥ 3.2%', current: '1.2%' },
      { metric: 'Mobile Bounce Rate', target: '< 38%', current: '61.4%' },
      { metric: 'Monthly Comprehensive Scans Booked', target: '≥ 30 Scans', current: '20 Scans' },
      { metric: 'Average Cost Per Booked Scan (CPA)', target: '< $300.00', current: '$390.00' },
    ],
    actionRoadmap: [
      {
        phase: 'Phase 1: Emergency Mobile CRO Redesign',
        duration: 'Days 1–7',
        status: 'In Progress',
        tasks: [
          'Deploy revised mobile booking widget with simplified 3-step qualification',
          'Add click-to-call physician concierge button for mobile visitors',
          'Implement Hotjar heatmaps to track drop-off zones on booking page',
        ],
      },
      {
        phase: 'Phase 2: Video Testimonial Ad Rollout',
        duration: 'Weeks 2–4',
        status: 'Upcoming',
        tasks: [
          'Film 4 high-production video clips with Dr. Rostova in Miami clinic',
          'Launch geo-fenced Meta video campaign targeting Brickell & Palm Beach executives',
          'Review Google Search negative keyword list to eliminate non-local traffic',
        ],
      },
      {
        phase: 'Phase 3: High-Ticket VIP Membership Launch',
        duration: 'Weeks 5–8',
        status: 'Upcoming',
        tasks: [
          'Introduce annual $12,000 executive health concierge membership package',
          'Host private breakfast briefing at Miami executive club for referral leads',
          'Present 60-day recovery audit to Solstice leadership board',
        ],
      },
    ],
  },
  {
    id: 'strat-005',
    title: 'Enterprise Cold-Chain SEO Route Moat & Tender Capture',
    clientId: 'cli-005',
    clientName: 'Velox Logistics & Freight',
    category: 'Organic & SEO',
    stage: 'Active Execution',
    targetAudience: 'Supply chain VPs, logistics directors, and cold-chain compliance heads in pharmaceutical, biotechnology, and organic food manufacturing',
    primaryObjective: 'Secure 150+ high-volume enterprise lane RFP submissions per quarter and outrank CH Robinson on Midwest refrigerated routes',
    expectedRoas: '4.4x Attributed Pipeline Value',
    createdAt: '2026-08-15',
    lastUpdated: '2026-10-09',
    aiStrategicRationale:
      'B2B freight decisions are driven by reliability and route coverage. By developing programmatic high-authority route landing pages for specific cold-chain freight corridors (e.g. Chicago to Atlanta refrigerated shipping) and backing it with technical case studies on IoT temperature compliance, Velox builds an organic traffic moat that drives zero-cost high-contract RFP bids.',
    channelMix: ['Technical Programmatic SEO', 'Google High-Intent Freight Search', 'LinkedIn Logistics Outbound', 'Industry Whitepapers'],
    budgetAllocation: [
      { channel: 'Google Search Ads (Dedicated Lane RFP)', percentage: 60, amount: 9000 },
      { channel: 'Programmatic SEO & Content Engineering', percentage: 25, amount: 3750 },
      { channel: 'LinkedIn ABM Decision-Maker Targeting', percentage: 15, amount: 2250 },
    ],
    strategicPillars: [
      {
        title: 'Programmatic Freight Lane Landing Pages',
        description: 'Build 45 indexable, highly optimized corridor landing pages targeting commercial refrigerated shipping queries.',
        tactics: [
          'Page template with real-time transit calculators, temperature range guarantees, and fleet specs',
          'Structured schema data for logistics services, routes, and geographic coverage',
          'Internal linking architecture clustering around regional logistics hubs (Chicago, Dallas, Atlanta)',
        ],
      },
      {
        title: 'Precision Commercial Negative Keyword Gating',
        description: 'Protect ad spend by relentlessly filtering out low-margin consumer moving and personal freight queries.',
        tactics: [
          'Added 42 negative keyword exclusions in Google Ads campaign',
          'Bidding strictly on B2B commercial intent: "refrigerated freight RFP", "contract cold storage carrier"',
          'Dynamic landing page headline matching the specific origin-destination corridor searched',
        ],
      },
      {
        title: 'Cold-Chain IoT Compliance Credibility',
        description: 'Position Velox as the gold standard for zero-spoilage pharmaceutical and perishables transport.',
        tactics: [
          'Publish whitepaper on FDA Food Safety Modernization Act (FSMA) compliance telemetry',
          'Showcase 99.8% on-time temperature compliance audit data in sales decks',
          'Promote case study on safeguarding multi-million dollar biologic pharmaceutical shipments',
        ],
      },
    ],
    kpis: [
      { metric: 'Quarterly RFP Bids Received', target: '≥ 140 RFPs', current: '126 RFPs' },
      { metric: 'Cost Per Qualified RFP (CPL)', target: '< $85.00', current: '$82.50' },
      { metric: 'First-Page Google Keywords for Lanes', target: '> 60 Keywords', current: '54 Keywords' },
      { metric: 'Average Won Contract Value', target: '> $120k ARR', current: '$148k ARR' },
    ],
    actionRoadmap: [
      {
        phase: 'Phase 1: Negative Keyword Scrub & Audit',
        duration: 'Month 1',
        status: 'Done',
        tasks: [
          'Scrub search query logs and add 42 consumer parcel negative keywords',
          'Launch Google Ads dedicated lane campaign for 5 core Midwest routes',
          'Optimize schema markup across veloxfreight.com site architecture',
        ],
      },
      {
        phase: 'Phase 2: Programmatic Corridor Rollout',
        duration: 'Month 2',
        status: 'In Progress',
        tasks: [
          'Deploy 18 programmatic cold-chain route landing pages',
          'Publish cold-chain IoT temperature telemetry article on LinkedIn',
          'Integrate 60-second instant freight quote RFP form with sales dispatch',
        ],
      },
      {
        phase: 'Phase 3: Backlink Authority Sprint',
        duration: 'Month 3',
        status: 'Upcoming',
        tasks: [
          'Secure placements on Logistics Management and Supply Chain Brain portals',
          'Launch targeted LinkedIn sponsored campaign targeting 300 pharma supply chain heads',
          'Present quarterly enterprise growth review to CEO Marcus Brody',
        ],
      },
    ],
  },
  {
    id: 'strat-006',
    title: 'Mayfair Bespoke Bridal & High-Net-Worth Private Concierge Strategy',
    clientId: 'cli-006',
    clientName: 'Aurelia Fine Jewels',
    category: 'Brand Authority',
    stage: 'Active Execution',
    targetAudience: 'High-net-worth couples, affluent grooms-to-be, and luxury bridal tastemakers across London, the UK, and international destinations',
    primaryObjective: 'Scale private bespoke bridal atelier consultations to 130+ per quarter with average bespoke order value > £12,000',
    expectedRoas: '4.5x Attributed Luxury Sales',
    createdAt: '2026-09-10',
    lastUpdated: '2026-10-09',
    aiStrategicRationale:
      'High-end bespoke jewelry is an emotional, high-touch investment. Rather than treating social media as a commodity storefront, Aurelia positions its Mayfair atelier as an exclusive sanctuary of heirloom craftsmanship. Utilizing cinematic macro photography, bespoke consultation scheduling, and discreet VIP email storytelling, we attract discerning clients seeking one-of-a-kind diamond heirlooms.',
    channelMix: ['Instagram Luxury Editorial', 'Pinterest Bridal Boards', 'Meta Advantage+ Concierge Ads', 'Private Atelier VIP Lists'],
    budgetAllocation: [
      { channel: 'Meta Ads (Instagram Stories, Reels & Private DMs)', percentage: 55, amount: 5775 },
      { channel: 'Pinterest Visual Discovery & Bridal Planning', percentage: 25, amount: 2625 },
      { channel: 'VIP Atelier Storytelling & Private Email Invitations', percentage: 15, amount: 1575 },
      { channel: 'Luxury Bridal Publication Features', percentage: 5, amount: 525 },
    ],
    strategicPillars: [
      {
        title: 'Cinematic Mayfair Atelier Storytelling',
        description: 'Highlight the meticulous hand-craftsmanship of master bench jewelers through macro video captures of stone setting and gold polishing.',
        tactics: [
          'Short-form Reels showcasing hand-setting antique cushion cut diamonds with authentic studio sounds',
          'Behind-the-scenes glimpses into the private Mayfair showroom consultations',
          'Emphasis on ethical sourcing: 100% recycled 18k gold and conflict-free certified stones',
        ],
      },
      {
        title: 'Seamless Virtual & In-Person Appointment Booking',
        description: 'Provide an effortless VIP booking path for both local London clients and international virtual consultations.',
        tactics: [
          'Automated Instagram Direct Message concierge flow delivering instant appointment selection calendar',
          'Personalized intake form inquiring about ring style preferences, timeline, and stone cut interests',
          'Dedicated consultation confirmation with digital champagne welcome guide',
        ],
      },
      {
        title: 'Pinterest High-Intent Bridal Discovery',
        description: 'Target brides-to-be at the exact moment they are designing their dream engagement ring mood boards.',
        tactics: [
          'Rich product Pins for bespoke solitaire, three-stone, and bezel engagement designs',
          'Bridal style guides: "How to Choose Between Oval, Cushion, and Emerald Cut Diamonds"',
          'Retargeting Pin visitors with invitations to book an atelier consultation',
        ],
      },
    ],
    kpis: [
      { metric: 'Quarterly Bespoke Consultations Booked', target: '≥ 120 Consultations', current: '100 Consultations' },
      { metric: 'Average Bespoke Order Value', target: '> £10,000', current: '£12,400' },
      { metric: 'Consultation to Commission Conversion', target: '> 55%', current: '62%' },
      { metric: 'Cost Per Booked Consultation (CPA)', target: '< £75.00', current: '£64.00' },
    ],
    actionRoadmap: [
      {
        phase: 'Phase 1: Autumn Bridal Launch',
        duration: 'Weeks 1–3',
        status: 'Done',
        tasks: [
          'Film 8 macro studio reels of new bespoke solitaire collection in Mayfair atelier',
          'Configure Instagram DM automated concierge booking link with Calendly VIP integration',
          'Launch Pinterest Autumn Bridal inspiration campaigns',
        ],
      },
      {
        phase: 'Phase 2: Scale Meta Advantage+ Appointments',
        duration: 'Weeks 4–7',
        status: 'In Progress',
        tasks: [
          'Launch Meta Ads campaign targeting high-net-worth London and international bridal audiences',
          'Deploy 3 UGC client unboxing & proposal moment stories',
          'Prepare winter holiday proposal campaign creative assets',
        ],
      },
      {
        phase: 'Phase 3: Holiday Proposal Peak Surge',
        duration: 'Weeks 8–12',
        status: 'Upcoming',
        tasks: [
          'Scale campaign budget for peak December proposal booking season',
          'Launch private VIP email preview for exclusive rare stone allocations',
          'Quarterly review with Camilla Laurent to discuss 2027 international expansion',
        ],
      },
    ],
  },
  {
    id: 'strat-007',
    title: 'Single-Estate Cold-Pressed Olive Oil Heritage Launch & VIP Pre-Order Sprint',
    clientId: 'cli-007',
    clientName: 'Zaytoun Natural Oils',
    category: 'Full-Funnel',
    stage: 'Planning',
    targetAudience: 'Artisanal foodies, home chefs, gourmet health enthusiasts, and conscious culinary connoisseurs',
    primaryObjective: 'Execute high-converting 60-day launch sprint to generate 2,500 initial bottle pre-orders and $85k revenue at 4.0x ROAS',
    expectedRoas: '4.1x Projected ROAS',
    createdAt: '2026-10-05',
    lastUpdated: '2026-10-09',
    aiStrategicRationale:
      'Zaytoun Natural Oils has century-old heritage olive groves producing rare single-estate, high-polyphenol cold-pressed oil. By positioning the first pressing as a strictly limited annual harvest allocation, we build immediate scarcity and demand, allowing a profitable VIP launch sprint that converts inbound foodies into long-term subscribers.',
    channelMix: ['Meta Ads (Heritage & Culinary Storytelling)', 'Gourmet Chef Creator Partnerships', 'Klaviyo VIP Pre-Order Flows', 'Gourmet Food PR'],
    budgetAllocation: [
      { channel: 'Meta Ads (Advantage+ & Storytelling Video)', percentage: 50, amount: 4250 },
      { channel: 'Culinary Influencer Seedings & Collabs', percentage: 25, amount: 2125 },
      { channel: 'VIP Waitlist & Early Access Email Sequences', percentage: 15, amount: 1275 },
      { channel: 'High-Intent Foodie Search & Google Shopping', percentage: 10, amount: 850 },
    ],
    strategicPillars: [
      {
        title: 'Limited Harvest Scarcity Architecture',
        description: 'Position the olive oil like fine vintage wine, with numbered bottles and strict annual harvest allocations.',
        tactics: [
          'Pre-launch countdown landing page offering first 1,000 subscribers early bottle access',
          'Certificates of polyphenol potency and harvest date stamped on every bottle label',
          'Transparent behind-the-scenes harvest footage in Palestinian family groves',
        ],
      },
      {
        title: 'Culinary Tastemaker Seeding',
        description: 'Get bottles into the hands of respected chefs, sourdough bakers, and food creators for authentic taste reviews.',
        tactics: [
          'Ship custom wooden gift crates with fresh sourdough loaf, sea salt, and harvest bottle to 25 creators',
          'Encourage simple sensory videos: dipping warm crusty bread into the vibrant green oil',
          'Spark ads amplification of the top 3 highest-performing creator reaction videos',
        ],
      },
      {
        title: 'Direct-to-Consumer Culinary Subscription',
        description: 'Transition one-time holiday buyers into quarterly kitchen staple subscription members.',
        tactics: [
          'Introduce the "Founder’s Harvest Club" delivering 2 fresh bottles every 90 days with 15% discount',
          'Quarterly recipes crafted by Mediterranean culinary experts included in every shipment',
          'Guaranteed holiday gift allocation reserve for active club members',
        ],
      },
    ],
    kpis: [
      { metric: 'VIP Waitlist Subscribers Acquired', target: '≥ 3,000 Signups', current: '1,420 Signups' },
      { metric: 'Pre-Order Conversion Rate', target: '> 18%', current: 'Pending Launch' },
      { metric: 'Launch Phase Blended ROAS', target: '≥ 4.00x', current: 'Targeting 4.1x' },
      { metric: 'Subscription Opt-in at Checkout', target: '> 25%', current: 'Targeting 28%' },
    ],
    actionRoadmap: [
      {
        phase: 'Phase 1: VIP Waitlist & Content Capture',
        duration: 'Weeks 1–2',
        status: 'In Progress',
        tasks: [
          'Launch Shopify pre-order landing page with countdown timer and waitlist incentive',
          'Ship seed packages to 25 prominent gourmet food and bread creators',
          'Draft 5-part email nurture sequence introducing family harvest history',
        ],
      },
      {
        phase: 'Phase 2: Private VIP Pre-Order Opening',
        duration: 'Weeks 3–4',
        status: 'Upcoming',
        tasks: [
          'Open 48-hour exclusive pre-order window for VIP waitlist members',
          'Deploy Meta Ads Advantage+ campaigns targeting artisanal culinary audiences',
          'Monitor initial batch inventory depletion and activate waitlist overflow',
        ],
      },
      {
        phase: 'Phase 3: Public Launch & Subscription Scaling',
        duration: 'Weeks 5–8',
        status: 'Upcoming',
        tasks: [
          'Open public orders on Shopify and activate Google Shopping campaign',
          'Launch Founder’s Harvest Club quarterly replenishment subscription offer',
          'Evaluate expanding international shipping distribution into GCC markets',
        ],
      },
    ],
  },
];
