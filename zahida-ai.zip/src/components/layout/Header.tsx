import React, { useState } from 'react';
import {
  Menu,
  Search,
  Sparkles,
  Plus,
  Bell,
  ChevronDown,
  Building2,
  CheckCircle2,
  Download,
  Database,
} from 'lucide-react';
import { useAgency } from '../../context/AgencyContext';

interface HeaderProps {
  onOpenMobile: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenMobile }) => {
  const {
    currentView,
    clients,
    selectedClientId,
    setSelectedClientId,
    setIsCommandPaletteOpen,
    setIsAskZaiOpen,
    setQuickModalType,
    approvals,
    setCurrentView,
    isDemoMode,
    setIsDemoMode,
    exportBackup,
  } = useAgency();

  const [isClientMenuOpen, setIsClientMenuOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isActionMenuOpen, setIsActionMenuOpen] = useState(false);

  const selectedClient = clients.find((c) => c.id === selectedClientId);
  const pendingApprovals = approvals.filter((a) => a.status === 'PENDING');

  return (
    <header className="sticky top-0 z-20 bg-white/95 backdrop-blur-md border-b border-slate-200/80 px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
      {/* Left: Mobile Toggle & Contextual Breadcrumb */}
      <div className="flex items-center gap-3 min-w-0">
        <button
          onClick={onOpenMobile}
          className="lg:hidden p-2 -ml-2 text-slate-500 hover:text-slate-800 rounded-lg hover:bg-slate-100"
          aria-label="Open navigation menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <nav aria-label="Breadcrumb" className="flex items-center gap-2 text-xs text-slate-500 truncate">
          <span className="font-medium text-slate-700 hidden sm:inline">Zahida Digital Marketing</span>
          <span className="text-slate-300 hidden sm:inline">/</span>
          <h1 className="font-semibold text-slate-900 text-sm truncate font-display">
            {currentView}
          </h1>
        </nav>
      </div>

      {/* Center-Right Controls */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Demo / Live Data Mode Indicator */}
        <button
          onClick={() => setIsDemoMode(!isDemoMode)}
          title={isDemoMode ? 'Click to toggle between Demo Data and Live Agency Clean Slate' : 'Currently in Live Data mode'}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold border transition-colors ${
            isDemoMode
              ? 'bg-amber-50 text-amber-800 border-amber-200/80 hover:bg-amber-100'
              : 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
          }`}
        >
          <Database className="w-3 h-3" />
          <span className="hidden sm:inline">{isDemoMode ? 'Demo Data Active' : 'Live Agency Mode'}</span>
          <span className="sm:hidden">{isDemoMode ? 'Demo' : 'Live'}</span>
        </button>

        {/* Quick Backup Trigger */}
        <button
          onClick={exportBackup}
          title="Backup and Export Agency Data (JSON)"
          className="hidden sm:flex items-center gap-1 px-2.5 py-1 rounded-lg border border-slate-200 hover:bg-slate-50 text-xs text-slate-600 transition-colors"
        >
          <Download className="w-3 h-3 text-slate-500" />
          <span>Backup</span>
        </button>

        {/* Client Scope Selector Dropdown */}
        <div className="relative">
          <button
            onClick={() => {
              setIsClientMenuOpen(!isClientMenuOpen);
              setIsNotificationsOpen(false);
              setIsActionMenuOpen(false);
            }}
            className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg border border-slate-200 bg-slate-50/70 hover:bg-white text-xs font-medium text-slate-700 transition-colors"
          >
            <Building2 className="w-3.5 h-3.5 text-slate-500" />
            <span className="max-w-[120px] sm:max-w-[160px] truncate">
              {selectedClient ? selectedClient.name : 'All Agency Clients'}
            </span>
            <ChevronDown className="w-3 h-3 text-slate-400" />
          </button>

          {isClientMenuOpen && (
            <div className="absolute right-0 mt-1.5 w-60 bg-white rounded-xl shadow-lg border border-slate-200/90 py-1.5 z-50 animate-in fade-in zoom-in-95 duration-100">
              <div className="px-3 py-1 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                Filter Workspace Scope
              </div>
              <button
                onClick={() => {
                  setSelectedClientId(null);
                  setIsClientMenuOpen(false);
                }}
                className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between hover:bg-slate-50 ${
                  selectedClientId === null ? 'font-semibold text-indigo-600 bg-indigo-50/50' : 'text-slate-700'
                }`}
              >
                <span>All Agency Clients</span>
                {selectedClientId === null && <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600" />}
              </button>
              <div className="border-t border-slate-100 my-1" />
              {clients.map((c) => (
                <button
                  key={c.id}
                  onClick={() => {
                    setSelectedClientId(c.id);
                    setIsClientMenuOpen(false);
                  }}
                  className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between hover:bg-slate-50 ${
                    selectedClientId === c.id ? 'font-semibold text-indigo-600 bg-indigo-50/50' : 'text-slate-700'
                  }`}
                >
                  <div className="truncate">
                    <div className="font-medium truncate">{c.name}</div>
                    <div className="text-[10px] text-slate-400 truncate">{c.industry}</div>
                  </div>
                  {selectedClientId === c.id && <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600 shrink-0 ml-2" />}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Global Search / Command Palette (Cmd+K) */}
        <button
          onClick={() => setIsCommandPaletteOpen(true)}
          className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-lg border border-slate-200 text-xs text-slate-400 hover:text-slate-600 hover:border-slate-300 bg-slate-50/50 hover:bg-white transition-all"
        >
          <Search className="w-3.5 h-3.5 text-slate-400" />
          <span>Search or command...</span>
          <kbd className="font-mono text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-500 border border-slate-200">
            ⌘K
          </kbd>
        </button>

        {/* Ask ZAI Quick Launch */}
        <button
          onClick={() => setIsAskZaiOpen(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-50 hover:bg-indigo-100/80 text-indigo-700 text-xs font-semibold transition-colors border border-indigo-200/60"
        >
          <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
          <span className="hidden sm:inline">Ask ZAI</span>
          <span className="sm:hidden">ZAI</span>
        </button>

        {/* Notifications & Approvals Badge Dropdown */}
        <div className="relative">
          <button
            onClick={() => {
              setIsNotificationsOpen(!isNotificationsOpen);
              setIsClientMenuOpen(false);
              setIsActionMenuOpen(false);
            }}
            className="p-2 text-slate-500 hover:text-slate-800 rounded-lg hover:bg-slate-100 relative transition-colors"
            aria-label="View notifications"
          >
            <Bell className="w-4 h-4" />
            {pendingApprovals.length > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-indigo-600 ring-2 ring-white" />
            )}
          </button>

          {isNotificationsOpen && (
            <div className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-50 animate-in fade-in zoom-in-95 duration-100">
              <div className="px-4 py-2 border-b border-slate-100 flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-900">Intelligence Notifications</span>
                <span className="text-[10px] font-mono text-slate-500">{pendingApprovals.length} pending</span>
              </div>
              <div className="max-h-72 overflow-y-auto divide-y divide-slate-50">
                {pendingApprovals.length === 0 ? (
                  <div className="p-4 text-center text-xs text-slate-500">
                    All agency actions are approved and current.
                  </div>
                ) : (
                  pendingApprovals.slice(0, 4).map((a) => (
                    <div
                      key={a.id}
                      onClick={() => {
                        setCurrentView('Approvals');
                        setIsNotificationsOpen(false);
                      }}
                      className="p-3 hover:bg-slate-50 cursor-pointer text-xs"
                    >
                      <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1">
                        <span className="font-medium text-slate-900 truncate">{a.clientName}</span>
                        <span className="font-mono text-[10px]">{a.tier} TIER</span>
                      </div>
                      <p className="text-slate-700 font-medium line-clamp-2">{a.title}</p>
                    </div>
                  ))
                )}
              </div>
              <div className="p-2 border-t border-slate-100 text-center">
                <button
                  onClick={() => {
                    setCurrentView('Approvals');
                    setIsNotificationsOpen(false);
                  }}
                  className="text-xs font-medium text-indigo-600 hover:text-indigo-800"
                >
                  View Approval Center →
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Quick Action Button */}
        <div className="relative">
          <button
            onClick={() => {
              setIsActionMenuOpen(!isActionMenuOpen);
              setIsClientMenuOpen(false);
              setIsNotificationsOpen(false);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-medium transition-colors shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">New Action</span>
          </button>

          {isActionMenuOpen && (
            <div className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5 z-50 animate-in fade-in zoom-in-95 duration-100">
              <button
                onClick={() => {
                  setQuickModalType('client');
                  setIsActionMenuOpen(false);
                }}
                className="w-full text-left px-3 py-2 text-xs text-slate-700 hover:bg-slate-50 hover:text-slate-900 flex items-center justify-between"
              >
                <span>New Client</span>
                <span className="text-[10px] text-slate-400">CRM</span>
              </button>
              <button
                onClick={() => {
                  setQuickModalType('campaign');
                  setIsActionMenuOpen(false);
                }}
                className="w-full text-left px-3 py-2 text-xs text-slate-700 hover:bg-slate-50 hover:text-slate-900 flex items-center justify-between"
              >
                <span>New Campaign</span>
                <span className="text-[10px] text-slate-400">Ads</span>
              </button>
              <button
                onClick={() => {
                  setQuickModalType('lead');
                  setIsActionMenuOpen(false);
                }}
                className="w-full text-left px-3 py-2 text-xs text-slate-700 hover:bg-slate-50 hover:text-slate-900 flex items-center justify-between"
              >
                <span>New Lead</span>
                <span className="text-[10px] text-slate-400">Pipeline</span>
              </button>
              <button
                onClick={() => {
                  setQuickModalType('content');
                  setIsActionMenuOpen(false);
                }}
                className="w-full text-left px-3 py-2 text-xs text-slate-700 hover:bg-slate-50 hover:text-slate-900 flex items-center justify-between"
              >
                <span>New Content Brief</span>
                <span className="text-[10px] text-slate-400">Studio</span>
              </button>
              <button
                onClick={() => {
                  setQuickModalType('task');
                  setIsActionMenuOpen(false);
                }}
                className="w-full text-left px-3 py-2 text-xs text-slate-700 hover:bg-slate-50 hover:text-slate-900 flex items-center justify-between"
              >
                <span>New Task</span>
                <span className="text-[10px] text-slate-400">Workflow</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
