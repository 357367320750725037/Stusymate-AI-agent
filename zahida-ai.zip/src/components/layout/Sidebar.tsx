import React from 'react';
import {
  LayoutDashboard,
  Bot,
  Compass,
  Users,
  Target,
  Megaphone,
  PenTool,
  CalendarDays,
  Search,
  BarChart3,
  FileText,
  CheckSquare,
  ShieldCheck,
  BookOpen,
  UserCheck,
  Settings,
  X,
  Workflow,
} from 'lucide-react';
import { useAgency } from '../../context/AgencyContext';
import { NavView } from '../../types';
import { ZaiLogo } from '../common/ZaiLogo';

interface SidebarProps {
  isMobileOpen: boolean;
  onCloseMobile: () => void;
}

interface NavItemConfig {
  name: NavView;
  icon: React.ComponentType<{ className?: string }>;
  badge?: number;
  badgeColor?: string;
}

export const Sidebar: React.FC<SidebarProps> = ({ isMobileOpen, onCloseMobile }) => {
  const { currentView, setCurrentView, approvals, tasks } = useAgency();

  const pendingApprovalsCount = approvals.filter((a) => a.status === 'PENDING').length;
  const urgentTasksCount = tasks.filter((t) => t.priority === 'Urgent' && t.status !== 'Completed').length;

  const navItems: NavItemConfig[] = [
    { name: 'Dashboard', icon: LayoutDashboard },
    { name: 'AI Command Center', icon: Bot },
    { name: 'Strategies', icon: Compass },
    { name: 'Clients', icon: Users },
    { name: 'Leads', icon: Target },
    { name: 'Campaigns', icon: Megaphone },
    { name: 'Content Studio', icon: PenTool },
    { name: 'Content Calendar', icon: CalendarDays },
    { name: 'SEO & Research', icon: Search },
    { name: 'Analytics', icon: BarChart3 },
    { name: 'Reports', icon: FileText },
    { name: 'Tasks', icon: CheckSquare, badge: urgentTasksCount > 0 ? urgentTasksCount : undefined, badgeColor: 'bg-amber-100 text-amber-800' },
    { name: 'Approvals', icon: ShieldCheck, badge: pendingApprovalsCount > 0 ? pendingApprovalsCount : undefined, badgeColor: 'bg-indigo-100 text-indigo-700' },
    { name: 'Automations', icon: Workflow },
    { name: 'Knowledge Base', icon: BookOpen },
    { name: 'Team', icon: UserCheck },
    { name: 'Settings', icon: Settings },
  ];

  const handleSelectNav = (view: NavView) => {
    setCurrentView(view);
    if (isMobileOpen) {
      onCloseMobile();
    }
  };

  const sidebarContent = (
    <div className="flex flex-col h-full bg-[#FFFFFF] border-r border-slate-200/80 w-[270px] select-none">
      {/* Brand Header */}
      <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
        <ZaiLogo />
        <button
          onClick={onCloseMobile}
          className="lg:hidden p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
          aria-label="Close menu"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Agency Identity Micro-strip */}
      <div className="px-5 py-2.5 bg-slate-50/70 border-b border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
        <span className="font-medium">ZAHIDA DIGITAL MARKETING</span>
        <span className="font-mono text-[10px] text-slate-400">PHASE 1</span>
      </div>

      {/* Navigation List */}
      <div className="flex-1 overflow-y-auto px-3 py-3 space-y-0.5">
        <div className="px-2 pb-1 text-[10px] font-semibold tracking-wider text-slate-400 uppercase">
          Agency OS
        </div>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.name;

          return (
            <button
              key={item.name}
              onClick={() => handleSelectNav(item.name)}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-[13px] font-medium transition-colors ${
                isActive
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/80'
              }`}
            >
              <div className="flex items-center gap-2.5 truncate">
                <Icon
                  className={`w-4 h-4 shrink-0 ${
                    isActive ? 'text-indigo-300' : 'text-slate-500'
                  }`}
                />
                <span className="truncate">{item.name}</span>
              </div>

              {item.badge !== undefined && (
                <span
                  className={`px-1.5 py-0.5 text-[10px] font-semibold rounded-md tabular-nums ${
                    isActive ? 'bg-slate-800 text-indigo-300' : item.badgeColor || 'bg-slate-100 text-slate-700'
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Zahida Owner Account Card */}
      <div className="p-3 border-t border-slate-100 bg-[#FAFAFA]">
        <div className="flex items-center justify-between p-2 rounded-lg hover:bg-white border border-transparent hover:border-slate-200 transition-all">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="relative w-8 h-8 rounded-full overflow-hidden bg-slate-200 shrink-0 ring-1 ring-slate-300">
              <img
                src="/src/assets/images/avatar_zahida_khan_1791562745547.jpg"
                alt="Zahida Khan"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
              <div className="w-full h-full flex items-center justify-center bg-indigo-900 text-white font-bold text-xs">
                ZK
              </div>
            </div>
            <div className="min-w-0">
              <div className="text-[12px] font-semibold text-slate-900 truncate">
                Zahida Khan
              </div>
              <div className="text-[10px] text-slate-500 truncate">
                Founder & Agency Director
              </div>
            </div>
          </div>
          <button
            onClick={() => handleSelectNav('Settings')}
            title="Account Settings"
            className="p-1 text-slate-400 hover:text-slate-700 rounded-md hover:bg-slate-100"
          >
            <Settings className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <aside className="hidden lg:block shrink-0 sticky top-0 h-screen z-30">
        {sidebarContent}
      </aside>

      {/* Mobile Drawer Backdrop */}
      {isMobileOpen && (
        <div
          className="lg:hidden fixed inset-0 z-40 bg-slate-950/40 backdrop-blur-xs transition-opacity"
          onClick={onCloseMobile}
        />
      )}

      {/* Mobile Drawer */}
      <div
        className={`lg:hidden fixed inset-y-0 left-0 z-50 transform transition-transform duration-200 ease-in-out ${
          isMobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {sidebarContent}
      </div>
    </>
  );
};
