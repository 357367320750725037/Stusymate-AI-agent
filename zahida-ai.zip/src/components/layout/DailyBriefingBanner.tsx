import React, { useState } from 'react';
import {
  ChevronDown,
  ChevronUp,
  Sparkles,
  ArrowRight,
  TrendingUp,
  AlertTriangle,
  Lightbulb,
} from 'lucide-react';
import { useAgency } from '../../context/AgencyContext';

export const DailyBriefingBanner: React.FC = () => {
  const { dailyBriefing, setCurrentView } = useAgency();
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div className="bg-white border border-slate-200/90 rounded-2xl p-5 mb-6 shadow-xs relative overflow-hidden transition-all">
      {/* Subtle intelligent accent glow bar */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-indigo-500 via-indigo-600 to-violet-500" />

      {/* Main Header Row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-display font-bold text-slate-950 text-sm tracking-tight">
                GOOD MORNING ZAHIDA
              </span>
              <span className="text-slate-400">·</span>
              <span className="text-xs text-slate-500">{dailyBriefing.date}</span>
            </div>
            <p className="text-xs text-slate-600 mt-0.5">
              ZAI Daily Intelligence Briefing — 5 items priority attention
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={() => setCurrentView('Approvals')}
            className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 px-2.5 py-1 rounded-lg hover:bg-indigo-50 transition-colors"
          >
            <span>{dailyBriefing.pendingApprovalsCount} Approvals Waiting</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors"
            title={isExpanded ? 'Collapse briefing' : 'Expand full briefing'}
          >
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Today's Critical Priorities Strip */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-4">
        {/* Priority 1: Task */}
        <div
          onClick={() => setCurrentView('Campaigns')}
          className="p-3 rounded-xl bg-slate-50/70 hover:bg-slate-50 border border-slate-100 cursor-pointer transition-colors"
        >
          <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
            01. Campaign Alert
          </div>
          <div className="text-xs font-medium text-slate-800 line-clamp-2">
            {dailyBriefing.campaignAlert}
          </div>
        </div>

        {/* Priority 2: Client Issue */}
        <div
          onClick={() => setCurrentView('Clients')}
          className="p-3 rounded-xl bg-slate-50/70 hover:bg-slate-50 border border-slate-100 cursor-pointer transition-colors"
        >
          <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
            02. Client Health Attention
          </div>
          <div className="text-xs font-medium text-slate-800 line-clamp-2">
            {dailyBriefing.importantClientIssue}
          </div>
        </div>

        {/* Priority 3: Hot Lead */}
        <div
          onClick={() => setCurrentView('Leads')}
          className="p-3 rounded-xl bg-slate-50/70 hover:bg-slate-50 border border-slate-100 cursor-pointer transition-colors"
        >
          <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
            03. Pipeline Opportunity
          </div>
          <div className="text-xs font-medium text-slate-800 line-clamp-2">
            {dailyBriefing.hotLeadSummary}
          </div>
        </div>
      </div>

      {/* Expanded Deep-Dive (Yesterday's Wins, Issues, and Opportunities) */}
      {isExpanded && (
        <div className="mt-4 pt-4 border-t border-slate-100 grid grid-cols-1 md:grid-cols-3 gap-4 text-xs animate-in fade-in duration-200">
          {/* Wins */}
          <div className="p-3.5 rounded-xl bg-emerald-50/50 border border-emerald-100/80">
            <div className="flex items-center gap-1.5 font-semibold text-emerald-900 mb-2">
              <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
              <span>Yesterday's Wins</span>
            </div>
            <ul className="space-y-1.5 text-slate-700">
              {dailyBriefing.yesterdaysWins.map((win, idx) => (
                <li key={idx} className="flex items-start gap-1.5">
                  <span className="text-emerald-500 font-bold shrink-0">·</span>
                  <span>{win}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Issues */}
          <div className="p-3.5 rounded-xl bg-amber-50/50 border border-amber-100/80">
            <div className="flex items-center gap-1.5 font-semibold text-amber-900 mb-2">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
              <span>Yesterday's Bottlenecks</span>
            </div>
            <ul className="space-y-1.5 text-slate-700">
              {dailyBriefing.yesterdaysProblems.map((prob, idx) => (
                <li key={idx} className="flex items-start gap-1.5">
                  <span className="text-amber-500 font-bold shrink-0">·</span>
                  <span>{prob}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Opportunities */}
          <div className="p-3.5 rounded-xl bg-indigo-50/50 border border-indigo-100/80">
            <div className="flex items-center gap-1.5 font-semibold text-indigo-900 mb-2">
              <Lightbulb className="w-3.5 h-3.5 text-indigo-600" />
              <span>Today's Opportunities</span>
            </div>
            <ul className="space-y-1.5 text-slate-700">
              {dailyBriefing.todaysOpportunities.map((opp, idx) => (
                <li key={idx} className="flex items-start gap-1.5">
                  <span className="text-indigo-500 font-bold shrink-0">·</span>
                  <span>{opp}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};
