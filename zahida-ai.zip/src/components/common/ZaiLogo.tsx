import React from 'react';

interface ZaiLogoProps {
  collapsed?: boolean;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const ZaiLogo: React.FC<ZaiLogoProps> = ({ collapsed = false, className = '', size = 'md' }) => {
  const iconSize = size === 'sm' ? 24 : size === 'lg' ? 36 : 28;

  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* Custom Distinctive ZAI Monogram / Neural Node Icon */}
      <div
        className="relative flex items-center justify-center shrink-0 rounded-xl bg-slate-950 text-white shadow-sm ring-1 ring-slate-900/10 overflow-hidden"
        style={{ width: iconSize + 10, height: iconSize + 10 }}
      >
        {/* Subtle geometric gradient backdrop */}
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/30 via-slate-900 to-violet-950" />
        
        {/* Distinctive Vector Emblem */}
        <svg
          width={iconSize}
          height={iconSize}
          viewBox="0 0 32 32"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="relative z-10"
        >
          {/* Outer hexagonal precision lattice */}
          <path
            d="M16 3L27 9.5V22.5L16 29L5 22.5V9.5L16 3Z"
            stroke="rgba(255,255,255,0.25)"
            strokeWidth="1.2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          {/* Distinctive stylized 'Z' facet paths */}
          <path
            d="M9 11H23L11 21H23"
            stroke="#818CF8"
            strokeWidth="2.4"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          {/* Intelligent central nexus node */}
          <circle cx="16" cy="16" r="2.2" fill="#FFFFFF" />
          <path
            d="M16 11V13M16 19V21M11 16H13M19 16H21"
            stroke="rgba(255,255,255,0.6)"
            strokeWidth="1.2"
            strokeLinecap="round"
          />
        </svg>
      </div>

      {!collapsed && (
        <div className="flex flex-col min-w-0">
          <div className="flex items-center gap-1.5 leading-none">
            <span className="font-display font-bold tracking-tight text-slate-950 text-[15px]">
              ZAHIDA
            </span>
            <span className="font-display font-semibold tracking-wider text-indigo-600 text-[14px]">
              AI
            </span>
          </div>
          <span className="text-[10px] tracking-wide text-slate-600 font-medium truncate mt-0.5">
            By Zahida Digital Marketing
          </span>
        </div>
      )}
    </div>
  );
};
