import React, { useState, useEffect } from 'react';
import {
  Search,
  X,
  LayoutDashboard,
  Bot,
  Compass,
  Users,
  Target,
  Megaphone,
  PenTool,
  CalendarDays,
  Search as SearchIcon,
  BarChart3,
  FileText,
  CheckSquare,
  ShieldCheck,
  Workflow,
  BookOpen,
  UserCheck,
  Settings,
  Plus,
  Sparkles,
} from 'lucide-react';
import { useAgency } from '../../context/AgencyContext';
import { NavView } from '../../types';

export const CommandPalette: React.FC = () => {
  const {
    isCommandPaletteOpen,
    setIsCommandPaletteOpen,
    setCurrentView,
    clients,
    leads,
    setSelectedClientId,
    setQuickModalType,
    setIsAskZaiOpen,
  } = useAgency();

  const [query, setQuery] = useState('');

  useEffect(() => {
    if (isCommandPaletteOpen) {
      setQuery('');
    }
  }, [isCommandPaletteOpen]);

  if (!isCommandPaletteOpen) return null;

  const navigationCommands: Array<{ name: NavView; icon: any; category: string }> = [
    { name: 'Dashboard', icon: LayoutDashboard, category: 'Navigation' },
    { name: 'AI Command Center', icon: Bot, category: 'Navigation' },
    { name: 'Strategies', icon: Compass, category: 'Navigation' },
    { name: 'Clients', icon: Users, category: 'Navigation' },
    { name: 'Leads', icon: Target, category: 'Navigation' },
    { name: 'Campaigns', icon: Megaphone, category: 'Navigation' },
    { name: 'Content Studio', icon: PenTool, category: 'Navigation' },
    { name: 'Content Calendar', icon: CalendarDays, category: 'Navigation' },
    { name: 'SEO & Research', icon: SearchIcon, category: 'Navigation' },
    { name: 'Analytics', icon: BarChart3, category: 'Navigation' },
    { name: 'Reports', icon: FileText, category: 'Navigation' },
    { name: 'Tasks', icon: CheckSquare, category: 'Navigation' },
    { name: 'Approvals', icon: ShieldCheck, category: 'Navigation' },
    { name: 'Automations', icon: Workflow, category: 'Navigation' },
    { name: 'Knowledge Base', icon: BookOpen, category: 'Navigation' },
    { name: 'Team', icon: UserCheck, category: 'Navigation' },
    { name: 'Settings', icon: Settings, category: 'Navigation' },
  ];

  const filteredNav = navigationCommands.filter((c) =>
    c.name.toLowerCase().includes(query.toLowerCase())
  );

  const filteredClients = clients.filter(
    (c) =>
      c.name.toLowerCase().includes(query.toLowerCase()) ||
      c.industry.toLowerCase().includes(query.toLowerCase())
  );

  const filteredLeads = leads.filter(
    (l) =>
      l.name.toLowerCase().includes(query.toLowerCase()) ||
      l.company.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4 bg-slate-950/40 backdrop-blur-xs">
      <div
        className="fixed inset-0"
        onClick={() => setIsCommandPaletteOpen(false)}
      />

      <div className="relative w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden z-10 animate-in fade-in zoom-in-95 duration-100">
        {/* Search Input Bar */}
        <div className="flex items-center px-4 py-3.5 border-b border-slate-100 gap-3">
          <Search className="w-4 h-4 text-slate-400 shrink-0" />
          <input
            type="text"
            autoFocus
            placeholder="Type a command, client name, or lead..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full text-sm bg-transparent outline-hidden text-slate-900 placeholder:text-slate-400 font-sans"
          />
          <button
            onClick={() => setIsCommandPaletteOpen(false)}
            className="p-1 text-slate-400 hover:text-slate-600 rounded-md"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Results List */}
        <div className="max-h-96 overflow-y-auto p-2 space-y-3">
          {/* AI Quick Actions */}
          <div>
            <div className="px-3 py-1 text-[10px] font-semibold tracking-wider text-slate-400 uppercase">
              AI Command Actions
            </div>
            <button
              onClick={() => {
                setIsCommandPaletteOpen(false);
                setIsAskZaiOpen(true);
              }}
              className="w-full text-left px-3 py-2 rounded-lg text-xs hover:bg-indigo-50 text-indigo-700 font-medium flex items-center justify-between"
            >
              <div className="flex items-center gap-2">
                <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                <span>Ask ZAI Chief Marketing Intelligence...</span>
              </div>
              <span className="font-mono text-[10px] text-indigo-400">Action</span>
            </button>
          </div>

          {/* Quick Create Actions */}
          <div>
            <div className="px-3 py-1 text-[10px] font-semibold tracking-wider text-slate-400 uppercase">
              Quick Create
            </div>
            <div className="grid grid-cols-2 gap-1 px-1">
              <button
                onClick={() => {
                  setIsCommandPaletteOpen(false);
                  setQuickModalType('campaign');
                }}
                className="text-left px-2.5 py-1.5 rounded-lg text-xs hover:bg-slate-50 text-slate-700 flex items-center gap-2"
              >
                <Plus className="w-3 h-3 text-slate-400" />
                <span>New Campaign</span>
              </button>
              <button
                onClick={() => {
                  setIsCommandPaletteOpen(false);
                  setQuickModalType('client');
                }}
                className="text-left px-2.5 py-1.5 rounded-lg text-xs hover:bg-slate-50 text-slate-700 flex items-center gap-2"
              >
                <Plus className="w-3 h-3 text-slate-400" />
                <span>New Client</span>
              </button>
              <button
                onClick={() => {
                  setIsCommandPaletteOpen(false);
                  setQuickModalType('lead');
                }}
                className="text-left px-2.5 py-1.5 rounded-lg text-xs hover:bg-slate-50 text-slate-700 flex items-center gap-2"
              >
                <Plus className="w-3 h-3 text-slate-400" />
                <span>New Lead</span>
              </button>
              <button
                onClick={() => {
                  setIsCommandPaletteOpen(false);
                  setQuickModalType('content');
                }}
                className="text-left px-2.5 py-1.5 rounded-lg text-xs hover:bg-slate-50 text-slate-700 flex items-center gap-2"
              >
                <Plus className="w-3 h-3 text-slate-400" />
                <span>New Content Brief</span>
              </button>
            </div>
          </div>

          {/* Navigation Views */}
          {filteredNav.length > 0 && (
            <div>
              <div className="px-3 py-1 text-[10px] font-semibold tracking-wider text-slate-400 uppercase">
                Views
              </div>
              {filteredNav.slice(0, 5).map((cmd) => {
                const Icon = cmd.icon;
                return (
                  <button
                    key={cmd.name}
                    onClick={() => {
                      setCurrentView(cmd.name);
                      setIsCommandPaletteOpen(false);
                    }}
                    className="w-full text-left px-3 py-2 rounded-lg text-xs hover:bg-slate-50 text-slate-700 flex items-center justify-between"
                  >
                    <div className="flex items-center gap-2.5">
                      <Icon className="w-3.5 h-3.5 text-slate-400" />
                      <span>{cmd.name}</span>
                    </div>
                    <span className="text-[10px] text-slate-400">View</span>
                  </button>
                );
              })}
            </div>
          )}

          {/* Client Matches */}
          {filteredClients.length > 0 && (
            <div>
              <div className="px-3 py-1 text-[10px] font-semibold tracking-wider text-slate-400 uppercase">
                Clients
              </div>
              {filteredClients.slice(0, 4).map((client) => (
                <button
                  key={client.id}
                  onClick={() => {
                    setSelectedClientId(client.id);
                    setCurrentView('Clients');
                    setIsCommandPaletteOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 rounded-lg text-xs hover:bg-slate-50 text-slate-700 flex items-center justify-between"
                >
                  <div>
                    <div className="font-medium text-slate-900">{client.name}</div>
                    <div className="text-[10px] text-slate-400">{client.industry}</div>
                  </div>
                  <span className="font-mono text-[10px] text-indigo-600">
                    ${client.monthlyRetainer}/mo
                  </span>
                </button>
              ))}
            </div>
          )}

          {/* Lead Matches */}
          {filteredLeads.length > 0 && (
            <div>
              <div className="px-3 py-1 text-[10px] font-semibold tracking-wider text-slate-400 uppercase">
                Leads & Prospects
              </div>
              {filteredLeads.slice(0, 3).map((lead) => (
                <button
                  key={lead.id}
                  onClick={() => {
                    setCurrentView('Leads');
                    setIsCommandPaletteOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 rounded-lg text-xs hover:bg-slate-50 text-slate-700 flex items-center justify-between"
                >
                  <div>
                    <div className="font-medium text-slate-900">{lead.name} · {lead.company}</div>
                    <div className="text-[10px] text-slate-400">{lead.status} · {lead.scoreTier} ({lead.score}/100)</div>
                  </div>
                  <span className="font-mono text-[10px] text-emerald-600">
                    Est ${lead.budgetEst}/mo
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Footer shortcuts */}
        <div className="px-4 py-2 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
          <span>Navigate with ⌘K</span>
          <span>Esc to close</span>
        </div>
      </div>
    </div>
  );
};
