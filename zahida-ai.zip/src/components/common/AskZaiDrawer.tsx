import React, { useState } from 'react';
import {
  X,
  Sparkles,
  Send,
  Loader2,
  Bot,
  User,
  ShieldCheck,
  Building2,
  Trash2,
} from 'lucide-react';
import { useAgency } from '../../context/AgencyContext';

export const AskZaiDrawer: React.FC = () => {
  const {
    isAskZaiOpen,
    setIsAskZaiOpen,
    chatMessages,
    isAiThinking,
    sendAiMessage,
    clearChat,
    clients,
    selectedClientId,
    setSelectedClientId,
    setCurrentView,
  } = useAgency();

  const [inputPrompt, setInputPrompt] = useState('');
  const [activeAgent, setActiveAgent] = useState('ZAI — Chief Marketing Intelligence');

  if (!isAskZaiOpen) return null;

  const quickPrompts = [
    'ZAI, aaj meri company mein kya important hai?',
    'Show me everything that needs my attention.',
    'Analyze Lumina Skin Co CPA increase.',
    'Create next month content strategy for Nordic Roastery.',
    'Which leads are hot right now?',
    'Prepare the monthly executive report.',
  ];

  const agentOptions = [
    'ZAI — Chief Marketing Intelligence',
    'Strategy Agent',
    'Content Agent',
    'Ads Agent',
    'Research Agent',
    'SEO Agent',
    'Analytics Agent',
    'Lead Agent',
    'Reporting Agent',
  ];

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputPrompt.trim() || isAiThinking) return;
    const promptToSend = inputPrompt;
    setInputPrompt('');
    sendAiMessage(promptToSend, activeAgent, selectedClientId || undefined);
  };

  const handleSelectQuickPrompt = (prompt: string) => {
    setInputPrompt('');
    sendAiMessage(prompt, activeAgent, selectedClientId || undefined);
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/40 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        className="fixed inset-0"
        onClick={() => setIsAskZaiOpen(false)}
      />

      <div className="relative w-full max-w-xl bg-white h-full shadow-2xl flex flex-col z-10 animate-in slide-in-from-right duration-200">
        {/* Drawer Header */}
        <div className="px-5 py-4 border-b border-slate-200/90 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-lg bg-indigo-600 text-white shadow-xs">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-display font-bold text-slate-900 text-sm">
                  ASK ZAI
                </span>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-700 font-semibold border border-indigo-100">
                  Chief Marketing Intelligence
                </span>
              </div>
              <p className="text-[11px] text-slate-500">
                Your intelligent digital marketing partner for Zahida Digital Marketing
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={clearChat}
              title="Clear conversation"
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
            >
              <Trash2 className="w-4 h-4" />
            </button>
            <button
              onClick={() => setIsAskZaiOpen(false)}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Client Memory & Sub-Agent Bar */}
        <div className="px-4 py-2.5 bg-slate-50 border-b border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs">
          {/* Agent Selector */}
          <div className="flex items-center gap-1.5">
            <Bot className="w-3.5 h-3.5 text-slate-500" />
            <select
              value={activeAgent}
              onChange={(e) => setActiveAgent(e.target.value)}
              className="bg-white border border-slate-200 rounded-md px-2 py-1 text-xs font-medium text-slate-700 outline-hidden"
            >
              {agentOptions.map((a) => (
                <option key={a} value={a}>
                  {a}
                </option>
              ))}
            </select>
          </div>

          {/* Client Memory Context */}
          <div className="flex items-center gap-1.5">
            <Building2 className="w-3.5 h-3.5 text-slate-500" />
            <select
              value={selectedClientId || ''}
              onChange={(e) => setSelectedClientId(e.target.value ? e.target.value : null)}
              className="bg-white border border-slate-200 rounded-md px-2 py-1 text-xs font-medium text-slate-700 outline-hidden max-w-[170px] truncate"
            >
              <option value="">Full Agency Context</option>
              {clients.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Message Thread */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {chatMessages.map((msg) => (
            <div
              key={msg.id}
              className={`flex gap-3 text-xs ${
                msg.sender === 'zahida' ? 'justify-end' : 'justify-start'
              }`}
            >
              {msg.sender === 'zai' && (
                <div className="w-7 h-7 rounded-lg bg-indigo-600 text-white flex items-center justify-center shrink-0 mt-0.5">
                  <Sparkles className="w-3.5 h-3.5" />
                </div>
              )}

              <div
                className={`max-w-[85%] rounded-2xl p-3.5 space-y-2 ${
                  msg.sender === 'zahida'
                    ? 'bg-slate-900 text-white rounded-br-xs'
                    : 'bg-slate-50 border border-slate-200/80 text-slate-800 rounded-bl-xs'
                }`}
              >
                {/* Agent Tag */}
                {msg.sender === 'zai' && (
                  <div className="flex items-center justify-between text-[10px] text-slate-600 pb-1 border-b border-slate-200/60 font-medium">
                    <span>{msg.agentName || 'ZAI'}</span>
                    <span className="font-mono">{msg.timestamp}</span>
                  </div>
                )}

                {/* Message Body */}
                <div className="whitespace-pre-wrap leading-relaxed text-slate-800 text-[13px]">
                  {msg.text}
                </div>

                {/* Tool trace indicator */}
                {msg.toolsCalled && msg.toolsCalled.length > 0 && (
                  <div className="pt-2 border-t border-slate-200/50 flex flex-wrap gap-1 text-[10px] font-mono text-slate-600">
                    <span className="font-semibold">Tools:</span>
                    {msg.toolsCalled.map((t, idx) => (
                      <span key={idx} className="bg-white/80 px-1 py-0.5 rounded border border-slate-200">
                        {t}
                      </span>
                    ))}
                  </div>
                )}

                {/* Suggested Followups */}
                {msg.suggestedActions && (
                  <div className="pt-2 flex flex-wrap gap-1.5">
                    {msg.suggestedActions.map((action, i) => (
                      <button
                        key={i}
                        onClick={() => {
                          if (action.includes('Approval')) {
                            setCurrentView('Approvals');
                            setIsAskZaiOpen(false);
                          } else {
                            handleSelectQuickPrompt(action);
                          }
                        }}
                        className="px-2 py-1 rounded bg-white hover:bg-slate-100 text-slate-700 text-[11px] font-medium border border-slate-200 transition-colors"
                      >
                        {action} →
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {msg.sender === 'zahida' && (
                <div className="w-7 h-7 rounded-lg bg-slate-900 text-white flex items-center justify-center shrink-0 mt-0.5">
                  <User className="w-3.5 h-3.5" />
                </div>
              )}
            </div>
          ))}

          {isAiThinking && (
            <div className="flex items-center gap-2 p-3 bg-slate-50 rounded-xl text-xs text-indigo-700 border border-indigo-100">
              <Loader2 className="w-4 h-4 animate-spin text-indigo-600" />
              <span>ZAI is analyzing agency data and synthesizing response...</span>
            </div>
          )}
        </div>

        {/* Quick Prompts Strip */}
        <div className="p-2 border-t border-slate-100 bg-slate-50/70 overflow-x-auto whitespace-nowrap scrollbar-none flex gap-1.5 text-[11px]">
          {quickPrompts.map((qp, idx) => (
            <button
              key={idx}
              onClick={() => handleSelectQuickPrompt(qp)}
              className="px-2.5 py-1 bg-white hover:bg-indigo-50 hover:text-indigo-700 text-slate-600 rounded-md border border-slate-200 transition-colors shrink-0"
            >
              {qp}
            </button>
          ))}
        </div>

        {/* Prompt Input Form */}
        <form onSubmit={handleSubmit} className="p-3 border-t border-slate-200 bg-white">
          <div className="flex items-center gap-2 bg-slate-50 rounded-xl border border-slate-200 px-3 py-2 focus-within:border-indigo-500 focus-within:ring-1 focus-within:ring-indigo-500 transition-all">
            <input
              type="text"
              placeholder="Ask ZAI anything about your marketing campaigns, clients, or strategies..."
              value={inputPrompt}
              onChange={(e) => setInputPrompt(e.target.value)}
              className="flex-1 text-xs bg-transparent outline-hidden text-slate-900 placeholder:text-slate-400 font-sans"
            />
            <button
              type="submit"
              disabled={!inputPrompt.trim() || isAiThinking}
              className="p-1.5 bg-indigo-600 text-white rounded-lg disabled:opacity-40 hover:bg-indigo-700 transition-colors shadow-xs"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="mt-1.5 flex items-center justify-between text-[10px] text-slate-500 px-1">
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-emerald-600" />
              Human-in-the-loop: High-impact actions require Approval Center authorization
            </span>
            <span>Enter to send</span>
          </div>
        </form>
      </div>
    </div>
  );
};
