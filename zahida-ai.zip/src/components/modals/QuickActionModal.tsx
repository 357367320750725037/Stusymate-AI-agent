import React, { useState } from 'react';
import { X, Plus, Sparkles, Building2, Megaphone, Target, CheckSquare, PenTool } from 'lucide-react';
import { useAgency } from '../../context/AgencyContext';

export const QuickActionModal: React.FC = () => {
  const {
    quickModalType,
    setQuickModalType,
    clients,
    addClient,
    addCampaign,
    addLead,
    addTask,
    addContentItem,
  } = useAgency();

  // Client form
  const [clientForm, setClientForm] = useState({
    name: '',
    industry: '',
    contactPerson: '',
    email: '',
    phone: '',
    website: '',
    monthlyRetainer: 5000,
    monthlyAdSpend: 15000,
    tier: 'Growth' as const,
    status: 'Active' as const,
    assignedLead: 'Ayesha Tariq',
    tags: ['DTC', 'Meta Ads'],
    memory: {
      industry: '',
      targetAudience: 'Modern consumers aged 25-45',
      location: 'Global / North America',
      primaryGoal: 'Scale qualified customer conversions',
      mainPlatform: 'Meta Ads',
      secondaryPlatform: 'Google Search',
      brandTone: 'Premium, authoritative, confident',
      brandColors: ['#0F172A', '#6366F1'],
      monthlyAdBudget: 15000,
      currency: 'USD',
      keyDifferentiators: ['High quality craftsmanship', 'Fast delivery'],
      competitors: ['Market Leader A', 'Direct Competitor B'],
      prohibitedWords: ['Cheap', 'Discount code'],
      notes: 'New client onboarded during Phase 1 sprint.',
    },
  });

  // Campaign form
  const [campaignForm, setCampaignForm] = useState({
    name: '',
    clientId: clients[0]?.id || '',
    clientName: clients[0]?.name || '',
    platform: 'Meta Ads' as const,
    objective: 'Conversions' as const,
    status: 'Active' as const,
    monthlyBudget: 10000,
  });

  // Lead form
  const [leadForm, setLeadForm] = useState({
    name: '',
    company: '',
    email: '',
    phone: '',
    source: 'Referral' as const,
    serviceInterest: 'Performance Media Buying & Creative Studio',
    budgetEst: 6500,
    status: 'New' as const,
    nextAction: 'Schedule 30-min strategy discovery with Zahida',
    notes: 'Inbound intake received.',
  });

  // Task form
  const [taskForm, setTaskForm] = useState({
    title: '',
    description: '',
    priority: 'High' as const,
    status: 'To Do' as const,
    assignee: 'Ayesha Tariq',
    deadline: new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0],
    clientId: clients[0]?.id || '',
    clientName: clients[0]?.name || '',
  });

  // Content form
  const [contentForm, setContentForm] = useState({
    title: '',
    clientId: clients[0]?.id || '',
    clientName: clients[0]?.name || '',
    platform: 'Instagram' as const,
    contentType: 'Reel' as const,
    hook: '',
    caption: '',
    body: '',
    cta: 'Link in bio to shop.',
    hashtags: ['#DigitalMarketing', '#Growth'],
    creativeBrief: 'Clean minimalist aesthetic.',
    scheduledDate: new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0],
    scheduledTime: '11:00 AM',
    assignedTo: 'Sara Malik',
  });

  if (!quickModalType) return null;

  const handleClientSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientForm.name) return;
    addClient({
      ...clientForm,
      memory: {
        ...clientForm.memory,
        industry: clientForm.industry,
      },
    });
    setQuickModalType(null);
  };

  const handleCampaignSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const client = clients.find((c) => c.id === campaignForm.clientId) || clients[0];
    addCampaign({
      ...campaignForm,
      clientName: client ? client.name : 'Agency Client',
    });
    setQuickModalType(null);
  };

  const handleLeadSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addLead(leadForm);
    setQuickModalType(null);
  };

  const handleTaskSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const client = clients.find((c) => c.id === taskForm.clientId);
    addTask({
      ...taskForm,
      clientName: client?.name,
    });
    setQuickModalType(null);
  };

  const handleContentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const client = clients.find((c) => c.id === contentForm.clientId) || clients[0];
    addContentItem({
      ...contentForm,
      clientName: client ? client.name : 'Agency Client',
    });
    setQuickModalType(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/40 backdrop-blur-xs animate-in fade-in duration-100">
      <div
        className="fixed inset-0"
        onClick={() => setQuickModalType(null)}
      />

      <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden z-10 animate-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="font-display font-bold text-slate-900 text-sm">
              {quickModalType === 'client' && 'Onboard New Agency Client'}
              {quickModalType === 'campaign' && 'Launch New Marketing Campaign'}
              {quickModalType === 'lead' && 'Add Prospective Lead to CRM'}
              {quickModalType === 'task' && 'Create Operational Task'}
              {quickModalType === 'content' && 'Draft New Content Brief'}
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 font-semibold uppercase">
              {quickModalType}
            </span>
          </div>

          <button
            onClick={() => setQuickModalType(null)}
            className="p-1 text-slate-400 hover:text-slate-600 rounded-md"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-5 max-h-[80vh] overflow-y-auto text-xs space-y-4">
          {/* CLIENT FORM */}
          {quickModalType === 'client' && (
            <form onSubmit={handleClientSubmit} className="space-y-3">
              <div>
                <label className="block text-slate-500 font-medium mb-1">Company / Brand Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Lumina Skin Co"
                  value={clientForm.name}
                  onChange={(e) => setClientForm({ ...clientForm, name: e.target.value })}
                  className="w-full border border-slate-200 rounded-lg p-2.5 outline-hidden focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-500 font-medium mb-1">Industry</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Luxury Skincare"
                    value={clientForm.industry}
                    onChange={(e) => setClientForm({ ...clientForm, industry: e.target.value })}
                    className="w-full border border-slate-200 rounded-lg p-2.5 outline-hidden focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-500 font-medium mb-1">Key Contact Person</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Sophie Vance"
                    value={clientForm.contactPerson}
                    onChange={(e) => setClientForm({ ...clientForm, contactPerson: e.target.value })}
                    className="w-full border border-slate-200 rounded-lg p-2.5 outline-hidden focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-500 font-medium mb-1">Monthly Retainer ($)</label>
                  <input
                    type="number"
                    value={clientForm.monthlyRetainer}
                    onChange={(e) => setClientForm({ ...clientForm, monthlyRetainer: Number(e.target.value) })}
                    className="w-full border border-slate-200 rounded-lg p-2.5 outline-hidden focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-500 font-medium mb-1">Estimated Ad Spend ($)</label>
                  <input
                    type="number"
                    value={clientForm.monthlyAdSpend}
                    onChange={(e) => setClientForm({ ...clientForm, monthlyAdSpend: Number(e.target.value) })}
                    className="w-full border border-slate-200 rounded-lg p-2.5 outline-hidden focus:border-indigo-500"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-xl mt-3 shadow-xs"
              >
                Save Client to CRM
              </button>
            </form>
          )}

          {/* CAMPAIGN FORM */}
          {quickModalType === 'campaign' && (
            <form onSubmit={handleCampaignSubmit} className="space-y-3">
              <div>
                <label className="block text-slate-500 font-medium mb-1">Campaign Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Q4 Barrier Serum Advantage+ Scale"
                  value={campaignForm.name}
                  onChange={(e) => setCampaignForm({ ...campaignForm, name: e.target.value })}
                  className="w-full border border-slate-200 rounded-lg p-2.5 outline-hidden focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-500 font-medium mb-1">Select Client</label>
                  <select
                    value={campaignForm.clientId}
                    onChange={(e) => setCampaignForm({ ...campaignForm, clientId: e.target.value })}
                    className="w-full border border-slate-200 rounded-lg p-2.5 outline-hidden"
                  >
                    {clients.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-500 font-medium mb-1">Advertising Platform</label>
                  <select
                    value={campaignForm.platform}
                    onChange={(e) => setCampaignForm({ ...campaignForm, platform: e.target.value as any })}
                    className="w-full border border-slate-200 rounded-lg p-2.5 outline-hidden"
                  >
                    <option value="Meta Ads">Meta Ads</option>
                    <option value="Google Ads">Google Ads</option>
                    <option value="TikTok Ads">TikTok Ads</option>
                    <option value="Email">Email Marketing Flow</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-500 font-medium mb-1">Monthly Budget Allocation ($)</label>
                <input
                  type="number"
                  value={campaignForm.monthlyBudget}
                  onChange={(e) => setCampaignForm({ ...campaignForm, monthlyBudget: Number(e.target.value) })}
                  className="w-full border border-slate-200 rounded-lg p-2.5 outline-hidden focus:border-indigo-500"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-xl mt-3 shadow-xs"
              >
                Register Campaign
              </button>
            </form>
          )}

          {/* LEAD FORM */}
          {quickModalType === 'lead' && (
            <form onSubmit={handleLeadSubmit} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-500 font-medium mb-1">Contact Name</label>
                  <input
                    type="text"
                    required
                    value={leadForm.name}
                    onChange={(e) => setLeadForm({ ...leadForm, name: e.target.value })}
                    className="w-full border border-slate-200 rounded-lg p-2.5 outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 font-medium mb-1">Company / Brand</label>
                  <input
                    type="text"
                    required
                    value={leadForm.company}
                    onChange={(e) => setLeadForm({ ...leadForm, company: e.target.value })}
                    className="w-full border border-slate-200 rounded-lg p-2.5 outline-hidden"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-500 font-medium mb-1">Email</label>
                  <input
                    type="email"
                    required
                    value={leadForm.email}
                    onChange={(e) => setLeadForm({ ...leadForm, email: e.target.value })}
                    className="w-full border border-slate-200 rounded-lg p-2.5 outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 font-medium mb-1">Est. Retainer Budget ($/mo)</label>
                  <input
                    type="number"
                    value={leadForm.budgetEst}
                    onChange={(e) => setLeadForm({ ...leadForm, budgetEst: Number(e.target.value) })}
                    className="w-full border border-slate-200 rounded-lg p-2.5 outline-hidden"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-xl mt-3 shadow-xs"
              >
                Add Lead & Calculate AI Score
              </button>
            </form>
          )}

          {/* TASK FORM */}
          {quickModalType === 'task' && (
            <form onSubmit={handleTaskSubmit} className="space-y-3">
              <div>
                <label className="block text-slate-500 font-medium mb-1">Task Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Audit Google Ads negative keywords"
                  value={taskForm.title}
                  onChange={(e) => setTaskForm({ ...taskForm, title: e.target.value })}
                  className="w-full border border-slate-200 rounded-lg p-2.5 outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-500 font-medium mb-1">Client</label>
                  <select
                    value={taskForm.clientId}
                    onChange={(e) => setTaskForm({ ...taskForm, clientId: e.target.value })}
                    className="w-full border border-slate-200 rounded-lg p-2.5 outline-hidden"
                  >
                    {clients.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-slate-500 font-medium mb-1">Assignee</label>
                  <select
                    value={taskForm.assignee}
                    onChange={(e) => setTaskForm({ ...taskForm, assignee: e.target.value })}
                    className="w-full border border-slate-200 rounded-lg p-2.5 outline-hidden"
                  >
                    <option value="Ayesha Tariq">Ayesha Tariq (Sr Media Buyer)</option>
                    <option value="Bilal Farooq">Bilal Farooq (SEO Lead)</option>
                    <option value="Sara Malik">Sara Malik (Content Specialist)</option>
                    <option value="Tariq Aziz">Tariq Aziz (Creative Strategist)</option>
                    <option value="Zahida Khan">Zahida Khan (Director)</option>
                  </select>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-xl mt-3 shadow-xs"
              >
                Create Task
              </button>
            </form>
          )}

          {/* CONTENT FORM */}
          {quickModalType === 'content' && (
            <form onSubmit={handleContentSubmit} className="space-y-3">
              <div>
                <label className="block text-slate-500 font-medium mb-1">Content Title / Subject</label>
                <input
                  type="text"
                  required
                  value={contentForm.title}
                  onChange={(e) => setContentForm({ ...contentForm, title: e.target.value })}
                  className="w-full border border-slate-200 rounded-lg p-2.5 outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-500 font-medium mb-1">Client</label>
                  <select
                    value={contentForm.clientId}
                    onChange={(e) => setContentForm({ ...contentForm, clientId: e.target.value })}
                    className="w-full border border-slate-200 rounded-lg p-2.5 outline-hidden"
                  >
                    {clients.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-slate-500 font-medium mb-1">Platform</label>
                  <select
                    value={contentForm.platform}
                    onChange={(e) => setContentForm({ ...contentForm, platform: e.target.value as any })}
                    className="w-full border border-slate-200 rounded-lg p-2.5 outline-hidden"
                  >
                    <option value="Instagram">Instagram</option>
                    <option value="LinkedIn">LinkedIn</option>
                    <option value="TikTok">TikTok</option>
                    <option value="Facebook">Facebook</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-500 font-medium mb-1">Caption / Copy</label>
                <textarea
                  rows={3}
                  value={contentForm.caption}
                  onChange={(e) => setContentForm({ ...contentForm, caption: e.target.value })}
                  className="w-full border border-slate-200 rounded-lg p-2.5 outline-hidden resize-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-xl mt-3 shadow-xs"
              >
                Send to Content Queue & Approvals
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
