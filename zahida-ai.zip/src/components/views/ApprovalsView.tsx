import React, { useState } from 'react';
import {
  ShieldCheck,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Lock,
  Sparkles,
  Eye,
  FileCheck,
  Clock,
  UserCheck,
} from 'lucide-react';
import { useAgency } from '../../context/AgencyContext';
import { ApprovalItem } from '../../types';

export const ApprovalsView: React.FC = () => {
  const { approvals, handleApproval } = useAgency();

  const [filterTier, setFilterTier] = useState<string>('All');
  const [filterStatus, setFilterStatus] = useState<string>('PENDING');
  const [inspectItem, setInspectItem] = useState<ApprovalItem | null>(null);

  const filteredApprovals = approvals.filter((a) => {
    const matchesTier = filterTier === 'All' || a.tier === filterTier;
    const matchesStatus = filterStatus === 'All' || a.status === filterStatus;
    return matchesTier && matchesStatus;
  });

  const pendingCount = approvals.filter((a) => a.status === 'PENDING').length;
  const approvedCount = approvals.filter((a) => a.status === 'APPROVED' || a.status === 'EXECUTED').length;

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* 1. Header */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="font-display font-bold text-slate-950 text-lg tracking-tight">
              Executive Approval Center
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 font-semibold">
              3-TIER GOVERNANCE
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Human-in-the-loop authorization gates for campaign launches, budget changes, and external publishing
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="font-semibold text-slate-900 font-mono bg-indigo-50 px-2.5 py-1 rounded-lg text-indigo-700 border border-indigo-100">
            {pendingCount} Pending Sign-Off
          </span>
        </div>
      </div>

      {/* 2. Three-Tier Policy Explainer Banner */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {/* GREEN */}
        <div className="p-4 rounded-xl bg-emerald-50/40 border border-emerald-100 text-xs space-y-1">
          <div className="font-bold text-emerald-950 flex items-center justify-between">
            <span>GREEN — Autonomous</span>
            <span className="text-[10px] font-mono text-emerald-700 font-semibold">TIER 1</span>
          </div>
          <p className="text-slate-600 text-[11px] leading-relaxed">
            AI runs research, data analysis, internal task creation, and draft formulation autonomously.
          </p>
        </div>

        {/* YELLOW */}
        <div className="p-4 rounded-xl bg-amber-50/40 border border-amber-100 text-xs space-y-1">
          <div className="font-bold text-amber-950 flex items-center justify-between">
            <span>YELLOW — Approval Required</span>
            <span className="text-[10px] font-mono text-amber-700 font-semibold">TIER 2</span>
          </div>
          <p className="text-slate-600 text-[11px] leading-relaxed">
            Requires Zahida Khan sign-off before publishing social posts, budget updates, or client emails.
          </p>
        </div>

        {/* RED */}
        <div className="p-4 rounded-xl bg-rose-50/40 border border-rose-100 text-xs space-y-1">
          <div className="font-bold text-rose-950 flex items-center justify-between">
            <span>RED — Strictly Human Only</span>
            <span className="text-[10px] font-mono text-rose-700 font-semibold">TIER 3</span>
          </div>
          <p className="text-slate-600 text-[11px] leading-relaxed">
            Contracts, payments, banking, account deletions, and irreversible decisions. Zero automation allowed.
          </p>
        </div>
      </div>

      {/* 3. Filter Bar */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-3.5 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 font-medium outline-hidden"
          >
            <option value="All">All States</option>
            <option value="PENDING">Pending Authorization ({pendingCount})</option>
            <option value="APPROVED">Approved ({approvedCount})</option>
            <option value="REJECTED">Rejected / Revision</option>
          </select>

          <select
            value={filterTier}
            onChange={(e) => setFilterTier(e.target.value)}
            className="border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 outline-hidden"
          >
            <option value="All">All Tiers</option>
            <option value="YELLOW">Yellow (Approval Required)</option>
            <option value="RED">Red (Human-Only)</option>
            <option value="GREEN">Green (Autonomous Logs)</option>
          </select>
        </div>

        <div className="text-xs text-slate-500 font-medium">
          Authorizing Officer: <strong>Zahida Khan</strong>
        </div>
      </div>

      {/* 4. Approvals Queue */}
      <div className="space-y-3">
        {filteredApprovals.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center text-xs text-slate-400">
            No items matching the selected approval filters.
          </div>
        ) : (
          filteredApprovals.map((item) => {
            const isPending = item.status === 'PENDING';

            return (
              <div
                key={item.id}
                className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs space-y-3 transition-colors"
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                          item.tier === 'GREEN'
                            ? 'bg-emerald-50 text-emerald-800'
                            : item.tier === 'YELLOW'
                            ? 'bg-amber-50 text-amber-800'
                            : 'bg-rose-50 text-rose-800'
                        }`}
                      >
                        {item.tier} TIER
                      </span>
                      <span className="text-xs font-semibold text-slate-400">·</span>
                      <span className="text-xs font-semibold text-slate-700">{item.clientName}</span>
                      <span className="text-xs text-slate-400">·</span>
                      <span className="text-[11px] text-slate-500">Requested by {item.requestedByAgent}</span>
                    </div>

                    <h3 className="font-display font-bold text-slate-900 text-sm">{item.title}</h3>
                    <p className="text-xs text-slate-600 leading-relaxed max-w-3xl">{item.description}</p>
                  </div>

                  <span
                    className={`self-start text-[10px] font-semibold px-2.5 py-1 rounded-full ${
                      item.status === 'PENDING'
                        ? 'bg-amber-100 text-amber-800'
                        : item.status === 'APPROVED' || item.status === 'EXECUTED'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    {item.status}
                  </span>
                </div>

                {/* Proposed Action Preview Details */}
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/70 text-xs space-y-1">
                  <div className="font-semibold text-slate-800">Proposed Action & Impact:</div>
                  <div className="text-slate-600 font-mono text-[11px]">{item.proposedAction.details}</div>
                  <div className="text-emerald-700 text-[11px] font-medium pt-1">
                    Impact: {item.proposedAction.impactSummary}
                  </div>
                </div>

                {/* Decision Actions Bar */}
                <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="text-[11px] text-slate-400">
                    Logged at {item.createdAt}
                    {item.auditLog?.reviewedAt && (
                      <span className="ml-2 text-indigo-600 font-medium">
                        · Reviewed at {item.auditLog.reviewedAt} by {item.auditLog.reviewedBy}
                      </span>
                    )}
                  </div>

                  {isPending && (
                    <div className="flex items-center gap-2 self-end sm:self-auto">
                      <button
                        onClick={() => handleApproval(item.id, 'REJECT')}
                        className="px-3.5 py-1.5 rounded-lg border border-slate-200 hover:bg-rose-50 hover:text-rose-700 hover:border-rose-200 text-slate-600 text-xs font-semibold transition-colors flex items-center gap-1.5"
                      >
                        <XCircle className="w-3.5 h-3.5" />
                        <span>Reject / Revise</span>
                      </button>

                      <button
                        onClick={() => handleApproval(item.id, 'APPROVE')}
                        className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold transition-colors shadow-xs flex items-center gap-1.5"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Authorize Action</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
