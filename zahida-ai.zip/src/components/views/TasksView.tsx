import React, { useState } from 'react';
import {
  CheckSquare,
  Plus,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  User,
  AlertCircle,
  Sparkles,
  Trash2,
} from 'lucide-react';
import { useAgency } from '../../context/AgencyContext';
import { Task } from '../../types';

export const TasksView: React.FC = () => {
  const {
    tasks,
    toggleTaskStatus,
    deleteTask,
    setQuickModalType,
    clients,
    selectedClientId,
    setSelectedClientId,
  } = useAgency();

  const [priorityFilter, setPriorityFilter] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [search, setSearch] = useState('');

  const filteredTasks = tasks.filter((t) => {
    const matchesSearch =
      t.title.toLowerCase().includes(search.toLowerCase()) ||
      t.assignee.toLowerCase().includes(search.toLowerCase()) ||
      (t.clientName && t.clientName.toLowerCase().includes(search.toLowerCase()));
    const matchesPriority = priorityFilter === 'All' || t.priority === priorityFilter;
    const matchesStatus = statusFilter === 'All' || t.status === statusFilter;
    const matchesClient = !selectedClientId || t.clientId === selectedClientId;
    return matchesSearch && matchesPriority && matchesStatus && matchesClient;
  });

  const pendingCount = tasks.filter((t) => t.status !== 'Completed').length;
  const urgentCount = tasks.filter((t) => t.priority === 'Urgent' && t.status !== 'Completed').length;

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* 1. Header */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="font-display font-bold text-slate-950 text-lg tracking-tight">
              Agency Task Operations
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-50 text-amber-800 font-semibold">
              {urgentCount} URGENT
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Strategy-driven operational tasks assigned across media buyers, designers, and strategists
          </p>
        </div>

        <button
          onClick={() => setQuickModalType('task')}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold transition-colors shadow-xs self-start sm:self-auto"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Task</span>
        </button>
      </div>

      {/* 2. Filters Strip */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-3.5 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-2 flex-1 max-w-xl">
          <div className="relative flex-1 min-w-[180px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search tasks..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full text-xs pl-8 pr-3 py-1.5 border border-slate-200 rounded-lg outline-hidden focus:border-indigo-500"
            />
          </div>

          <select
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value)}
            className="border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 outline-hidden"
          >
            <option value="All">All Priorities</option>
            <option value="Urgent">Urgent</option>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 outline-hidden"
          >
            <option value="All">All Statuses</option>
            <option value="To Do">To Do</option>
            <option value="In Progress">In Progress</option>
            <option value="Review">Review</option>
            <option value="Completed">Completed</option>
          </select>
        </div>

        <div className="text-xs text-slate-500 font-medium">
          {pendingCount} open deliverables remaining
        </div>
      </div>

      {/* 3. Tasks List */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs space-y-2">
        {filteredTasks.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-400">
            No matching tasks found.
          </div>
        ) : (
          filteredTasks.map((task) => {
            const isCompleted = task.status === 'Completed';

            return (
              <div
                key={task.id}
                className={`p-3.5 rounded-xl border flex items-start justify-between gap-3 transition-colors ${
                  isCompleted
                    ? 'bg-slate-50/40 border-slate-200/60 opacity-60'
                    : 'bg-white border-slate-200/90 hover:border-slate-300'
                }`}
              >
                <div className="flex items-start gap-3">
                  {/* Checkbox */}
                  <button
                    onClick={() => toggleTaskStatus(task.id)}
                    className={`mt-0.5 w-4 h-4 rounded border flex items-center justify-center transition-colors ${
                      isCompleted
                        ? 'bg-emerald-600 border-emerald-600 text-white'
                        : 'border-slate-300 hover:border-slate-400 bg-white'
                    }`}
                  >
                    {isCompleted && <CheckCircle2 className="w-3.5 h-3.5" />}
                  </button>

                  <div>
                    <div
                      className={`text-xs font-semibold ${
                        isCompleted ? 'line-through text-slate-500' : 'text-slate-900'
                      }`}
                    >
                      {task.title}
                    </div>

                    <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-1">
                      {task.description}
                    </p>

                    <div className="flex flex-wrap items-center gap-2.5 mt-2 text-[10px] text-slate-500 font-medium">
                      {task.clientName && (
                        <span className="font-semibold text-slate-800">
                          Client: {task.clientName}
                        </span>
                      )}
                      <span>·</span>
                      <span>Assignee: {task.assignee}</span>
                      <span>·</span>
                      <span className="font-mono">Due: {task.deadline}</span>
                      {task.sourceStrategy && (
                        <>
                          <span>·</span>
                          <span className="text-indigo-600 flex items-center gap-1">
                            <Sparkles className="w-2.5 h-2.5" />
                            {task.sourceStrategy}
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <span
                    className={`text-[10px] font-semibold px-2 py-0.5 rounded font-mono ${
                      task.priority === 'Urgent'
                        ? 'bg-rose-50 text-rose-700'
                        : task.priority === 'High'
                        ? 'bg-amber-50 text-amber-700'
                        : 'bg-slate-100 text-slate-700'
                    }`}
                  >
                    {task.priority}
                  </span>

                  <button
                    onClick={() => deleteTask(task.id)}
                    className="p-1 text-slate-400 hover:text-rose-600 rounded"
                    title="Delete task"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
