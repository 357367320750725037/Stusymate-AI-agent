import React, { useState } from 'react';
import {
  Users,
  Search,
  Plus,
  Building2,
  DollarSign,
  TrendingUp,
  Globe,
  Mail,
  Phone,
  Sparkles,
  Edit3,
  CheckCircle2,
  AlertTriangle,
  FolderOpen,
  ArrowRight,
  ExternalLink,
  Save,
} from 'lucide-react';
import { useAgency } from '../../context/AgencyContext';
import { Client } from '../../types';

export const ClientsView: React.FC = () => {
  const {
    clients,
    campaigns,
    contentItems,
    tasks,
    strategies,
    reports,
    knowledgeDocs,
    leads,
    updateClientMemory,
    setQuickModalType,
    selectedClientDetail,
    setSelectedClientDetail,
    setSelectedClientId,
    sendAiMessage,
    setIsAskZaiOpen,
    setCurrentView,
  } = useAgency();

  const [search, setSearch] = useState('');
  const [filterTier, setFilterTier] = useState<string>('All');
  const [filterStatus, setFilterStatus] = useState<string>('All');
  const [activeTab, setActiveTab] = useState<
    | 'Overview'
    | 'Strategy'
    | 'Campaigns'
    | 'Content'
    | 'Tasks'
    | 'Leads'
    | 'Analytics'
    | 'Reports'
    | 'Documents'
    | 'AI Insights'
  >('Overview');

  // Client memory edit state
  const [isEditingMemory, setIsEditingMemory] = useState(false);
  const [memoryForm, setMemoryForm] = useState<Client['memory'] | null>(null);

  const activeClient = selectedClientDetail || clients[0];

  const handleOpenClient = (client: Client) => {
    setSelectedClientDetail(client);
    setSelectedClientId(client.id);
    setIsEditingMemory(false);
    setMemoryForm(client.memory);
  };

  const handleSaveMemory = () => {
    if (!activeClient || !memoryForm) return;
    updateClientMemory(activeClient.id, memoryForm);
    setIsEditingMemory(false);
  };

  const filteredClients = clients.filter((c) => {
    const matchesSearch =
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.industry.toLowerCase().includes(search.toLowerCase()) ||
      c.contactPerson.toLowerCase().includes(search.toLowerCase());
    const matchesTier = filterTier === 'All' || c.tier === filterTier;
    const matchesStatus = filterStatus === 'All' || c.status === filterStatus;
    return matchesSearch && matchesTier && matchesStatus;
  });

  const clientCampaigns = campaigns.filter((camp) => camp.clientId === activeClient?.id);
  const clientContent = contentItems.filter((item) => item.clientId === activeClient?.id);
  const clientTasks = tasks.filter((t) => t.clientId === activeClient?.id);

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* 1. Header Bar */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display font-bold text-slate-950 text-lg tracking-tight">
            Client CRM & Structured Memory
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage agency accounts, memory vectors, brand voice parameters, and active deliverables
          </p>
        </div>

        <button
          onClick={() => setQuickModalType('client')}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold transition-colors shadow-xs self-start sm:self-auto"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add New Client</span>
        </button>
      </div>

      {/* 2. Client Browser & Detail Split Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Client Directory List (5 cols) */}
        <div className="lg:col-span-4 space-y-3">
          {/* Search & Filters */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-3.5 shadow-xs space-y-2.5">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search clients, industries, contacts..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full text-xs pl-8 pr-3 py-1.5 border border-slate-200 rounded-lg outline-hidden focus:border-indigo-500"
              />
            </div>

            <div className="flex items-center gap-2 text-xs">
              <select
                value={filterTier}
                onChange={(e) => setFilterTier(e.target.value)}
                className="flex-1 border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-700 outline-hidden"
              >
                <option value="All">All Tiers</option>
                <option value="Enterprise">Enterprise</option>
                <option value="Growth">Growth</option>
                <option value="Starter">Starter</option>
              </select>

              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="flex-1 border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-700 outline-hidden"
              >
                <option value="All">All Statuses</option>
                <option value="Active">Active</option>
                <option value="At Risk">At Risk</option>
                <option value="Onboarding">Onboarding</option>
              </select>
            </div>
          </div>

          {/* Client Card Items */}
          <div className="space-y-2">
            {filteredClients.map((client) => {
              const isSelected = activeClient?.id === client.id;
              return (
                <div
                  key={client.id}
                  onClick={() => handleOpenClient(client)}
                  className={`p-4 rounded-xl border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-indigo-50/50 border-indigo-500 shadow-xs ring-1 ring-indigo-500/20'
                      : 'bg-white border-slate-200/90 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2.5">
                      {client.logoUrl ? (
                        <img
                          src={client.logoUrl}
                          alt={client.name}
                          className="w-8 h-8 rounded-lg object-cover ring-1 ring-slate-200"
                          referrerPolicy="no-referrer"
                          onError={(e) => {
                            (e.target as HTMLElement).style.display = 'none';
                          }}
                        />
                      ) : (
                        <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-700 font-bold flex items-center justify-center text-xs">
                          {client.name.slice(0, 2).toUpperCase()}
                        </div>
                      )}
                      <div>
                        <div className="font-semibold text-slate-900 text-xs">{client.name}</div>
                        <div className="text-[10px] text-slate-500">{client.industry}</div>
                      </div>
                    </div>

                    <span
                      className={`text-[10px] font-semibold px-1.5 py-0.5 rounded ${
                        client.status === 'Active'
                          ? 'bg-emerald-50 text-emerald-700'
                          : client.status === 'At Risk'
                          ? 'bg-rose-50 text-rose-700'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {client.status}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[11px] pt-2 border-t border-slate-100/80">
                    <div>
                      <span className="text-slate-400">Retainer: </span>
                      <span className="font-mono font-medium text-slate-900 tabular-nums">
                        ${client.monthlyRetainer}/mo
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400">Blended ROAS: </span>
                      <span className="font-mono font-semibold text-emerald-600 tabular-nums">
                        {client.blendedRoas}x
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Detailed Client Workspace & Memory Tabs (8 cols) */}
        {activeClient && (
          <div className="lg:col-span-8 bg-white border border-slate-200/90 rounded-2xl p-6 shadow-xs space-y-6">
            {/* Top Workspace Bar */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
              <div className="flex items-center gap-3">
                {activeClient.logoUrl ? (
                  <img
                    src={activeClient.logoUrl}
                    alt={activeClient.name}
                    className="w-12 h-12 rounded-xl object-cover ring-1 ring-slate-200"
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      (e.target as HTMLElement).style.display = 'none';
                    }}
                  />
                ) : (
                  <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-700 font-bold flex items-center justify-center text-sm">
                    {activeClient.name.slice(0, 2).toUpperCase()}
                  </div>
                )}
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-display font-bold text-slate-950 text-lg">
                      {activeClient.name}
                    </h3>
                    <span className="text-xs text-slate-400">·</span>
                    <span className="text-xs text-slate-600 font-medium">{activeClient.tier} Tier</span>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-slate-500 mt-0.5">
                    <span>{activeClient.contactPerson}</span>
                    <span>·</span>
                    <a
                      href={activeClient.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-indigo-600 hover:underline flex items-center gap-0.5"
                    >
                      <span>{activeClient.website.replace('https://', '')}</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                </div>
              </div>

              {/* Ask ZAI for this Client Button */}
              <button
                onClick={() => {
                  setSelectedClientId(activeClient.id);
                  sendAiMessage(`Analyze current marketing performance and bottlenecks for ${activeClient.name}.`);
                  setIsAskZaiOpen(true);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-semibold border border-indigo-200/60 transition-colors self-start sm:self-auto"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Ask ZAI About {activeClient.name}</span>
              </button>
            </div>

            {/* Navigation Tabs (10 requested tabs) */}
            <div className="flex items-center gap-1 border-b border-slate-100 overflow-x-auto scrollbar-none pb-2 text-xs">
              {[
                'Overview',
                'Strategy',
                'Campaigns',
                'Content',
                'Tasks',
                'Leads',
                'Analytics',
                'Reports',
                'Documents',
                'AI Insights',
              ].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab as any)}
                  className={`px-3 py-1.5 font-medium rounded-lg whitespace-nowrap transition-colors ${
                    activeTab === tab
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>

            {/* Tab 1: Overview & Client Memory */}
            {activeTab === 'Overview' && (
              <div className="space-y-6">
                {/* Metric Strip */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                    <span className="text-[10px] text-slate-400 uppercase font-semibold">Monthly Retainer</span>
                    <div className="font-mono font-bold text-sm text-slate-900 mt-0.5">
                      ${activeClient.monthlyRetainer.toLocaleString()}/mo
                    </div>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                    <span className="text-[10px] text-slate-400 uppercase font-semibold">Managed Ad Spend</span>
                    <div className="font-mono font-bold text-sm text-slate-900 mt-0.5">
                      ${activeClient.monthlyAdSpend.toLocaleString()}/mo
                    </div>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                    <span className="text-[10px] text-slate-400 uppercase font-semibold">Blended ROAS</span>
                    <div className="font-mono font-bold text-sm text-emerald-600 mt-0.5">
                      {activeClient.blendedRoas}x
                    </div>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                    <span className="text-[10px] text-slate-400 uppercase font-semibold">Account Lead</span>
                    <div className="font-medium text-xs text-slate-900 mt-0.5 truncate">
                      {activeClient.assignedLead}
                    </div>
                  </div>
                </div>

                {/* Structured Client Memory (Core AI Context) */}
                <div className="border border-indigo-100 rounded-2xl p-5 bg-indigo-50/20">
                  <div className="flex items-center justify-between pb-3 border-b border-indigo-100/60 mb-4">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-indigo-600" />
                      <h4 className="font-display font-bold text-slate-900 text-sm">
                        ZAI Structured Client Memory
                      </h4>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-100 text-indigo-800">
                        INJECTED AUTOMATICALLY
                      </span>
                    </div>

                    {!isEditingMemory ? (
                      <button
                        onClick={() => {
                          setMemoryForm(activeClient.memory);
                          setIsEditingMemory(true);
                        }}
                        className="flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-800"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>Edit Memory</span>
                      </button>
                    ) : (
                      <button
                        onClick={handleSaveMemory}
                        className="flex items-center gap-1 text-xs font-semibold px-2.5 py-1 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
                      >
                        <Save className="w-3.5 h-3.5" />
                        <span>Save Memory</span>
                      </button>
                    )}
                  </div>

                  {!isEditingMemory ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                      <div>
                        <span className="text-slate-400 font-medium">Target Audience:</span>
                        <p className="text-slate-800 font-medium mt-0.5">{activeClient.memory.targetAudience}</p>
                      </div>
                      <div>
                        <span className="text-slate-400 font-medium">Primary Marketing Goal:</span>
                        <p className="text-slate-800 font-medium mt-0.5">{activeClient.memory.primaryGoal}</p>
                      </div>
                      <div>
                        <span className="text-slate-400 font-medium">Main Channels:</span>
                        <p className="text-slate-800 font-medium mt-0.5">
                          {activeClient.memory.mainPlatform} (Primary) · {activeClient.memory.secondaryPlatform} (Secondary)
                        </p>
                      </div>
                      <div>
                        <span className="text-slate-400 font-medium">Brand Voice & Tone:</span>
                        <p className="text-slate-800 font-medium mt-0.5">{activeClient.memory.brandTone}</p>
                      </div>
                      <div className="md:col-span-2">
                        <span className="text-slate-400 font-medium">Key Differentiators:</span>
                        <div className="flex flex-wrap gap-1.5 mt-1">
                          {activeClient.memory.keyDifferentiators.map((diff, i) => (
                            <span key={i} className="px-2 py-0.5 rounded bg-white border border-slate-200 text-slate-700 text-[11px]">
                              {diff}
                            </span>
                          ))}
                        </div>
                      </div>
                      <div className="md:col-span-2">
                        <span className="text-slate-400 font-medium">ZAI Strategic Memory Notes:</span>
                        <p className="text-slate-700 bg-white p-2.5 rounded-lg border border-slate-200 mt-1">
                          {activeClient.memory.notes}
                        </p>
                      </div>
                    </div>
                  ) : (
                    memoryForm && (
                      <div className="space-y-3 text-xs">
                        <div>
                          <label className="block text-slate-500 font-medium mb-1">Target Audience</label>
                          <input
                            type="text"
                            value={memoryForm.targetAudience}
                            onChange={(e) => setMemoryForm({ ...memoryForm, targetAudience: e.target.value })}
                            className="w-full border border-slate-200 rounded-lg p-2"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-500 font-medium mb-1">Primary Goal</label>
                          <input
                            type="text"
                            value={memoryForm.primaryGoal}
                            onChange={(e) => setMemoryForm({ ...memoryForm, primaryGoal: e.target.value })}
                            className="w-full border border-slate-200 rounded-lg p-2"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-slate-500 font-medium mb-1">Main Platform</label>
                            <input
                              type="text"
                              value={memoryForm.mainPlatform}
                              onChange={(e) => setMemoryForm({ ...memoryForm, mainPlatform: e.target.value })}
                              className="w-full border border-slate-200 rounded-lg p-2"
                            />
                          </div>
                          <div>
                            <label className="block text-slate-500 font-medium mb-1">Brand Voice Tone</label>
                            <input
                              type="text"
                              value={memoryForm.brandTone}
                              onChange={(e) => setMemoryForm({ ...memoryForm, brandTone: e.target.value })}
                              className="w-full border border-slate-200 rounded-lg p-2"
                            />
                          </div>
                        </div>
                        <div>
                          <label className="block text-slate-500 font-medium mb-1">Strategic Notes</label>
                          <textarea
                            rows={2}
                            value={memoryForm.notes}
                            onChange={(e) => setMemoryForm({ ...memoryForm, notes: e.target.value })}
                            className="w-full border border-slate-200 rounded-lg p-2"
                          />
                        </div>
                      </div>
                    )
                  )}
                </div>
              </div>
            )}

            {/* Tab 2: Strategy */}
            {activeTab === 'Strategy' && (() => {
              const clientStrat = strategies.find((s) => s.clientId === activeClient.id);
              return (
                <div className="space-y-4 text-xs">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                    <h4 className="font-display font-bold text-slate-900 text-sm">
                      {clientStrat ? clientStrat.title : 'Active Marketing Blueprint'}
                    </h4>
                    <button
                      onClick={() => {
                        setSelectedClientId(activeClient.id);
                        setCurrentView('Strategies');
                      }}
                      className="text-violet-700 font-semibold hover:underline flex items-center gap-1"
                    >
                      <span>Open Full Strategy Hub →</span>
                    </button>
                  </div>

                  {clientStrat ? (
                    <div className="space-y-4">
                      <div className="p-4 rounded-xl bg-violet-50/40 border border-violet-100 space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-violet-950">Strategic Rationale & Objective</span>
                          <span className="font-mono text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100">
                            {clientStrat.expectedRoas}
                          </span>
                        </div>
                        <p className="text-slate-700 leading-relaxed">
                          {clientStrat.primaryObjective}
                        </p>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                        {clientStrat.strategicPillars.map((p, idx) => (
                          <div key={idx} className="p-3 rounded-lg border border-slate-200 bg-slate-50 space-y-1.5">
                            <span className="font-semibold text-slate-900 text-[11px]">{p.title}</span>
                            <p className="text-[10px] text-slate-500 line-clamp-2">{p.description}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-3 leading-relaxed">
                      <div className="font-semibold text-slate-900 text-sm">
                        Strategic Objective: {activeClient.memory.primaryGoal}
                      </div>
                      <p className="text-slate-700">
                        Focus creative efforts on highlighting {activeClient.memory.keyDifferentiators.join(', ')}.
                        Maintain strict ad spend pacing with target blended ROAS threshold of {activeClient.blendedRoas}x.
                      </p>
                    </div>
                  )}
                </div>
              );
            })()}

            {/* Tab 3: Campaigns */}
            {activeTab === 'Campaigns' && (
              <div className="space-y-3 text-xs">
                <div className="flex items-center justify-between">
                  <h4 className="font-display font-bold text-slate-900 text-sm">
                    Campaigns for {activeClient.name} ({clientCampaigns.length})
                  </h4>
                  <button
                    onClick={() => setQuickModalType('campaign')}
                    className="text-indigo-600 font-semibold"
                  >
                    + New Campaign
                  </button>
                </div>
                {clientCampaigns.length === 0 ? (
                  <div className="p-8 text-center text-slate-400">No campaigns found for this client.</div>
                ) : (
                  clientCampaigns.map((camp) => (
                    <div key={camp.id} className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/50 flex items-center justify-between">
                      <div>
                        <div className="font-semibold text-slate-900">{camp.name}</div>
                        <div className="text-[11px] text-slate-500">{camp.platform} · {camp.objective}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-mono font-bold text-emerald-600">{camp.roas}x ROAS</div>
                        <div className="text-[10px] text-slate-400 font-mono">${camp.spentCurrentMonth.toLocaleString()} spent</div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* Tab 4: Content */}
            {activeTab === 'Content' && (
              <div className="space-y-3 text-xs">
                <div className="flex items-center justify-between">
                  <h4 className="font-display font-bold text-slate-900 text-sm">
                    Content Pieces ({clientContent.length})
                  </h4>
                  <button
                    onClick={() => setQuickModalType('content')}
                    className="text-indigo-600 font-semibold"
                  >
                    + New Brief
                  </button>
                </div>
                {clientContent.map((item) => (
                  <div key={item.id} className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/50">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-semibold text-slate-900">{item.title}</span>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-slate-200 text-slate-700 font-mono">
                        {item.status}
                      </span>
                    </div>
                    <p className="text-slate-600 line-clamp-2 text-[11px]">{item.caption}</p>
                  </div>
                ))}
              </div>
            )}

            {/* Tab 5: Tasks */}
            {activeTab === 'Tasks' && (
              <div className="space-y-3 text-xs">
                <div className="flex items-center justify-between">
                  <h4 className="font-display font-bold text-slate-900 text-sm">
                    Tasks Assigned ({clientTasks.length})
                  </h4>
                  <button onClick={() => setQuickModalType('task')} className="text-indigo-600 font-semibold">
                    + Add Task
                  </button>
                </div>
                {clientTasks.map((t) => (
                  <div key={t.id} className="p-3 rounded-xl border border-slate-200 bg-slate-50/50 flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-slate-900">{t.title}</div>
                      <div className="text-[10px] text-slate-500">Assignee: {t.assignee} · Due: {t.deadline}</div>
                    </div>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-50 text-amber-800">
                      {t.priority}
                    </span>
                  </div>
                ))}
              </div>
            )}

            {/* Tab 6: Leads */}
            {activeTab === 'Leads' && (
              <div className="space-y-3 text-xs">
                <div className="flex items-center justify-between">
                  <h4 className="font-display font-bold text-slate-900 text-sm">
                    Inbound Leads & Pipeline
                  </h4>
                  <button onClick={() => setCurrentView('Leads')} className="text-indigo-600 font-semibold">
                    Open Leads CRM →
                  </button>
                </div>
                {leads.slice(0, 3).map((lead) => (
                  <div key={lead.id} className="p-3 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-between">
                    <div>
                      <span className="font-semibold text-slate-900">{lead.name} ({lead.company})</span>
                      <p className="text-[11px] text-slate-500">{lead.serviceInterest}</p>
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-50 text-emerald-700">
                      Score: {lead.score}
                    </span>
                  </div>
                ))}
              </div>
            )}

            {/* Tab 7: Analytics */}
            {activeTab === 'Analytics' && (
              <div className="p-6 text-center text-xs text-slate-500 space-y-2">
                <p>Full-funnel attribution, CAC, and conversion rate analytics for {activeClient.name}.</p>
                <button
                  onClick={() => {
                    setSelectedClientId(activeClient.id);
                    setCurrentView('Analytics');
                  }}
                  className="px-3 py-1.5 rounded-lg bg-slate-900 text-white font-semibold text-xs"
                >
                  View Client Analytics Matrix →
                </button>
              </div>
            )}

            {/* Tab 8: Reports */}
            {activeTab === 'Reports' && (() => {
              const clientReports = reports.filter((r) => r.clientId === activeClient.id);
              return (
                <div className="space-y-3 text-xs">
                  <div className="flex items-center justify-between">
                    <h4 className="font-display font-bold text-slate-900 text-sm">
                      Executive Reports ({clientReports.length})
                    </h4>
                    <button
                      onClick={() => {
                        setSelectedClientId(activeClient.id);
                        setCurrentView('Reports');
                      }}
                      className="text-indigo-600 font-semibold"
                    >
                      Open Executive Decks →
                    </button>
                  </div>
                  {clientReports.map((rep) => (
                    <div key={rep.id} className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/50 flex items-center justify-between">
                      <div>
                        <div className="font-semibold text-slate-900">{rep.title}</div>
                        <div className="text-[11px] text-slate-500">{rep.period} · {rep.preparedBy}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-mono font-bold text-emerald-600">{rep.metrics.roas}x ROAS</div>
                        <div className="text-[10px] text-slate-400 font-mono">${rep.metrics.spend.toLocaleString()} spend</div>
                      </div>
                    </div>
                  ))}
                </div>
              );
            })()}

            {/* Tab 9: Documents */}
            {activeTab === 'Documents' && (
              <div className="space-y-3 text-xs">
                <div className="flex items-center justify-between">
                  <h4 className="font-display font-bold text-slate-900 text-sm">
                    Client SOPs & Retainer Documents
                  </h4>
                  <button onClick={() => setCurrentView('Knowledge Base')} className="text-indigo-600 font-semibold">
                    Knowledge Base →
                  </button>
                </div>
                {knowledgeDocs.slice(0, 4).map((doc) => (
                  <div key={doc.id} className="p-3 rounded-xl border border-slate-200 bg-slate-50/50 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-slate-900">{doc.title}</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-200 text-slate-700">
                        {doc.fileType}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 line-clamp-2">{doc.summary}</p>
                  </div>
                ))}
              </div>
            )}
            {activeTab === 'AI Insights' && (
              <div className="p-4 rounded-xl bg-indigo-50/40 border border-indigo-100 text-xs space-y-2">
                <div className="font-bold text-indigo-900 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                  <span>ZAI Continuous Monitoring Log for {activeClient.name}</span>
                </div>
                <p className="text-slate-700">
                  {activeClient.memory.notes}
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
