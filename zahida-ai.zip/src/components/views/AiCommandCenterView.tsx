import React, { useState } from 'react';
import {
  Bot,
  Sparkles,
  Send,
  Loader2,
  ShieldCheck,
  Search,
  Compass,
  PenTool,
  Megaphone,
  BarChart2,
  Share2,
  HeartHandshake,
  Target,
  FileSpreadsheet,
  Globe,
  Clock,
  ArrowRight,
  CheckCircle,
} from 'lucide-react';
import { useAgency } from '../../context/AgencyContext';

interface AgentCard {
  id: string;
  name: string;
  role: string;
  icon: any;
  status: 'Ready' | 'Active' | 'Queued';
  description: string;
  capabilities: string[];
}

export const AiCommandCenterView: React.FC = () => {
  const {
    clients,
    selectedClientId,
    setSelectedClientId,
    sendAiMessage,
    isAiThinking,
    chatMessages,
    agentLogs,
    setCurrentView,
  } = useAgency();

  const [selectedAgent, setSelectedAgent] = useState('Strategy Agent');
  const [commandInput, setCommandInput] = useState('');

  const agents: AgentCard[] = [
    {
      id: 'strat',
      name: 'Strategy Agent',
      role: 'Growth & Funnel Architecture',
      icon: Compass,
      status: 'Ready',
      description: 'Formulates full-funnel multichannel marketing strategies, channel allocations, and monthly KPI targets.',
      capabilities: ['Multichannel Funnels', 'Budget Modeling', 'Audience Personas', 'GTM Blueprints'],
    },
    {
      id: 'ads',
      name: 'Ads Agent',
      role: 'Paid Media Intelligence',
      icon: Megaphone,
      status: 'Active',
      description: 'Monitors Meta & Google Ads spend, detects creative fatigue and CPA spikes, and formulates scaling plans.',
      capabilities: ['CPA Anomaly Alert', 'Creative Testing Matrix', 'Bid & Budget Optimization', 'Lookalike Modeling'],
    },
    {
      id: 'content',
      name: 'Content Agent',
      role: 'Creative & Copywriting Suite',
      icon: PenTool,
      status: 'Ready',
      description: 'Writes platform-native copy, viral hooks, Reels scripts, carousels, ad copy variations, and email sequences.',
      capabilities: ['Reels & TikTok Scripts', 'LinkedIn Thought Leadership', 'Ad Copy Angles', 'Email Nurture Flows'],
    },
    {
      id: 'research',
      name: 'Research Agent',
      role: 'Market & Competitor Intel',
      icon: Search,
      status: 'Active',
      description: 'Crawls competitor ad libraries, SERP landscape, audience sentiment, and industry shifts.',
      capabilities: ['Competitor Ad Spying', 'SERP Keyword Trends', 'Customer Pain Point Mining', 'Industry Benchmarks'],
    },
    {
      id: 'seo',
      name: 'SEO Agent',
      role: 'Organic Search & On-Page UX',
      icon: Globe,
      status: 'Ready',
      description: 'Performs technical website audits, uncovers keyword gaps, and drafts high-converting content briefs.',
      capabilities: ['Technical Audits', 'Keyword Opportunity Index', 'Meta Tag Generation', 'Content Gap Analysis'],
    },
    {
      id: 'analytics',
      name: 'Analytics Agent',
      role: 'Attribution & Unit Economics',
      icon: BarChart2,
      status: 'Ready',
      description: 'Synthesizes blended ROAS, customer acquisition costs, churn signals, and channel attribution models.',
      capabilities: ['Blended ROAS Tracking', 'Cohort LTV Modeling', 'Attribution Diagnostics', 'Budget Efficiency Index'],
    },
    {
      id: 'social',
      name: 'Social Media Agent',
      role: 'Calendar & Community Strategy',
      icon: Share2,
      status: 'Ready',
      description: 'Prepares structured monthly publishing calendars, optimal posting times, and engagement frameworks.',
      capabilities: ['Monthly Editorial Grid', 'Format Mix Optimization', 'Caption Iteration', 'Visual Brief Specs'],
    },
    {
      id: 'success',
      name: 'Client Success Agent',
      role: 'Deliverables & Relationship Health',
      icon: HeartHandshake,
      status: 'Ready',
      description: 'Tracks client health scores, flags overdue deliverables, and drafts white-glove executive communications.',
      capabilities: ['Health Score Monitoring', 'SLA Adherence Tracking', 'Weekly Milestone Recaps', 'Executive Comms'],
    },
    {
      id: 'lead',
      name: 'Lead Agent',
      role: 'CRM Pipeline & Lead Scoring',
      icon: Target,
      status: 'Ready',
      description: 'Scores incoming prospects as HOT/WARM/COLD with mathematical rationale and crafts audit proposals.',
      capabilities: ['Lead Scoring Engine', 'Budget Qualification', 'Follow-up Scripts', 'Pipeline Velocity Tracking'],
    },
    {
      id: 'reporting',
      name: 'Reporting Agent',
      role: 'Automated Executive Decks',
      icon: FileSpreadsheet,
      status: 'Ready',
      description: 'Produces monthly executive decks answering: What happened? Why? What worked? What did not? Next steps.',
      capabilities: ['Executive Summaries', 'Client Deck Generation', 'Anomaly Explanations', 'Next-Sprint Forecasts'],
    },
  ];

  const handleRunCommand = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!commandInput.trim() || isAiThinking) return;

    sendAiMessage(commandInput, selectedAgent, selectedClientId || undefined);
    setCommandInput('');
  };

  const sampleWorkflows = [
    {
      agent: 'Strategy Agent',
      prompt: 'Formulate a 30-day Q4 scale strategy for Nordic Roastery focusing on subscription acquisition.',
    },
    {
      agent: 'Ads Agent',
      prompt: 'Analyze Lumina Skin Co 28% CPA increase and prepare ad set rotation proposal.',
    },
    {
      agent: 'Content Agent',
      prompt: 'Draft 3 high-converting LinkedIn carousel hooks for Apex Fintech CFO audience.',
    },
    {
      agent: 'Reporting Agent',
      prompt: 'Synthesize monthly executive summary for all active agency clients.',
    },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* 1. Header Banner */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="font-display font-bold text-slate-950 text-lg tracking-tight">
              AI Command Center
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 font-semibold border border-indigo-100">
              ORCHESTRATOR v1.0
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1 max-w-2xl">
            ZAI Chief Marketing Intelligence orchestrating 10 specialized domain agents under a strict 3-tier human-in-the-loop authorization policy.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right hidden sm:block">
            <div className="text-xs font-semibold text-slate-900">10 Agents Ready</div>
            <div className="text-[10px] text-emerald-600 font-mono">0 Security Holds</div>
          </div>
          <div className="p-2 rounded-xl bg-slate-900 text-white shadow-xs">
            <Bot className="w-5 h-5 text-indigo-400" />
          </div>
        </div>
      </div>

      {/* 2. Interactive Agent Execution Console */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Execution Terminal & Response View */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs">
            <h3 className="font-display font-bold text-slate-900 text-sm mb-3">
              Direct Agent Dispatch Console
            </h3>

            {/* Scope & Agent Selectors */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
              <div>
                <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
                  Target Domain Agent
                </label>
                <select
                  value={selectedAgent}
                  onChange={(e) => setSelectedAgent(e.target.value)}
                  className="w-full text-xs border border-slate-200 rounded-lg px-3 py-2 bg-slate-50 focus:bg-white outline-hidden focus:border-indigo-500"
                >
                  {agents.map((a) => (
                    <option key={a.id} value={a.name}>
                      {a.name} ({a.role})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
                  Client Memory Scope
                </label>
                <select
                  value={selectedClientId || ''}
                  onChange={(e) => setSelectedClientId(e.target.value ? e.target.value : null)}
                  className="w-full text-xs border border-slate-200 rounded-lg px-3 py-2 bg-slate-50 focus:bg-white outline-hidden focus:border-indigo-500"
                >
                  <option value="">Full Agency Wide (All Clients)</option>
                  {clients.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} — {c.industry}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Sample Suggested Prompts */}
            <div className="mb-4">
              <div className="text-[11px] font-medium text-slate-400 mb-1.5">
                Executive Command Templates:
              </div>
              <div className="flex flex-wrap gap-1.5 text-xs">
                {sampleWorkflows.map((wf, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setSelectedAgent(wf.agent);
                      setCommandInput(wf.prompt);
                    }}
                    className="px-2.5 py-1 rounded-md bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 text-slate-600 text-[11px] transition-colors"
                  >
                    {wf.prompt.slice(0, 48)}...
                  </button>
                ))}
              </div>
            </div>

            {/* Input Form */}
            <form onSubmit={handleRunCommand} className="space-y-3">
              <div className="relative">
                <textarea
                  rows={3}
                  value={commandInput}
                  onChange={(e) => setCommandInput(e.target.value)}
                  placeholder={`Dispatch instruction to ${selectedAgent}...`}
                  className="w-full text-xs border border-slate-200 rounded-xl p-3 bg-slate-50/50 focus:bg-white outline-hidden focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 font-sans resize-none"
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Enforces Safety & Approval Gating (Yellow/Red Tiers)</span>
                </div>

                <button
                  type="submit"
                  disabled={!commandInput.trim() || isAiThinking}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-white text-xs font-semibold transition-colors shadow-xs"
                >
                  {isAiThinking ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Synthesizing...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      <span>Execute via {selectedAgent}</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>

          {/* Recent AI Output Stream */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
              <h4 className="font-display font-bold text-slate-900 text-xs">
                Active Reasoning & Intelligence Feed
              </h4>
              <span className="text-[10px] font-mono text-slate-400">
                {chatMessages.length} interactions logged
              </span>
            </div>

            <div className="space-y-4 max-h-96 overflow-y-auto">
              {chatMessages.slice(-3).map((msg) => (
                <div
                  key={msg.id}
                  className={`p-4 rounded-xl border text-xs space-y-2 ${
                    msg.sender === 'zahida'
                      ? 'bg-slate-50 border-slate-200 text-slate-900'
                      : 'bg-indigo-50/40 border-indigo-100 text-slate-900'
                  }`}
                >
                  <div className="flex items-center justify-between font-semibold text-[11px]">
                    <span className="flex items-center gap-1.5">
                      {msg.sender === 'zahida' ? (
                        <span className="text-slate-700">Zahida Khan</span>
                      ) : (
                        <span className="text-indigo-700 font-bold flex items-center gap-1">
                          <Sparkles className="w-3 h-3 text-indigo-600" />
                          {msg.agentName || 'ZAI'}
                        </span>
                      )}
                    </span>
                    <span className="font-mono text-[10px] text-slate-400">{msg.timestamp}</span>
                  </div>

                  <div className="whitespace-pre-wrap leading-relaxed text-[13px] text-slate-800">
                    {msg.text}
                  </div>

                  {msg.suggestedActions && (
                    <div className="pt-2 flex flex-wrap gap-1.5 border-t border-slate-200/60">
                      {msg.suggestedActions.map((act, i) => (
                        <button
                          key={i}
                          onClick={() => {
                            if (act.includes('Approval')) {
                              setCurrentView('Approvals');
                            } else {
                              setCommandInput(act);
                            }
                          }}
                          className="px-2.5 py-1 rounded bg-white hover:bg-slate-100 text-slate-700 text-[11px] font-medium border border-slate-200"
                        >
                          {act} →
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Col: Multi-Agent Audit Log & Decision Loop */}
        <div className="space-y-4">
          {/* Decision Loop Policy Card */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs">
            <h4 className="font-display font-bold text-slate-900 text-xs mb-3">
              Agent Decision Loop Contract
            </h4>
            <div className="space-y-2 text-[11px] text-slate-600">
              <div className="flex items-start gap-2">
                <span className="font-mono text-indigo-600 font-bold shrink-0">01.</span>
                <span>User Request parsed with intent detection</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="font-mono text-indigo-600 font-bold shrink-0">02.</span>
                <span>Structured client memory & SOP retrieval</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="font-mono text-indigo-600 font-bold shrink-0">03.</span>
                <span>Specialized sub-agent task routing</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="font-mono text-indigo-600 font-bold shrink-0">04.</span>
                <span>Safe autonomous execution (Green Tier)</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="font-mono text-indigo-600 font-bold shrink-0">05.</span>
                <span>Gated human approval for external actions (Yellow/Red)</span>
              </div>
            </div>
          </div>

          {/* Real-time Agent Execution Audit Logs */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-display font-bold text-slate-900 text-xs">
                Agent Activity Logs
              </h4>
              <Clock className="w-3.5 h-3.5 text-slate-400" />
            </div>

            <div className="space-y-3">
              {agentLogs.map((log) => (
                <div key={log.id} className="text-xs p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                  <div className="flex items-center justify-between text-[10px] text-slate-500 mb-1">
                    <span className="font-semibold text-slate-800">{log.agent}</span>
                    <span className="font-mono">{log.timestamp}</span>
                  </div>
                  <div className="font-medium text-slate-800">{log.action}</div>
                  <div className="text-[11px] text-slate-500 mt-0.5 line-clamp-2">{log.details}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* 3. The 10 Sub-Agents Architecture Grid */}
      <div>
        <h3 className="font-display font-bold text-slate-900 text-sm mb-3">
          Specialized Sub-Agents Roster
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3">
          {agents.map((agent) => {
            const Icon = agent.icon;
            const isSelected = selectedAgent === agent.name;

            return (
              <div
                key={agent.id}
                onClick={() => setSelectedAgent(agent.name)}
                className={`p-4 rounded-xl border cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-indigo-50/50 border-indigo-400 shadow-xs'
                    : 'bg-white border-slate-200/90 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="p-1.5 rounded-lg bg-slate-100 text-slate-700">
                    <Icon className="w-4 h-4" />
                  </div>
                  <span className="text-[10px] font-mono font-semibold text-emerald-600">
                    {agent.status}
                  </span>
                </div>

                <div className="font-semibold text-slate-900 text-xs truncate">{agent.name}</div>
                <div className="text-[10px] text-slate-500 mb-2 truncate">{agent.role}</div>

                <div className="flex flex-wrap gap-1">
                  {agent.capabilities.slice(0, 2).map((cap, i) => (
                    <span
                      key={i}
                      className="text-[9px] bg-slate-100 text-slate-600 px-1 py-0.5 rounded"
                    >
                      {cap}
                    </span>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
