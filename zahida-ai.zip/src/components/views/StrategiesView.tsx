import React, { useState } from 'react';
import {
  Compass,
  Plus,
  Search,
  Filter,
  Sparkles,
  ArrowRight,
  TrendingUp,
  Target,
  Layers,
  PieChart,
  Calendar,
  CheckCircle2,
  Clock,
  ChevronDown,
  ChevronUp,
  DollarSign,
  Share2,
  CheckSquare,
  AlertCircle,
  ExternalLink,
  ShieldCheck,
  Send,
  Loader2,
} from 'lucide-react';
import { useAgency } from '../../context/AgencyContext';
import { MarketingStrategy, StrategicPillar, StrategyBudgetAllocation, StrategyKpi } from '../../types';

export const StrategiesView: React.FC = () => {
  const {
    strategies,
    clients,
    selectedClientId,
    setSelectedClientId,
    addStrategy,
    updateStrategyStage,
    convertMilestoneToTasks,
    setCurrentView,
    sendAiMessage,
  } = useAgency();

  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [stageFilter, setStageFilter] = useState<string>('All');
  const [expandedStrategyId, setExpandedStrategyId] = useState<string | null>('strat-001');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [taskAddedToast, setTaskAddedToast] = useState<string | null>(null);

  // New Strategy Form State
  const [newTitle, setNewTitle] = useState('');
  const [newClientId, setNewClientId] = useState(clients[0]?.id || '');
  const [newCategory, setNewCategory] = useState<MarketingStrategy['category']>('Full-Funnel');
  const [newTargetAudience, setNewTargetAudience] = useState('');
  const [newPrimaryObjective, setNewPrimaryObjective] = useState('');
  const [newExpectedRoas, setNewExpectedRoas] = useState('3.8x Blended ROAS');
  const [isAiGenerating, setIsAiGenerating] = useState(false);

  // Filter strategies
  const filteredStrategies = strategies.filter((strat) => {
    if (selectedClientId && strat.clientId !== selectedClientId) return false;
    if (categoryFilter !== 'All' && strat.category !== categoryFilter) return false;
    if (stageFilter !== 'All' && strat.stage !== stageFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = strat.title.toLowerCase().includes(q);
      const matchClient = strat.clientName.toLowerCase().includes(q);
      const matchObjective = strat.primaryObjective.toLowerCase().includes(q);
      if (!matchTitle && !matchClient && !matchObjective) return false;
    }
    return true;
  });

  const handleConvertMilestone = (strategyId: string, phaseTitle: string) => {
    convertMilestoneToTasks(strategyId, phaseTitle);
    setTaskAddedToast(`Tasks from "${phaseTitle}" successfully added to Agency Tasks Board!`);
    setTimeout(() => setTaskAddedToast(null), 4000);
  };

  const handleAiAutoPopulate = () => {
    setIsAiGenerating(true);
    const client = clients.find((c) => c.id === newClientId) || clients[0];
    setTimeout(() => {
      setNewTitle(`Omnichannel Performance Blueprint for ${client.name}`);
      setNewTargetAudience(client.memory?.targetAudience || 'Core demographic and high-intent commercial buyers');
      setNewPrimaryObjective(client.memory?.primaryGoal || 'Scale blended revenue while maintaining high ROAS');
      setNewExpectedRoas('4.0x Blended ROAS');
      setIsAiGenerating(false);
    }, 600);
  };

  const handleCreateStrategy = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const client = clients.find((c) => c.id === newClientId) || clients[0];

    const strategy: Omit<MarketingStrategy, 'id' | 'createdAt' | 'lastUpdated'> = {
      title: newTitle,
      clientId: client.id,
      clientName: client.name,
      category: newCategory,
      stage: 'Active Execution',
      targetAudience: newTargetAudience || 'High-intent digital consumers',
      primaryObjective: newPrimaryObjective || 'Scale profitable acquisitions across core channels',
      expectedRoas: newExpectedRoas,
      aiStrategicRationale: `ZAI Strategy Agent tailored this blueprint specifically for ${client.name}'s industry (${client.industry}). Focuses on eliminating creative fatigue, optimizing conversion pathways, and scaling high-intent channels.`,
      channelMix: ['Meta Ads', 'Google Ads', 'Klaviyo Email', 'Organic Content'],
      budgetAllocation: [
        { channel: 'Meta Ads', percentage: 50, amount: (client.monthlyAdSpend || 10000) * 0.5 },
        { channel: 'Google Search & PMax', percentage: 30, amount: (client.monthlyAdSpend || 10000) * 0.3 },
        { channel: 'Email & Retention Automations', percentage: 15, amount: (client.monthlyAdSpend || 10000) * 0.15 },
        { channel: 'Creative Testing & UGC', percentage: 5, amount: (client.monthlyAdSpend || 10000) * 0.05 },
      ],
      strategicPillars: [
        {
          title: 'Full-Funnel Paid Acquisition',
          description: 'Deploy Advantage+ and exact match search campaigns with disciplined budget caps.',
          tactics: [
            'Test 4 distinct hooks every 10 days to combat creative fatigue',
            'Deploy dynamic retargeting to website visitors within 14 days of visit',
            'Enforce negative keyword exclusions to prevent unqualified spend bleed',
          ],
        },
        {
          title: 'High-Converting On-Site Experience',
          description: 'Eliminate friction on landing pages with streamlined forms and proof elements.',
          tactics: [
            'Implement mobile-first sticky call-to-action button',
            'Add customer review badges and clinical/editorial verification proof points',
            'A/B test headline variants targeting customer primary pain points',
          ],
        },
        {
          title: 'Retention & Customer Lifetime Value',
          description: 'Maximize repeat purchases through automated lifecycle email flows.',
          tactics: [
            'Deploy 4-part welcome sequence with founder story',
            'Set up 3-step cart abandonment recovery sequence',
            'Send timed replenishment re-order notification before product depletion',
          ],
        },
      ],
      kpis: [
        { metric: 'Blended ROAS', target: newExpectedRoas, current: '3.4x' },
        { metric: 'Cost Per Acquisition (CPA)', target: '< $32.00', current: '$35.50' },
        { metric: 'Landing Page Conversion Rate', target: '> 3.2%', current: '2.1%' },
      ],
      actionRoadmap: [
        {
          phase: 'Phase 1: Foundation & Audit',
          duration: 'Weeks 1–2',
          status: 'In Progress',
          tasks: [
            'Verify server-side pixel tracking and GA4 event parameters',
            'Conduct competitor creative and hook teardown',
            'Draft initial creative briefs in Content Studio',
          ],
        },
        {
          phase: 'Phase 2: Scale Winning Angles',
          duration: 'Weeks 3–5',
          status: 'Upcoming',
          tasks: [
            'Deploy winning creative combinations into CBO scaling sets',
            'Set up automated email flows in retention platform',
            'Evaluate weekly pacing report in ZAI Analytics',
          ],
        },
      ],
    };

    addStrategy(strategy);
    setIsCreateModalOpen(false);
    setNewTitle('');
    setNewTargetAudience('');
    setNewPrimaryObjective('');
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* 1. View Header */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="font-display font-bold text-slate-950 text-xl tracking-tight">
              Marketing Strategies & Growth Blueprints
            </h1>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-violet-50 text-violet-700 font-semibold border border-violet-100">
              ZAI STRATEGY AGENT
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Data-backed omnichannel marketing blueprints, budget allocation models, and execution roadmaps designed for Zahida Digital Marketing clients.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              sendAiMessage(
                'ZAI, please evaluate our active marketing strategies across all clients and recommend the highest-leverage growth sprint for this week.',
                'Strategy Agent'
              );
            }}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-violet-50 hover:bg-violet-100 text-violet-700 text-xs font-semibold border border-violet-200 transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5 text-violet-600" />
            <span>AI Strategy Review</span>
          </button>

          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-950 hover:bg-slate-800 text-white text-xs font-semibold shadow-xs transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>New Strategy</span>
          </button>
        </div>
      </div>

      {/* Toast Notification */}
      {taskAddedToast && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-900 px-4 py-3 rounded-xl text-xs flex items-center justify-between shadow-xs animate-in fade-in duration-200">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span className="font-medium">{taskAddedToast}</span>
          </div>
          <button
            onClick={() => setCurrentView('Tasks')}
            className="font-bold underline text-emerald-800 hover:text-emerald-950 ml-4 shrink-0"
          >
            View Tasks →
          </button>
        </div>
      )}

      {/* 2. Metrics Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-white border border-slate-200/90 rounded-xl p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium">Active Strategies</span>
            <Compass className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="font-display font-bold text-2xl text-slate-950 mt-1">
            {strategies.filter((s) => s.stage === 'Active Execution').length}
          </div>
          <div className="text-[10px] text-slate-500 mt-1 flex items-center gap-1">
            <span>{strategies.length} total blueprints formulated</span>
          </div>
        </div>

        <div className="bg-white border border-slate-200/90 rounded-xl p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium">Avg Target ROAS</span>
            <TrendingUp className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="font-display font-bold text-2xl text-emerald-600 mt-1">
            4.2x
          </div>
          <div className="text-[10px] text-slate-500 mt-1">Blended cross-channel efficiency</div>
        </div>

        <div className="bg-white border border-slate-200/90 rounded-xl p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium">Managed Budget Mix</span>
            <DollarSign className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="font-display font-bold text-2xl text-slate-950 mt-1">
            ${clients.reduce((acc, c) => acc + (c.monthlyAdSpend || 0), 0).toLocaleString()}
          </div>
          <div className="text-[10px] text-slate-500 mt-1">Allocated across active client retainers</div>
        </div>

        <div className="bg-white border border-slate-200/90 rounded-xl p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium">Execution Pillars</span>
            <Layers className="w-4 h-4 text-violet-500" />
          </div>
          <div className="font-display font-bold text-2xl text-slate-950 mt-1">
            {strategies.reduce((acc, s) => acc + s.strategicPillars.length, 0)}
          </div>
          <div className="text-[10px] text-slate-500 mt-1">Tactical workstreams active</div>
        </div>
      </div>

      {/* 3. Filters & Search Bar */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-3 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-2">
          {/* Client Filter */}
          <select
            value={selectedClientId || 'all'}
            onChange={(e) => setSelectedClientId(e.target.value === 'all' ? null : e.target.value)}
            className="border border-slate-200 rounded-lg px-2.5 py-1.5 bg-slate-50 text-slate-700 font-medium focus:ring-2 focus:ring-violet-500/20"
          >
            <option value="all">All Agency Clients</option>
            {clients.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>

          {/* Category Filter */}
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="border border-slate-200 rounded-lg px-2.5 py-1.5 bg-slate-50 text-slate-700 font-medium focus:ring-2 focus:ring-violet-500/20"
          >
            <option value="All">All Categories</option>
            <option value="Full-Funnel">Full-Funnel</option>
            <option value="Paid Media">Paid Media</option>
            <option value="Organic & SEO">Organic & SEO</option>
            <option value="Conversion Optimization">Conversion Optimization</option>
            <option value="Retention & Lifecycle">Retention & Lifecycle</option>
            <option value="Brand Authority">Brand Authority</option>
          </select>

          {/* Stage Filter */}
          <select
            value={stageFilter}
            onChange={(e) => setStageFilter(e.target.value)}
            className="border border-slate-200 rounded-lg px-2.5 py-1.5 bg-slate-50 text-slate-700 font-medium focus:ring-2 focus:ring-violet-500/20"
          >
            <option value="All">All Stages</option>
            <option value="Active Execution">Active Execution</option>
            <option value="Planning">Planning</option>
            <option value="Optimizing">Optimizing</option>
            <option value="Completed">Completed</option>
          </select>
        </div>

        {/* Search */}
        <div className="relative min-w-[240px]">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search strategies, goals, tactics..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-violet-500/20"
          />
        </div>
      </div>

      {/* 4. Strategy List / Cards */}
      <div className="space-y-4">
        {filteredStrategies.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center">
            <Compass className="w-10 h-10 text-slate-300 mx-auto mb-3" />
            <h3 className="font-display font-bold text-slate-900 text-sm">No strategies found</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
              Try adjusting your filters or click "New Strategy" to draft an omnichannel growth plan with ZAI.
            </p>
          </div>
        ) : (
          filteredStrategies.map((strategy) => {
            const isExpanded = expandedStrategyId === strategy.id;

            return (
              <div
                key={strategy.id}
                className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs transition-all hover:border-slate-300"
              >
                {/* Strategy Header Bar */}
                <div
                  onClick={() => setExpandedStrategyId(isExpanded ? null : strategy.id)}
                  className="p-5 cursor-pointer flex flex-col md:flex-row md:items-center justify-between gap-4 select-none hover:bg-slate-50/50 transition-colors"
                >
                  <div className="space-y-1.5 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono text-[10px] font-bold text-violet-700 bg-violet-50 border border-violet-100 px-2 py-0.5 rounded">
                        {strategy.clientName}
                      </span>
                      <span className="text-[10px] font-medium text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
                        {strategy.category}
                      </span>
                      <span
                        className={`text-[10px] font-semibold px-2 py-0.5 rounded ${
                          strategy.stage === 'Active Execution'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : strategy.stage === 'Planning'
                            ? 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                            : strategy.stage === 'Optimizing'
                            ? 'bg-amber-50 text-amber-700 border border-amber-200'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {strategy.stage}
                      </span>
                    </div>

                    <h2 className="font-display font-bold text-slate-950 text-base">
                      {strategy.title}
                    </h2>

                    <p className="text-xs text-slate-600 line-clamp-1">
                      <strong className="text-slate-800">Objective:</strong> {strategy.primaryObjective}
                    </p>
                  </div>

                  <div className="flex items-center gap-4 shrink-0">
                    <div className="text-right">
                      <div className="text-[10px] text-slate-400 font-medium uppercase">Expected Return</div>
                      <div className="font-display font-bold text-sm text-emerald-600">
                        {strategy.expectedRoas}
                      </div>
                    </div>

                    <div className="p-1.5 rounded-lg bg-slate-100 text-slate-500">
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </div>
                  </div>
                </div>

                {/* Expanded Details */}
                {isExpanded && (
                  <div className="border-t border-slate-100 p-6 bg-slate-50/30 space-y-6 animate-in fade-in duration-150">
                    {/* Strategic Rationale & Audience */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="md:col-span-2 bg-white border border-slate-200/80 rounded-xl p-4">
                        <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900 mb-2">
                          <Sparkles className="w-4 h-4 text-violet-600" />
                          <span>ZAI Strategic Rationale & Competitive Moat</span>
                        </div>
                        <p className="text-xs text-slate-600 leading-relaxed">
                          {strategy.aiStrategicRationale}
                        </p>
                      </div>

                      <div className="bg-white border border-slate-200/80 rounded-xl p-4">
                        <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900 mb-2">
                          <Target className="w-4 h-4 text-indigo-600" />
                          <span>Target Audience</span>
                        </div>
                        <p className="text-xs text-slate-600 leading-relaxed">
                          {strategy.targetAudience}
                        </p>
                      </div>
                    </div>

                    {/* Channel Mix & Budget Allocation */}
                    <div className="bg-white border border-slate-200/80 rounded-xl p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900">
                          <PieChart className="w-4 h-4 text-violet-600" />
                          <span>Recommended Channel Mix & Media Allocation</span>
                        </div>
                        <span className="text-[10px] text-slate-400 font-mono">
                          Total Allocation: ${strategy.budgetAllocation.reduce((acc, b) => acc + b.amount, 0).toLocaleString()}
                        </span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                        {strategy.budgetAllocation.map((alloc, idx) => (
                          <div key={idx} className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                            <div className="flex items-center justify-between text-xs">
                              <span className="font-semibold text-slate-800">{alloc.channel}</span>
                              <span className="font-bold text-violet-700">{alloc.percentage}%</span>
                            </div>
                            <div className="w-full bg-slate-200 rounded-full h-1.5 mt-2 overflow-hidden">
                              <div
                                className="bg-violet-600 h-1.5 rounded-full"
                                style={{ width: `${alloc.percentage}%` }}
                              />
                            </div>
                            <div className="text-[10px] text-slate-500 mt-1 font-mono">
                              ${alloc.amount.toLocaleString()} / mo
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Strategic Pillars */}
                    <div>
                      <h3 className="font-display font-bold text-xs uppercase tracking-wider text-slate-400 mb-3">
                        Core Strategic Pillars & Workstreams
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {strategy.strategicPillars.map((pillar, idx) => (
                          <div
                            key={idx}
                            className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col justify-between space-y-3"
                          >
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="w-5 h-5 rounded-full bg-violet-100 text-violet-800 text-[10px] font-bold flex items-center justify-center shrink-0">
                                  {idx + 1}
                                </span>
                                <h4 className="font-display font-bold text-xs text-slate-900">
                                  {pillar.title}
                                </h4>
                              </div>
                              <p className="text-[11px] text-slate-500 mt-1.5 leading-relaxed">
                                {pillar.description}
                              </p>
                            </div>

                            <div className="border-t border-slate-100 pt-3 space-y-1.5">
                              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Tactics:</span>
                              {pillar.tactics.map((tactic, tIdx) => (
                                <div key={tIdx} className="text-[11px] text-slate-600 flex items-start gap-1.5">
                                  <span className="text-violet-500 font-bold shrink-0">•</span>
                                  <span>{tactic}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* KPIs & Roadmap */}
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                      {/* KPIs */}
                      <div className="bg-white border border-slate-200 rounded-xl p-4">
                        <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900 mb-3">
                          <Target className="w-4 h-4 text-emerald-600" />
                          <span>Strategic KPIs & Target Benchmarks</span>
                        </div>
                        <div className="space-y-2.5">
                          {strategy.kpis.map((kpi, kIdx) => (
                            <div
                              key={kIdx}
                              className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 border border-slate-100 text-xs"
                            >
                              <span className="font-medium text-slate-700">{kpi.metric}</span>
                              <div className="flex items-center gap-3 font-mono text-[11px]">
                                <span className="text-slate-400">Current: {kpi.current}</span>
                                <span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100">
                                  Target: {kpi.target}
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Action Roadmap */}
                      <div className="bg-white border border-slate-200 rounded-xl p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900">
                            <Calendar className="w-4 h-4 text-indigo-600" />
                            <span>Actionable Execution Roadmap</span>
                          </div>
                          <span className="text-[10px] text-slate-400">3-Phase Sprint</span>
                        </div>

                        <div className="space-y-3">
                          {strategy.actionRoadmap.map((phase, pIdx) => (
                            <div
                              key={pIdx}
                              className="p-3 rounded-lg border border-slate-100 bg-slate-50/70 space-y-2"
                            >
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                  <span className="font-semibold text-xs text-slate-900">{phase.phase}</span>
                                  <span className="text-[10px] text-slate-400">({phase.duration})</span>
                                </div>
                                <span
                                  className={`text-[9px] font-bold px-2 py-0.5 rounded ${
                                    phase.status === 'Done'
                                      ? 'bg-emerald-100 text-emerald-800'
                                      : phase.status === 'In Progress'
                                      ? 'bg-amber-100 text-amber-800'
                                      : 'bg-slate-200 text-slate-700'
                                  }`}
                                >
                                  {phase.status}
                                </span>
                              </div>

                              <ul className="space-y-1">
                                {phase.tasks.map((task, tIdx) => (
                                  <li key={tIdx} className="text-[11px] text-slate-600 flex items-center gap-1.5">
                                    <CheckSquare className="w-3 h-3 text-slate-400 shrink-0" />
                                    <span>{task}</span>
                                  </li>
                                ))}
                              </ul>

                              <div className="pt-1 flex justify-end">
                                <button
                                  onClick={() => handleConvertMilestone(strategy.id, phase.phase)}
                                  className="text-[10px] font-bold text-violet-700 hover:text-violet-900 flex items-center gap-1 bg-violet-50 hover:bg-violet-100 px-2.5 py-1 rounded-md transition-colors"
                                >
                                  <Plus className="w-3 h-3" />
                                  <span>Convert to Agency Tasks</span>
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Bottom Action Footer */}
                    <div className="pt-2 flex flex-wrap items-center justify-between gap-3 border-t border-slate-200/80">
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-slate-500">Stage:</span>
                        {(['Planning', 'Active Execution', 'Optimizing', 'Completed'] as const).map((stage) => (
                          <button
                            key={stage}
                            onClick={() => updateStrategyStage(strategy.id, stage)}
                            className={`text-[10px] font-semibold px-2.5 py-1 rounded-lg transition-colors ${
                              strategy.stage === stage
                                ? 'bg-slate-900 text-white'
                                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                            }`}
                          >
                            {stage}
                          </button>
                        ))}
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => {
                            setSelectedClientId(strategy.clientId);
                            setCurrentView('Campaigns');
                          }}
                          className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                        >
                          <span>View Linked Campaigns</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* 5. Create Strategy Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-xl border border-slate-200 space-y-4 my-8">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-display font-bold text-slate-950 text-base">
                  Formulate New Marketing Strategy
                </h3>
                <p className="text-xs text-slate-500">
                  Define an omnichannel growth framework for Zahida Digital Marketing.
                </p>
              </div>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-semibold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateStrategy} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Target Client</label>
                <select
                  value={newClientId}
                  onChange={(e) => setNewClientId(e.target.value)}
                  className="w-full border border-slate-200 rounded-lg p-2 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-violet-500/20"
                >
                  {clients.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.industry})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="font-semibold text-slate-700">Strategy Title</label>
                  <button
                    type="button"
                    onClick={handleAiAutoPopulate}
                    disabled={isAiGenerating}
                    className="text-[10px] text-violet-700 hover:text-violet-900 font-bold flex items-center gap-1"
                  >
                    {isAiGenerating ? (
                      <Loader2 className="w-3 h-3 animate-spin" />
                    ) : (
                      <Sparkles className="w-3 h-3 text-violet-600" />
                    )}
                    <span>Autofill with ZAI</span>
                  </button>
                </div>
                <input
                  type="text"
                  required
                  placeholder="e.g. Omnichannel DTC Scaling & Creative Fatigue Defense"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full border border-slate-200 rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-violet-500/20"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Strategic Category</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as any)}
                    className="w-full border border-slate-200 rounded-lg p-2 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-violet-500/20"
                  >
                    <option value="Full-Funnel">Full-Funnel</option>
                    <option value="Paid Media">Paid Media</option>
                    <option value="Organic & SEO">Organic & SEO</option>
                    <option value="Conversion Optimization">Conversion Optimization</option>
                    <option value="Retention & Lifecycle">Retention & Lifecycle</option>
                    <option value="Brand Authority">Brand Authority</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Target ROAS / KPI</label>
                  <input
                    type="text"
                    value={newExpectedRoas}
                    onChange={(e) => setNewExpectedRoas(e.target.value)}
                    placeholder="e.g. 4.0x Blended ROAS"
                    className="w-full border border-slate-200 rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-violet-500/20"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Target Audience</label>
                <input
                  type="text"
                  placeholder="e.g. Women 24–45 with focus on clean ingredients, dermatologist backed"
                  value={newTargetAudience}
                  onChange={(e) => setNewTargetAudience(e.target.value)}
                  className="w-full border border-slate-200 rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-violet-500/20"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Primary Objective</label>
                <textarea
                  rows={2}
                  placeholder="e.g. Scale online sales from $95k to $160k while defending blended ROAS ≥ 3.5x"
                  value={newPrimaryObjective}
                  onChange={(e) => setNewPrimaryObjective(e.target.value)}
                  className="w-full border border-slate-200 rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-violet-500/20"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-slate-950 hover:bg-slate-800 text-white font-semibold shadow-xs"
                >
                  Create Strategy Blueprint
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
