import React, { useState } from 'react';
import {
  Settings,
  ShieldCheck,
  Building2,
  Plug,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Save,
  Download,
  Trash2,
  Database,
} from 'lucide-react';
import { useAgency } from '../../context/AgencyContext';

export const SettingsView: React.FC = () => {
  const {
    exportBackup,
    clearAllDataToFreshSlate,
    isDemoMode,
    setIsDemoMode,
  } = useAgency();

  const [agencyName, setAgencyName] = useState('ZAHIDA DIGITAL MARKETING');
  const [productName, setProductName] = useState('ZAHIDA AI');
  const [tagline, setTagline] = useState('Your Intelligent Digital Marketing Partner');
  const [ownerName, setOwnerName] = useState('Zahida Khan');
  const [ownerEmail, setOwnerEmail] = useState('zahida@zahidadigital.com');
  const [isSaved, setIsSaved] = useState(false);

  const [integrations, setIntegrations] = useState([
    {
      id: 'meta',
      name: 'Meta Ads Graph API (v20.0)',
      category: 'Paid Advertising',
      status: 'Ready for OAuth Token',
      description: 'Synchronizes Facebook & Instagram ad campaign metrics, ad set budgets, and creative fatigue signals.',
    },
    {
      id: 'google-ads',
      name: 'Google Ads API (REST/gRPC)',
      category: 'Paid Advertising',
      status: 'Ready for OAuth Token',
      description: 'Ingests search impression share, keyword CPC bids, and high-intent query performance.',
    },
    {
      id: 'ga4',
      name: 'Google Analytics 4 (Data API)',
      category: 'Web Analytics',
      status: 'Ready for Service Account',
      description: 'Tracks full-funnel session attribution, landing page bounce rates, and conversion events.',
    },
    {
      id: 'tiktok',
      name: 'TikTok Commercial Ads API',
      category: 'Short-Form Video Ads',
      status: 'Ready for OAuth Token',
      description: 'Monitors short-form video retention curves and automated video creative unboxing metrics.',
    },
    {
      id: 'klaviyo',
      name: 'Klaviyo & Email Webhooks',
      category: 'Email Marketing & Retention',
      status: 'API Key Configured',
      description: 'Monitors automated welcome flows, cart abandonment recovery, and VIP customer segment lists.',
    },
  ]);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* 1. Header */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="font-display font-bold text-slate-950 text-lg tracking-tight">
              Agency Settings & API Infrastructure
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 font-semibold">
              PHASE 1 CONFIGURATION
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Branding parameters, multi-agent safety rules, and official marketing integration connectors
          </p>
        </div>

        {isSaved && (
          <div className="flex items-center gap-1.5 text-xs text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Settings saved successfully</span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Column: Brand & Autonomy Policies */}
        <div className="space-y-6">
          {/* Agency Brand Identity Form */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs space-y-4">
            <h3 className="font-display font-bold text-slate-900 text-sm pb-2 border-b border-slate-100 flex items-center gap-2">
              <Building2 className="w-4 h-4 text-indigo-600" />
              <span>Agency Brand Identity</span>
            </h3>

            <form onSubmit={handleSave} className="space-y-3 text-xs">
              <div>
                <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
                  Product Name
                </label>
                <input
                  type="text"
                  value={productName}
                  onChange={(e) => setProductName(e.target.value)}
                  className="w-full border border-slate-200 rounded-lg p-2.5 bg-slate-50 focus:bg-white outline-hidden"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
                  Parent Agency Brand
                </label>
                <input
                  type="text"
                  value={agencyName}
                  onChange={(e) => setAgencyName(e.target.value)}
                  className="w-full border border-slate-200 rounded-lg p-2.5 bg-slate-50 focus:bg-white outline-hidden"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
                  Tagline
                </label>
                <input
                  type="text"
                  value={tagline}
                  onChange={(e) => setTagline(e.target.value)}
                  className="w-full border border-slate-200 rounded-lg p-2.5 bg-slate-50 focus:bg-white outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
                    Founder & Owner
                  </label>
                  <input
                    type="text"
                    value={ownerName}
                    onChange={(e) => setOwnerName(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2.5 bg-slate-50 focus:bg-white outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
                    Owner Direct Email
                  </label>
                  <input
                    type="email"
                    value={ownerEmail}
                    onChange={(e) => setOwnerEmail(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2.5 bg-slate-50 focus:bg-white outline-hidden"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs transition-colors shadow-xs"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Save Agency Profile</span>
              </button>
            </form>
          </div>

          {/* AI Autonomy & Safety Governance */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs space-y-4">
            <h3 className="font-display font-bold text-slate-900 text-sm pb-2 border-b border-slate-100 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>AI Autonomy & Safety Policy</span>
            </h3>

            <div className="space-y-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-between">
                <div>
                  <div className="font-semibold text-slate-900">Green Tier Autonomous Execution</div>
                  <div className="text-[11px] text-slate-500">Allow autonomous SERP crawls & internal task generation</div>
                </div>
                <input type="checkbox" defaultChecked className="w-4 h-4 text-indigo-600 rounded" />
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-between">
                <div>
                  <div className="font-semibold text-slate-900">Yellow Tier Human-in-the-Loop Gating</div>
                  <div className="text-[11px] text-slate-500">Mandate Zahida Khan sign-off before ad budget or social publish</div>
                </div>
                <input type="checkbox" defaultChecked disabled className="w-4 h-4 text-indigo-600 rounded" />
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-between">
                <div>
                  <div className="font-semibold text-slate-900">Zero-Hallucination Policy</div>
                  <div className="text-[11px] text-slate-500">Disclose missing API integrations rather than simulating fake data</div>
                </div>
                <input type="checkbox" defaultChecked disabled className="w-4 h-4 text-indigo-600 rounded" />
              </div>
            </div>
          </div>

          {/* Data Backup & Demo Data Management */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs space-y-4">
            <h3 className="font-display font-bold text-slate-900 text-sm pb-2 border-b border-slate-100 flex items-center gap-2">
              <Database className="w-4 h-4 text-indigo-600" />
              <span>Agency Data Governance & Backups</span>
            </h3>

            <div className="space-y-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-between">
                <div>
                  <div className="font-semibold text-slate-900">Demo Data Mode</div>
                  <div className="text-[11px] text-slate-500">
                    {isDemoMode ? 'Showing labeled simulation accounts for onboarding walkthrough.' : 'Live mode active: only user saved data is displayed.'}
                  </div>
                </div>
                <button
                  onClick={() => setIsDemoMode(!isDemoMode)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                    isDemoMode ? 'bg-amber-100 text-amber-900' : 'bg-emerald-100 text-emerald-900'
                  }`}
                >
                  {isDemoMode ? 'Demo Active' : 'Live Active'}
                </button>
              </div>

              <div className="pt-2 flex flex-wrap gap-2">
                <button
                  onClick={exportBackup}
                  className="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold shadow-xs transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Export Backup (JSON)</span>
                </button>

                <button
                  onClick={() => {
                    if (confirm('Are you sure you want to clear demo accounts and switch to a fresh live agency slate?')) {
                      clearAllDataToFreshSlate();
                    }
                  }}
                  className="flex items-center gap-1.5 px-3.5 py-2 border border-rose-200 hover:bg-rose-50 text-rose-700 rounded-xl font-semibold transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Reset to Clean Slate</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Official Marketing API Integrations Hub */}
        <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <h3 className="font-display font-bold text-slate-900 text-sm flex items-center gap-2">
              <Plug className="w-4 h-4 text-indigo-600" />
              <span>Official Marketing Connectors Hub</span>
            </h3>
            <span className="text-[10px] font-mono text-slate-400">PHASE 1 ARCHITECTURE</span>
          </div>
          <p className="text-xs text-slate-500">
            Official marketing platform integration architecture. In Phase 1, data schema and tool contracts are normalized; OAuth authentication connects in Phase 3.
          </p>

          <div className="space-y-3">
            {integrations.map((item) => (
              <div
                key={item.id}
                className="p-4 rounded-xl border border-slate-200/90 hover:border-slate-300 bg-white space-y-2 text-xs transition-colors"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-[10px] font-semibold text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded">
                      {item.category}
                    </span>
                    <h4 className="font-semibold text-slate-900 mt-1">{item.name}</h4>
                  </div>
                  <span className="text-[10px] font-mono font-medium text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
                    {item.status}
                  </span>
                </div>

                <p className="text-[11px] text-slate-500 leading-relaxed">{item.description}</p>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-[10px] text-slate-400 font-mono">SDK Ready</span>
                  <button
                    onClick={() => alert(`Connection Flow: Client Secret & OAuth callback configured for ${item.name}. Ready for Phase 3 activation.`)}
                    className="text-xs font-semibold text-indigo-600 hover:text-indigo-800"
                  >
                    Configure Connector →
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
