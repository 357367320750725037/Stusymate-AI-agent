import React, { useState } from 'react';
import {
  PenTool,
  Sparkles,
  Send,
  Loader2,
  Calendar,
  CheckCircle2,
  Copy,
  Check,
  RefreshCw,
  SlidersHorizontal,
  Layers,
  ArrowRight,
  ShieldCheck,
  Globe2,
  FileText,
  Video,
  Mail,
  Megaphone,
  Layout,
  Image as ImageIcon,
  Repeat,
  Edit3,
} from 'lucide-react';
import { useAgency } from '../../context/AgencyContext';
import { ContentItem, ContentLanguage, ContentFormatType } from '../../types';

export const ContentStudioView: React.FC = () => {
  const {
    clients,
    selectedClientId,
    setSelectedClientId,
    addContentItem,
    setCurrentView,
  } = useAgency();

  const selectedClient = clients.find((c) => c.id === selectedClientId) || clients[0];

  const [language, setLanguage] = useState<ContentLanguage>('English');
  const [formatType, setFormatType] = useState<ContentFormatType>('Instagram Caption');
  const [topic, setTopic] = useState('Why modern skincare routines break the barrier');
  const [tone, setTone] = useState('Authoritative & Science-Backed');
  const [objective, setObjective] = useState('Conversions & Retention');
  const [ctaType, setCtaType] = useState('Shop Link in Bio');
  const [keywords, setKeywords] = useState('ceramides, barrier repair, bio-fermented');
  const [selectedVariationIndex, setSelectedVariationIndex] = useState(0);

  const [isGenerating, setIsGenerating] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  // 3 Distinct AI Variations
  const [variations, setVariations] = useState([
    {
      angleName: 'Angle 1: Direct Clinical Proof (High-Converting)',
      hook: language === 'Urdu'
        ? 'اگر منہ دھونے کے 20 منٹ بعد آپ کی جلد خشک اور کھنچی ہوئی محسوس ہو، تو آپ کا اسکن بیریئر ٹوٹ رہا ہے۔'
        : language === 'Roman Urdu'
        ? 'Agar chehra dhonay ke 20 minute baad skin tight mehsoos ho, toh aapka moisture barrier damage ho raha hai.'
        : 'If your skin feels tight 20 minutes after cleansing, your moisture barrier is officially breaking down.',
      caption: language === 'Urdu'
        ? `زیادہ تر لوگ جلد کھردری ہونے پر سخت اسکرب استعمال کرتے ہیں، لیکن 90 فیصد مسائل کی وجہ بیریئر کی کمزوری ہوتی ہے۔\n\n14 دنوں میں جلد کو دوبارہ بحال کرنے کے 3 طبی اجزاء:\n1. بائیو فرمینٹڈ اسکوئلین\n2. ڈوئل سیرامائڈز این پی\n3. سینٹیلا ایکسٹریکٹ\n\nلوکینا اسکن کو کے ساتھ قدرتی نکھار کا تجربہ کریں۔`
        : language === 'Roman Urdu'
        ? `Aksar log skin rough hone par scrub karte hain, lekin 90% masla broken lipid barrier ka hota hai.\n\n14 dino mein skin repair karne ke 3 verified ingredients:\n1. Bio-fermented squalane\n2. Dual ceramides NP & EOP\n3. Centella Asiatica isolate\n\nLumina Barrier Serum ke sath apni skin ko revitalise karein.`
        : `Most people scrub harder when their skin feels rough, but 90% of the time, the culprit is a broken lipid barrier.\n\nHere are 3 clinically proven active ingredients that rebuild it in 14 days:\n1. Bio-fermented squalane (locks cellular hydration)\n2. Dual ceramides NP & EOP (reconstructs lipid matrix)\n3. Centella Asiatica isolate (calms redness)\n\nExperience clinical restoration with Lumina Botanical Barrier Serum.`,
      body: 'Script / Copy Outline: Macro texture video of calming serum application + clinical 28-day repair data graphic.',
      cta: language === 'Urdu' ? 'باائیو میں موجود لنک پر کلک کر کے آرڈر کریں۔' : language === 'Roman Urdu' ? 'Bio mein diye gaye link se apna starter kit claim karein.' : 'Tap link in bio to claim your 28-day barrier starter ritual.',
      hashtags: ['#CleanSkincare', '#MoistureBarrier', '#SkinCareRoutine', `#${selectedClient.name.replace(/\s+/g, '')}`],
      creativeBrief: 'Warm neutral travertine background, macro camera close-up of amber glass dropper, serene natural lighting.',
    },
    {
      angleName: 'Angle 2: Contrarian / Myth-Busting',
      hook: language === 'Urdu'
        ? 'وہ سب سے بڑی غلطی جو 90 فیصد خواتین اسکن کیئر میں کرتی ہیں؟ پروڈکٹس کی زیادتی۔'
        : language === 'Roman Urdu'
        ? 'Wo sab se bari ghalti jo 90% log skincare mein karte hain? Zaroorat se zyada products use karna.'
        : 'The biggest mistake people make with their skincare routine? Layering 7 different products that cancel each other out.',
      caption: language === 'Urdu'
        ? `آپ کو 10 مرحلوں پر مشتمل روٹین کی ضرورت نہیں ہے۔ آپ کو صرف ایک متوازن اور تصدیق شدہ بیریئر سیرم کی ضرورت ہے۔`
        : language === 'Roman Urdu'
        ? `Aapko 10 steps wali routine ki zaroorat nahi hai. Aapko sirf aik scientific, barrier-repair formula chahiye.`
        : `You don't need a 10-step routine that exhausts your skin. Streamline your ritual with one potent, clinically balanced barrier serum that does the work of three.`,
      body: 'Contrarian problem-solution angle contrasting complicated shelf clutter against clean, minimal 1-step barrier solution.',
      cta: language === 'Urdu' ? 'آج ہی آزمائیں۔ لنک بائیو میں ہے۔' : language === 'Roman Urdu' ? 'Link in bio check karein aur asaan skincare apnayein.' : 'Discover minimalist clinical skincare. Link in bio.',
      hashtags: ['#MinimalistSkincare', '#SkinBarrierFirst', '#DermAdvice'],
      creativeBrief: 'Minimalist side-by-side comparison visual: messy shelf vs single elegant bottle.',
    },
    {
      angleName: 'Angle 3: Storytelling & Customer Transformation',
      hook: language === 'Urdu'
        ? '2 سال مسلسل بریک آؤٹس اور جلن کے بعد، آخر کار حل مل گیا۔'
        : language === 'Roman Urdu'
        ? '2 saal tak breakouts aur redness se larnay ke baad, aakhir car solution mil gaya.'
        : '"After two straight years of redness and reactive skin, I stopped testing random viral trends and did this."',
      caption: language === 'Urdu'
        ? `حقیقی کسٹمرز کے نتائج دیکھیں جنہوں نے 14 دنوں میں اپنی جلد کا بیریئر بحال کیا۔`
        : language === 'Roman Urdu'
        ? `Real customer journey: 14 days of gentle barrier repair and zero harsh actives.`
        : `Real customer story: Within 14 days of eliminating harsh exfoliants and adopting bio-fermented ceramides, reactive redness dropped by 72%.`,
      body: 'Emotional founder/customer transformation arch supported by verified lab measurement metrics.',
      cta: language === 'Urdu' ? 'اپنا سفر آج شروع کریں۔' : language === 'Roman Urdu' ? 'Apna transformation aaj shuru karein.' : 'Read verified clinical reviews and start your transformation today.',
      hashtags: ['#SkinTransformation', '#Ceramides', '#RealResults'],
      creativeBrief: 'Authentic documentary style, clean unedited skin texture, warm confident voiceover.',
    },
  ]);

  const activeVariation = variations[selectedVariationIndex] || variations[0];

  const handleGenerate = () => {
    setIsGenerating(true);
    setTimeout(() => {
      setIsGenerating(false);

      const clientName = selectedClient.name;
      const clientDiff = selectedClient.memory.keyDifferentiators[0] || 'quality';

      setVariations([
        {
          angleName: 'Angle 1: Direct Benefit Hook (High-Intent)',
          hook: language === 'Urdu'
            ? `${clientName} کا نیا حل: کیا آپ اپنے بزنس کے اہداف حاصل کر رہے ہیں؟`
            : language === 'Roman Urdu'
            ? `${clientName} ka premium solution: Kese aap behtar results hasil kar saktay hain.`
            : `Why top brands in ${selectedClient.industry} are ditching legacy methods for ${clientName}.`,
          caption: language === 'Urdu'
            ? `ہم پیش کرتے ہیں بہترین معیار اور پائیدار نتائج۔ ہمارے ساتھ جڑیں اور فرق محسوس کریں۔`
            : language === 'Roman Urdu'
            ? `Discover why ${clientName} is setting the benchmark in ${selectedClient.industry} with proven ${clientDiff}.`
            : `Discover why ${clientName} is setting the benchmark in ${selectedClient.industry} with proven ${clientDiff}.\n\nBuilt for: ${selectedClient.memory.targetAudience}.\nKey Benefit: ${selectedClient.memory.primaryGoal}.`,
          body: `Format: ${formatType} tailored for ${selectedClient.memory.mainPlatform}. Tone: ${tone}.`,
          cta: language === 'Urdu' ? 'تفصیلات کے لیے ابھی رابطہ کریں۔' : language === 'Roman Urdu' ? 'Abhi link pe click karein.' : ctaType,
          hashtags: ['#DigitalMarketing', `#${clientName.replace(/\s+/g, '')}`, '#GrowthStrategy'],
          creativeBrief: 'High contrast editorial typography, minimal distraction, professional brand color palette.',
        },
        {
          angleName: 'Angle 2: Curiosity & Engagement',
          hook: language === 'Urdu'
            ? 'ایک خاص بات جو آپ کے حریف آپ کو کبھی نہیں بتائیں گے...'
            : language === 'Roman Urdu'
            ? 'Aik secret jo aapke competitors aapko kabhi nahi batayein ge...'
            : `The silent bottleneck costing ${selectedClient.industry} teams time and money in 2026.`,
          caption: language === 'Urdu'
            ? `جب آپ صحیح حکمت عملی اپناتے ہیں تو ترقی آسان ہو جاتی ہے۔`
            : language === 'Roman Urdu'
            ? `Jab aap structured strategy use karte hain toh growth predictable ho jati hai.`
            : `Most teams focus on the wrong metric. Here is how ${clientName} solves this from day one with ${clientDiff}.`,
          body: `Engagement angle with strong problem agitator.`,
          cta: ctaType,
          hashtags: ['#IndustryInsights', '#Strategy', `#${clientName.replace(/\s+/g, '')}`],
          creativeBrief: 'Sleek carousel design with dark slate background and subtle electric indigo accents.',
        },
        {
          angleName: 'Angle 3: Social Proof & ROI Proof',
          hook: language === 'Urdu'
            ? 'ثابت شدہ نتائج: 180 فیصد بہتری بغیر اضافی اخراجات کے۔'
            : language === 'Roman Urdu'
            ? 'Verified results: 180% growth without doubling budget.'
            : `"Here is exactly how our partners achieved measurable growth in 90 days."`,
          caption: language === 'Urdu'
            ? `حقیقی اعداد و شمار اور شفاف رپورٹنگ۔`
            : language === 'Roman Urdu'
            ? `Real data and transparent results for ${selectedClient.name}.`
            : `Concrete outcomes for ${selectedClient.name}:\n- Focused positioning\n- Targeted acquisition\n- High retention.`,
          body: `Proof-driven conversion copy.`,
          cta: ctaType,
          hashtags: ['#CaseStudy', '#MarketingROI', '#AgencyLife'],
          creativeBrief: 'Clean typographic layout with authentic metric figures and executive testimonial stamp.',
        },
      ]);
    }, 900);
  };

  const handleCopy = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    setTimeout(() => setCopiedField(null), 1500);
  };

  const handlePushToCalendar = () => {
    addContentItem({
      clientId: selectedClient.id,
      clientName: selectedClient.name,
      platform: formatType.includes('LinkedIn') ? 'LinkedIn' : formatType.includes('TikTok') ? 'TikTok' : 'Instagram',
      contentType: formatType.includes('Reel') || formatType.includes('Script') ? 'Reel' : formatType.includes('Carousel') ? 'Carousel' : 'Post',
      title: `${selectedClient.name}: ${formatType} (${language})`,
      hook: activeVariation.hook,
      caption: activeVariation.caption,
      body: activeVariation.body,
      cta: activeVariation.cta,
      hashtags: activeVariation.hashtags,
      creativeBrief: activeVariation.creativeBrief,
      scheduledDate: new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0],
      scheduledTime: '11:00 AM',
      assignedTo: 'Sara Malik',
    });
    setCurrentView('Content Calendar');
  };

  const formatCategories: Array<{ label: ContentFormatType; icon: any }> = [
    { label: 'Instagram Caption', icon: PenTool },
    { label: 'Reel / Short Script', icon: Video },
    { label: 'LinkedIn Thought Leadership', icon: FileText },
    { label: 'Ad Copy Variations', icon: Megaphone },
    { label: 'Landing Page Copy', icon: Layout },
    { label: 'Email Campaign', icon: Mail },
    { label: 'YouTube Outline', icon: Video },
    { label: 'Blog Article', icon: FileText },
    { label: 'Promotional Image Prompt', icon: ImageIcon },
    { label: 'Content Repurposing', icon: Repeat },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* 1. Header with Language and Client Switcher */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="font-display font-bold text-slate-950 text-lg tracking-tight">
              AI Content Studio & Multilingual Copy Suite
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 font-semibold">
              3 VARIATIONS ENGINE
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Crafts conversion-focused hooks, captions, video scripts, ad copy, and creative briefs in English, Urdu, and Roman Urdu
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Language Selector */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-lg text-xs">
            <Globe2 className="w-3.5 h-3.5 text-slate-500 ml-1.5" />
            {(['English', 'Urdu', 'Roman Urdu'] as ContentLanguage[]).map((lang) => (
              <button
                key={lang}
                onClick={() => setLanguage(lang)}
                className={`px-2.5 py-1 font-medium rounded-md transition-colors ${
                  language === lang
                    ? 'bg-white text-slate-900 shadow-xs font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {lang === 'Urdu' ? 'اردو' : lang}
              </button>
            ))}
          </div>

          {/* Client Selector */}
          <select
            value={selectedClientId || selectedClient.id}
            onChange={(e) => setSelectedClientId(e.target.value)}
            className="text-xs border border-slate-200 rounded-lg px-2.5 py-1.5 bg-slate-50 font-medium text-slate-800"
          >
            {clients.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* 2. Format Selector Pill Bar */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-3.5 shadow-xs overflow-x-auto scrollbar-none flex items-center gap-1.5">
        {formatCategories.map((fmt) => {
          const Icon = fmt.icon;
          const isActive = formatType === fmt.label;
          return (
            <button
              key={fmt.label}
              onClick={() => setFormatType(fmt.label)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs whitespace-nowrap transition-colors font-medium ${
                isActive
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <Icon className="w-3.5 h-3.5 shrink-0" />
              <span>{fmt.label}</span>
            </button>
          );
        })}
      </div>

      {/* 3. Generator Split: Parameters (5 cols) & 3-Variation Deck (7 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Generator Controls */}
        <div className="lg:col-span-5 bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <h3 className="font-display font-bold text-slate-900 text-sm">
              Brief Inputs & Targeting
            </h3>
            <span className="text-[10px] font-mono text-indigo-600 font-semibold">
              LANG: {language.toUpperCase()}
            </span>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
                Core Topic / Friction Point
              </label>
              <textarea
                rows={2}
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="What core problem, offer, or customer benefit are we addressing?"
                className="w-full border border-slate-200 rounded-lg p-2.5 bg-slate-50 focus:bg-white outline-hidden resize-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
                  Tone of Voice
                </label>
                <input
                  type="text"
                  value={tone}
                  onChange={(e) => setTone(e.target.value)}
                  className="w-full border border-slate-200 rounded-lg px-2.5 py-1.5 bg-slate-50 focus:bg-white outline-hidden"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
                  Call to Action (CTA)
                </label>
                <input
                  type="text"
                  value={ctaType}
                  onChange={(e) => setCtaType(e.target.value)}
                  className="w-full border border-slate-200 rounded-lg px-2.5 py-1.5 bg-slate-50 focus:bg-white outline-hidden"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
                Target Keywords & Angles
              </label>
              <input
                type="text"
                value={keywords}
                onChange={(e) => setKeywords(e.target.value)}
                className="w-full border border-slate-200 rounded-lg px-2.5 py-1.5 bg-slate-50 focus:bg-white outline-hidden"
              />
            </div>

            {/* Injected Client Memory Preview */}
            <div className="p-3 rounded-xl bg-indigo-50/30 border border-indigo-100 text-[11px] text-slate-700 space-y-1">
              <span className="font-semibold text-indigo-900 block">Auto-Injected Client Memory:</span>
              <div>Client: <strong>{selectedClient.name}</strong> ({selectedClient.industry})</div>
              <div>Audience: {selectedClient.memory.targetAudience}</div>
              <div>Differentiator: {selectedClient.memory.keyDifferentiators[0]}</div>
            </div>

            <button
              onClick={handleGenerate}
              disabled={isGenerating}
              className="w-full py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs flex items-center justify-center gap-2 transition-colors shadow-xs"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Synthesizing 3 Variations...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Generate 3 Multi-Angle Variations</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* 3-Variation Deck & Live Editor */}
        <div className="lg:col-span-7 bg-white border border-slate-200/90 rounded-2xl p-6 shadow-xs space-y-4">
          {/* Variation Tabs */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl text-xs">
              {variations.map((v, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedVariationIndex(idx)}
                  className={`px-3 py-1 font-semibold rounded-lg transition-colors ${
                    selectedVariationIndex === idx
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Variation {idx + 1}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2 self-start sm:self-auto">
              <button
                onClick={handlePushToCalendar}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold transition-colors shadow-xs"
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>Add to Content Calendar</span>
              </button>
            </div>
          </div>

          <div className="text-xs font-semibold text-indigo-700">
            {activeVariation.angleName}
          </div>

          {/* Section 1: The Hook */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 relative">
            <div className="flex items-center justify-between text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
              <span>Viral Hook / Headline</span>
              <button
                onClick={() => handleCopy(activeVariation.hook, 'hook')}
                className="text-slate-400 hover:text-slate-700"
              >
                {copiedField === 'hook' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
            <div
              dir={language === 'Urdu' ? 'rtl' : 'ltr'}
              className="text-xs font-semibold text-slate-900 leading-relaxed font-sans"
            >
              "{activeVariation.hook}"
            </div>
          </div>

          {/* Section 2: Full Caption / Script (Editable) */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 relative space-y-1.5">
            <div className="flex items-center justify-between text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
              <span>Primary Copy & Caption (Editable Draft)</span>
              <button
                onClick={() => handleCopy(activeVariation.caption, 'caption')}
                className="text-slate-400 hover:text-slate-700"
              >
                {copiedField === 'caption' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
            <textarea
              dir={language === 'Urdu' ? 'rtl' : 'ltr'}
              rows={6}
              value={activeVariation.caption}
              onChange={(e) => {
                const updated = [...variations];
                updated[selectedVariationIndex].caption = e.target.value;
                setVariations(updated);
              }}
              className="w-full text-xs text-slate-800 bg-white border border-slate-200 rounded-lg p-2.5 outline-hidden focus:border-indigo-500 leading-relaxed font-sans resize-none"
            />
          </div>

          {/* Section 3: Visual Brief & CTA */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
              <span className="text-[10px] font-semibold text-slate-400 uppercase">Visual Direction Specs</span>
              <p className="text-slate-700 mt-1 leading-relaxed">{activeVariation.creativeBrief}</p>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
              <span className="text-[10px] font-semibold text-slate-400 uppercase">Hashtags & Offer CTA</span>
              <p className="text-indigo-600 font-medium mt-1">{activeVariation.cta}</p>
              <div className="flex flex-wrap gap-1 mt-1.5">
                {activeVariation.hashtags.map((h, i) => (
                  <span key={i} className="text-[10px] font-mono text-slate-600 bg-white px-1.5 py-0.5 rounded border border-slate-200">
                    {h}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
