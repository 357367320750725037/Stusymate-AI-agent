import React, { useState } from 'react';
import {
  Megaphone,
  Plus,
  Search,
  Filter,
  TrendingUp,
  AlertTriangle,
  Play,
  Pause,
  Sparkles,
  ArrowRight,
  DollarSign,
  BarChart2,
  CheckCircle2,
  ExternalLink,
  Wand2,
  Layers,
  ChevronRight,
  ShieldCheck,
  CheckSquare,
} from 'lucide-react';
import { useAgency } from '../../context/AgencyContext';
import { Campaign } from '../../types';

export const CampaignsView: React.FC = () => {
  const {
    campaigns,
    clients,
    addCampaign,
    toggleCampaignStatus,
    setQuickModalType,
    sendAiMessage,
    setIsAskZaiOpen,
    setCurrentView,
  } = useAgency();

  const [activeTab, setActiveTab] = useState<'manager' | 'wizard'>('manager');
  const [platformFilter, setPlatformFilter] = useState<string>('All');
  const [healthFilter, setHealthFilter] = useState<string>('All');
  const [search, setSearch] = useState('');
  const [selectedCampaign, setSelectedCampaign] = useState<Campaign | null>(campaigns[0] || null);

  // Wizard state
  const [wizardStep, setWizardStep] = useState(1);
  const [wizardData, setWizardData] = useState({
    clientId: clients[0]?.id || '',
    name: 'Q4 Barrier Repair Advantage+ Scale',
    objective: 'Conversions' as Campaign['objective'],
    productService: 'Clinical Barrier Repair Serum (30ml)',
    targetAudience: 'Women 24-45 experiencing barrier breakdown, redness, and sensitive skin reactivity',
    platform: 'Meta Ads' as Campaign['platform'],
    offer: 'Starter Ritual: 20% off first order + complimentary barrier sample',
    cta: 'Claim Your 28-Day Ritual',
    monthlyBudget: 12000,
    targetRoas: '3.8x',
    generatedBlueprint: null as any,
  });

  const [isGeneratingBlueprint, setIsGeneratingBlueprint] = useState(false);

  const handleGenerateBlueprint = () => {
    setIsGeneratingBlueprint(true);
    setTimeout(() => {
      setIsGeneratingBlueprint(false);
      setWizardData((prev) => ({
        ...prev,
        generatedBlueprint: {
          audienceHypotheses: [
            'Hypothesis A: Active ingredient conscious consumers respond to ceramide ratio transparency over generic "clean beauty" buzzwords.',
            'Hypothesis B: Frustrated users who over-exfoliated respond best to relatable before-and-after skin barrier education.',
          ],
          messagingAngles: [
            { title: 'Angle 1 (Clinical Barrier Proof)', hook: 'Why stripping your skin with harsh acids is making your breakouts worse.', cta: 'Switch to Bio-Fermented Barrier Repair' },
            { title: 'Angle 2 (Dermatologist Validation)', hook: 'The 3 ingredients board-certified dermatologists recommend for immediate skin barrier repair.', cta: 'Read the Clinical 28-Day Study' },
            { title: 'Angle 3 (Minimalist Routine)', hook: 'Replace your 7-step skincare shelf with one potent barrier matrix.', cta: 'Claim Your Starter Kit' },
          ],
          creativeConcepts: [
            'Short-form UGC video: Real user showing skin tightness after cleansing vs soothing calming relief.',
            'High-contrast carousel: Microscopic lipid barrier diagram vs restored barrier lipid seal.',
          ],
          launchChecklist: [
            { item: 'Meta Pixel & CAPI Conversion Events verified', completed: true },
            { item: 'Landing page mobile speed optimized (< 2.2s LCP)', completed: true },
            { item: '3 UGC Video creative cuts reviewed and approved by Zahida Khan', completed: false },
            { item: 'Exclusion custom audiences (30-day past purchasers) added', completed: true },
          ],
        },
      }));
      setWizardStep(4);
    }, 1000);
  };

  const handleSaveWizardCampaign = () => {
    const client = clients.find((c) => c.id === wizardData.clientId) || clients[0];
    addCampaign({
      name: wizardData.name,
      clientId: client.id,
      clientName: client.name,
      platform: wizardData.platform,
      objective: wizardData.objective,
      monthlyBudget: wizardData.monthlyBudget,
      status: 'Active',
    });
    setActiveTab('manager');
    setWizardStep(1);
  };

  const filteredCampaigns = campaigns.filter((c) => {
    const matchesSearch =
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.clientName.toLowerCase().includes(search.toLowerCase());
    const matchesPlatform = platformFilter === 'All' || c.platform === platformFilter;
    const matchesHealth = healthFilter === 'All' || c.health === healthFilter;
    return matchesSearch && matchesPlatform && matchesHealth;
  });

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* 1. Top Header */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="font-display font-bold text-slate-950 text-lg tracking-tight">
              Campaigns & Paid Ads Intelligence
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 font-semibold">
              WIZARD + TELEMETRY
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Real-time campaign telemetry, creative fatigue monitors, and structured AI campaign planning wizard
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Mode Switcher */}
          <div className="flex items-center p-1 bg-slate-100 rounded-lg text-xs">
            <button
              onClick={() => setActiveTab('manager')}
              className={`px-3 py-1 font-medium rounded-md transition-colors ${
                activeTab === 'manager' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              Campaign Manager
            </button>
            <button
              onClick={() => setActiveTab('wizard')}
              className={`px-3 py-1 font-medium rounded-md transition-colors flex items-center gap-1.5 ${
                activeTab === 'wizard' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600'
              }`}
            >
              <Wand2 className="w-3 h-3 text-indigo-600" />
              <span>Campaign Wizard</span>
            </button>
          </div>

          <button
            onClick={() => setActiveTab('wizard')}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold transition-colors shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Campaign</span>
          </button>
        </div>
      </div>

      {/* 2. Campaign Builder Wizard */}
      {activeTab === 'wizard' ? (
        <div className="bg-white border border-slate-200/90 rounded-2xl p-6 shadow-xs space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="font-display font-bold text-slate-900 text-base">
                Structured Campaign Creation Wizard
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Formulate audience hypotheses, copy variations, and launch requirements before deploying ad budget
              </p>
            </div>

            {/* Stepper Indicator */}
            <div className="flex items-center gap-2 text-xs">
              {[1, 2, 3, 4].map((step) => (
                <div
                  key={step}
                  className={`w-6 h-6 rounded-full flex items-center justify-center font-mono font-bold text-xs ${
                    wizardStep === step
                      ? 'bg-indigo-600 text-white'
                      : wizardStep > step
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-slate-100 text-slate-500'
                  }`}
                >
                  {step}
                </div>
              ))}
            </div>
          </div>

          {/* Step 1: Client & Objective */}
          {wizardStep === 1 && (
            <div className="space-y-4 max-w-xl text-xs">
              <div>
                <label className="block text-slate-500 font-semibold mb-1 uppercase tracking-wider text-[11px]">
                  Select Agency Client
                </label>
                <select
                  value={wizardData.clientId}
                  onChange={(e) => setWizardData({ ...wizardData, clientId: e.target.value })}
                  className="w-full border border-slate-200 rounded-lg p-2.5 bg-slate-50 outline-hidden font-medium"
                >
                  {clients.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} — {c.industry}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-500 font-semibold mb-1 uppercase tracking-wider text-[11px]">
                  Campaign Name
                </label>
                <input
                  type="text"
                  value={wizardData.name}
                  onChange={(e) => setWizardData({ ...wizardData, name: e.target.value })}
                  className="w-full border border-slate-200 rounded-lg p-2.5 outline-hidden"
                />
              </div>

              <div>
                <label className="block text-slate-500 font-semibold mb-1 uppercase tracking-wider text-[11px]">
                  Primary Campaign Objective
                </label>
                <select
                  value={wizardData.objective}
                  onChange={(e) => setWizardData({ ...wizardData, objective: e.target.value as any })}
                  className="w-full border border-slate-200 rounded-lg p-2.5 bg-slate-50 outline-hidden"
                >
                  <option value="Conversions">Conversions (Direct Sales)</option>
                  <option value="Lead Generation">Lead Generation (Inbound Calls & Demos)</option>
                  <option value="ROAS Scaling">ROAS Scaling (Advantage+ Budget)</option>
                  <option value="Brand Awareness">Brand Awareness & Category Reach</option>
                  <option value="Traffic">Traffic & Content Retargeting</option>
                </select>
              </div>

              <button
                onClick={() => setWizardStep(2)}
                className="px-5 py-2.5 bg-slate-900 text-white font-semibold rounded-xl mt-3 flex items-center gap-1.5 shadow-xs"
              >
                <span>Continue to Step 2</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Step 2: Target Audience & Offer */}
          {wizardStep === 2 && (
            <div className="space-y-4 max-w-xl text-xs">
              <div>
                <label className="block text-slate-500 font-semibold mb-1 uppercase tracking-wider text-[11px]">
                  Product / Service Focus
                </label>
                <input
                  type="text"
                  value={wizardData.productService}
                  onChange={(e) => setWizardData({ ...wizardData, productService: e.target.value })}
                  className="w-full border border-slate-200 rounded-lg p-2.5 outline-hidden"
                />
              </div>

              <div>
                <label className="block text-slate-500 font-semibold mb-1 uppercase tracking-wider text-[11px]">
                  Target Audience Persona
                </label>
                <textarea
                  rows={3}
                  value={wizardData.targetAudience}
                  onChange={(e) => setWizardData({ ...wizardData, targetAudience: e.target.value })}
                  className="w-full border border-slate-200 rounded-lg p-2.5 outline-hidden resize-none"
                />
              </div>

              <div>
                <label className="block text-slate-500 font-semibold mb-1 uppercase tracking-wider text-[11px]">
                  Core Customer Offer & CTA
                </label>
                <input
                  type="text"
                  value={wizardData.offer}
                  onChange={(e) => setWizardData({ ...wizardData, offer: e.target.value })}
                  className="w-full border border-slate-200 rounded-lg p-2.5 outline-hidden"
                />
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => setWizardStep(1)}
                  className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600"
                >
                  Back
                </button>
                <button
                  onClick={() => setWizardStep(3)}
                  className="px-5 py-2.5 bg-slate-900 text-white font-semibold rounded-xl flex items-center gap-1.5 shadow-xs"
                >
                  <span>Continue to Step 3</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* Step 3: Channels & Budget Allocation */}
          {wizardStep === 3 && (
            <div className="space-y-4 max-w-xl text-xs">
              <div>
                <label className="block text-slate-500 font-semibold mb-1 uppercase tracking-wider text-[11px]">
                  Advertising Channel
                </label>
                <select
                  value={wizardData.platform}
                  onChange={(e) => setWizardData({ ...wizardData, platform: e.target.value as any })}
                  className="w-full border border-slate-200 rounded-lg p-2.5 bg-slate-50 outline-hidden font-medium"
                >
                  <option value="Meta Ads">Meta Ads (Facebook & Instagram Feed/Reels)</option>
                  <option value="Google Ads">Google Ads (High-Intent Search & Performance Max)</option>
                  <option value="TikTok Ads">TikTok Ads (Short-Form Video UGC)</option>
                  <option value="Email">Email Automation & Nurture</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-500 font-semibold mb-1 uppercase tracking-wider text-[11px]">
                    Monthly Budget ($)
                  </label>
                  <input
                    type="number"
                    value={wizardData.monthlyBudget}
                    onChange={(e) => setWizardData({ ...wizardData, monthlyBudget: Number(e.target.value) })}
                    className="w-full border border-slate-200 rounded-lg p-2.5 outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-slate-500 font-semibold mb-1 uppercase tracking-wider text-[11px]">
                    Target ROAS Threshold
                  </label>
                  <input
                    type="text"
                    value={wizardData.targetRoas}
                    onChange={(e) => setWizardData({ ...wizardData, targetRoas: e.target.value })}
                    className="w-full border border-slate-200 rounded-lg p-2.5 outline-hidden"
                  />
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => setWizardStep(2)}
                  className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600"
                >
                  Back
                </button>
                <button
                  onClick={handleGenerateBlueprint}
                  disabled={isGeneratingBlueprint}
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl flex items-center gap-1.5 shadow-xs"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>{isGeneratingBlueprint ? 'Generating Blueprint...' : 'Generate AI Campaign Blueprint'}</span>
                </button>
              </div>
            </div>
          )}

          {/* Step 4: AI Strategic Blueprint Preview & Launch Checklist */}
          {wizardStep === 4 && wizardData.generatedBlueprint && (
            <div className="space-y-6 text-xs">
              <div className="p-4 rounded-xl bg-indigo-50/40 border border-indigo-100 flex items-center justify-between">
                <div>
                  <span className="font-display font-bold text-indigo-950 text-sm">
                    Campaign Blueprint Generated for {wizardData.name}
                  </span>
                  <p className="text-slate-600 mt-0.5">
                    Target ROAS: {wizardData.targetRoas} · Budget: ${wizardData.monthlyBudget.toLocaleString()}/mo · Platform: {wizardData.platform}
                  </p>
                </div>
                <button
                  onClick={handleSaveWizardCampaign}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-xl shadow-xs"
                >
                  Deploy Campaign & Send to Approvals
                </button>
              </div>

              {/* Messaging Angles */}
              <div>
                <h4 className="font-semibold text-slate-900 text-sm mb-2">3 Strategic Messaging Angles</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {wizardData.generatedBlueprint.messagingAngles.map((angle: any, i: number) => (
                    <div key={i} className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
                      <div className="font-semibold text-indigo-700">{angle.title}</div>
                      <p className="text-slate-800 font-medium">"{angle.hook}"</p>
                      <div className="text-[11px] text-slate-500 pt-1 border-t border-slate-200">
                        CTA: {angle.cta}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Launch Checklist */}
              <div>
                <h4 className="font-semibold text-slate-900 text-sm mb-2">Launch Requirements & Governance Checklist</h4>
                <div className="space-y-2">
                  {wizardData.generatedBlueprint.launchChecklist.map((c: any, i: number) => (
                    <div key={i} className="p-3 rounded-lg bg-slate-50 border border-slate-200/80 flex items-center justify-between">
                      <span className="text-slate-800">{c.item}</span>
                      <span
                        className={`text-[10px] font-mono font-semibold px-2 py-0.5 rounded ${
                          c.completed ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {c.completed ? 'VERIFIED' : 'PENDING APPROVAL'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      ) : (
        /* Standard Campaign Manager View */
        <>
          {/* Integration Architecture Notice */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs text-slate-600">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
              <span>
                <strong>Ads Engine Mode:</strong> Meta Graph API & Google Ads SDK Architecture active. Telemetry normalized across {campaigns.length} client campaigns.
              </span>
            </div>
            <button
              onClick={() => setCurrentView('Settings')}
              className="text-indigo-600 font-medium hover:underline text-xs flex items-center gap-1"
            >
              <span>API Connectors</span>
              <ExternalLink className="w-3 h-3" />
            </button>
          </div>

          {/* Campaign Performance Roster & Filters */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2 flex-1 max-w-md">
                <div className="relative w-full">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    placeholder="Search campaigns by name or client..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="w-full text-xs pl-8 pr-3 py-1.5 border border-slate-200 rounded-lg outline-hidden focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 text-xs">
                <select
                  value={platformFilter}
                  onChange={(e) => setPlatformFilter(e.target.value)}
                  className="border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 outline-hidden"
                >
                  <option value="All">All Platforms</option>
                  <option value="Meta Ads">Meta Ads</option>
                  <option value="Google Ads">Google Ads</option>
                  <option value="TikTok Ads">TikTok Ads</option>
                </select>

                <select
                  value={healthFilter}
                  onChange={(e) => setHealthFilter(e.target.value)}
                  className="border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 outline-hidden"
                >
                  <option value="All">All Health States</option>
                  <option value="Optimal">Optimal</option>
                  <option value="Caution">Caution (Fatigue)</option>
                  <option value="Action Required">Action Required</option>
                </select>
              </div>
            </div>

            {/* Campaigns Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-100 text-[11px] text-slate-400 uppercase font-semibold">
                    <th className="pb-3 pl-2">Campaign & Client</th>
                    <th className="pb-3">Platform</th>
                    <th className="pb-3">Monthly Budget</th>
                    <th className="pb-3">CTR</th>
                    <th className="pb-3">CPC</th>
                    <th className="pb-3">CPA</th>
                    <th className="pb-3">ROAS</th>
                    <th className="pb-3">Health Status</th>
                    <th className="pb-3 pr-2 text-right">State</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredCampaigns.map((camp) => (
                    <tr
                      key={camp.id}
                      onClick={() => setSelectedCampaign(camp)}
                      className={`hover:bg-slate-50/80 cursor-pointer transition-colors ${
                        selectedCampaign?.id === camp.id ? 'bg-indigo-50/40' : ''
                      }`}
                    >
                      <td className="py-3.5 pl-2">
                        <div className="font-semibold text-slate-900">{camp.name}</div>
                        <div className="text-[10px] text-slate-500">{camp.clientName} · {camp.objective}</div>
                      </td>

                      <td className="py-3 text-slate-600 font-medium">{camp.platform}</td>

                      <td className="py-3 font-mono text-slate-900 tabular-nums">
                        ${camp.monthlyBudget.toLocaleString()}/mo
                      </td>

                      <td className="py-3 font-mono text-slate-700 tabular-nums">{camp.ctr}%</td>

                      <td className="py-3 font-mono text-slate-700 tabular-nums">${camp.cpc.toFixed(2)}</td>

                      <td className="py-3 font-mono text-slate-900 font-semibold tabular-nums">
                        ${camp.cpa.toFixed(2)}
                      </td>

                      <td className="py-3 font-mono font-bold text-emerald-600 tabular-nums">
                        {camp.roas}x
                      </td>

                      <td className="py-3">
                        <span
                          className={`text-[10px] font-semibold px-2 py-0.5 rounded ${
                            camp.health === 'Optimal'
                              ? 'bg-emerald-50 text-emerald-700'
                              : camp.health === 'Caution'
                              ? 'bg-amber-50 text-amber-700'
                              : 'bg-rose-50 text-rose-700'
                          }`}
                        >
                          {camp.health}
                        </span>
                      </td>

                      <td className="py-3 pr-2 text-right">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleCampaignStatus(camp.id);
                          }}
                          className={`p-1.5 rounded-lg text-xs font-medium transition-colors ${
                            camp.status === 'Active'
                              ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                          }`}
                          title={camp.status === 'Active' ? 'Pause Campaign' : 'Resume Campaign'}
                        >
                          {camp.status === 'Active' ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
