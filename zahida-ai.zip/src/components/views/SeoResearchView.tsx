import React, { useState } from 'react';
import {
  Search,
  Globe,
  Sparkles,
  Loader2,
  AlertCircle,
  CheckCircle2,
  ArrowUpRight,
  TrendingUp,
  FileText,
  Key,
  Layers,
  Compass,
  ExternalLink,
  ShieldAlert,
} from 'lucide-react';
import { useAgency } from '../../context/AgencyContext';

export const SeoResearchView: React.FC = () => {
  const { clients, selectedClientId, competitorReports, addCompetitorReport } = useAgency();

  const [activeTab, setActiveTab] = useState<'audit' | 'competitor' | 'keywords' | 'metadata'>('audit');
  const [urlInput, setUrlInput] = useState('https://luminaskin.co');
  const [isAuditing, setIsAuditing] = useState(false);

  // Competitor research inputs
  const [competitorName, setCompetitorName] = useState('True Botanicals');
  const [competitorUrl, setCompetitorUrl] = useState('https://truebotanicals.com');
  const [isAnalyzingCompetitor, setIsAnalyzingCompetitor] = useState(false);

  // Audit state
  const [auditResult, setAuditResult] = useState({
    url: 'https://luminaskin.co',
    score: 79,
    crawlDate: 'October 9, 2026',
    criticalProblems: [
      'Missing schema markup for Product and Customer Review aggregations.',
      'Mobile viewport CLS (Cumulative Layout Shift) at 0.22 on product detail page.',
    ],
    highPriority: [
      'Hero banner LCP image (1.4MB) unoptimized; WebP/AVIF format recommended.',
      'Meta description truncated on 8 category landing pages (> 165 characters).',
    ],
    mediumPriority: [
      'H1 tag duplicate on collection page "/collections/barrier-rituals".',
      'Internal anchor links using non-descriptive "click here" text.',
    ],
    quickWins: [
      'Add structured FAQ schema to hero serum landing page (estimated +12% CTR).',
      'Canonicalize uppercase URL variations to avoid split search ranking authority.',
    ],
  });

  const handleRunAudit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!urlInput.trim()) return;

    setIsAuditing(true);
    setTimeout(() => {
      setIsAuditing(false);
      setAuditResult({
        url: urlInput,
        score: Math.floor(Math.random() * 15) + 75,
        crawlDate: 'October 10, 2026',
        criticalProblems: [
          'High TTFB (Time to First Byte) > 820ms due to uncompressed edge assets.',
          'Missing Organization and LocalBusiness JSON-LD structured data.',
        ],
        highPriority: [
          'Product imagery missing descriptive alt tags with targeted search keywords.',
          'Mobile consultation checkout flow has 4 unnecessary form fields causing bounce.',
        ],
        mediumPriority: [
          'Thin content detected on 4 service landing sub-pages (< 300 words).',
          'Internal link graph heavily isolated on older case studies.',
        ],
        quickWins: [
          'Compress top 10 hero banners to WebP format for instant 0.6s LCP improvement.',
          'Optimize title tag formula: "[Primary Keyword] | [Client Brand Name]".',
        ],
      });
    }, 1200);
  };

  const handleRunCompetitorAnalysis = (e: React.FormEvent) => {
    e.preventDefault();
    if (!competitorName.trim()) return;

    setIsAnalyzingCompetitor(true);
    setTimeout(() => {
      setIsAnalyzingCompetitor(false);
      addCompetitorReport({
        competitorName,
        websiteUrl: competitorUrl,
        positioningSummary: `Analysis of ${competitorName}: Strong visual luxury branding with focus on clean formulation, premium DTC subscription bundles, and editorial press coverage.`,
        coreOffers: ['Core Hero Product ($85)', 'Seasonal Discovery Set ($120)', '15% Off Auto-Delivery'],
        contentGaps: [
          'Lacks dermatological active ingredient ratio transparency',
          'Limited short-form video addressing common application friction',
          'Under-utilized commercial search queries around specific barrier restoration ceramides',
        ],
        swotAnalysis: {
          strengths: ['High organic search domain authority', 'Established celebrity customer trust'],
          weaknesses: ['Premium price barrier restricts middle-tier buyers', 'Low posting velocity on TikTok'],
          opportunities: ['Target price-sensitive customers with comparison proof points and verified barrier metrics'],
          threats: ['Potential ad budget increase during upcoming holiday quarter'],
        },
        recommendedDifferentiators: [
          'Differentiate on clinical 28-day restoration speed rather than generic clean beauty jargon',
          'Provide transparent active ingredient concentrations',
        ],
        sourcesDisclosed: [
          'Public website homepage & collection pages',
          'Public Meta Ad Library listings',
          'Google Search organic result meta snippets',
        ],
      });
    }, 1200);
  };

  const trackedKeywords = [
    { keyword: 'clean barrier repair serum', volume: '14,200/mo', difficulty: 'Medium (42)', position: 4, client: 'Lumina Skin Co' },
    { keyword: 'automated corporate treasury software', volume: '3,800/mo', difficulty: 'High (68)', position: 2, client: 'Apex Fintech' },
    { keyword: 'fresh roasted specialty coffee subscription', volume: '18,500/mo', difficulty: 'Medium (51)', position: 3, client: 'Nordic Roastery' },
    { keyword: 'refrigerated freight transport midwest', volume: '2,900/mo', difficulty: 'Low (28)', position: 1, client: 'Velox Logistics' },
    { keyword: 'bespoke engagement ring london', volume: '6,400/mo', difficulty: 'High (72)', position: 5, client: 'Aurelia Jewels' },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* 1. Top Header */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="font-display font-bold text-slate-950 text-lg tracking-tight">
              SEO Engine & Market Research
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 font-semibold">
              SWOT + AUDIT + SERP
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Technical website crawl, competitor SWOT analysis, content gap identification, and keyword intelligence
          </p>
        </div>

        <div className="flex items-center p-1 bg-slate-100 rounded-lg text-xs self-start sm:self-auto overflow-x-auto">
          <button
            onClick={() => setActiveTab('audit')}
            className={`px-3 py-1 font-medium rounded-md transition-colors whitespace-nowrap ${
              activeTab === 'audit' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600'
            }`}
          >
            Website Audit
          </button>
          <button
            onClick={() => setActiveTab('competitor')}
            className={`px-3 py-1 font-medium rounded-md transition-colors whitespace-nowrap flex items-center gap-1 ${
              activeTab === 'competitor' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600'
            }`}
          >
            <Compass className="w-3 h-3 text-indigo-600" />
            <span>Competitor Intel</span>
          </button>
          <button
            onClick={() => setActiveTab('keywords')}
            className={`px-3 py-1 font-medium rounded-md transition-colors whitespace-nowrap ${
              activeTab === 'keywords' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600'
            }`}
          >
            Rank Tracker
          </button>
          <button
            onClick={() => setActiveTab('metadata')}
            className={`px-3 py-1 font-medium rounded-md transition-colors whitespace-nowrap ${
              activeTab === 'metadata' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600'
            }`}
          >
            Meta Generator
          </button>
        </div>
      </div>

      {/* 2. Competitor Intel Tab (Improvement 4) */}
      {activeTab === 'competitor' && (
        <div className="space-y-6">
          {/* Research Input Form */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs space-y-3">
            <h3 className="font-display font-bold text-slate-900 text-sm">
              Competitor Analysis & SWOT Engine
            </h3>
            <p className="text-xs text-slate-500">
              Input competitor name and public website URL to evaluate positioning, pricing models, content gaps, and opportunities.
            </p>

            <form onSubmit={handleRunCompetitorAnalysis} className="grid grid-cols-1 sm:grid-cols-12 gap-2 pt-1 text-xs">
              <div className="sm:col-span-5">
                <input
                  type="text"
                  required
                  placeholder="Competitor Name (e.g. True Botanicals)"
                  value={competitorName}
                  onChange={(e) => setCompetitorName(e.target.value)}
                  className="w-full border border-slate-200 rounded-xl p-2.5 outline-hidden focus:border-indigo-500 bg-slate-50/50"
                />
              </div>

              <div className="sm:col-span-5">
                <input
                  type="url"
                  placeholder="https://competitor.com"
                  value={competitorUrl}
                  onChange={(e) => setCompetitorUrl(e.target.value)}
                  className="w-full border border-slate-200 rounded-xl p-2.5 outline-hidden focus:border-indigo-500 bg-slate-50/50"
                />
              </div>

              <div className="sm:col-span-2">
                <button
                  type="submit"
                  disabled={isAnalyzingCompetitor}
                  className="w-full h-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-semibold flex items-center justify-center gap-1.5 shadow-xs transition-colors"
                >
                  {isAnalyzingCompetitor ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <>
                      <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Analyze</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>

          {/* Competitor Reports List */}
          <div className="space-y-4">
            {competitorReports.map((report) => (
              <div
                key={report.id}
                className="bg-white border border-slate-200/90 rounded-2xl p-6 shadow-xs space-y-5"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-display font-bold text-slate-950 text-base">
                        {report.competitorName}
                      </h3>
                      <span className="text-xs text-slate-400">·</span>
                      <a
                        href={report.websiteUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs text-indigo-600 hover:underline flex items-center gap-0.5"
                      >
                        <span>{report.websiteUrl}</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                    <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                      {report.positioningSummary}
                    </p>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400 shrink-0">
                    Analyzed: {report.analysisDate}
                  </span>
                </div>

                {/* SWOT Matrix Grid */}
                <div>
                  <h4 className="font-semibold text-slate-900 text-xs mb-2 uppercase tracking-wider text-[11px]">
                    Structured SWOT Analysis
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                    <div className="p-3.5 rounded-xl bg-emerald-50/40 border border-emerald-100 space-y-1">
                      <div className="font-semibold text-emerald-900">Strengths (S)</div>
                      <ul className="space-y-1 text-slate-700">
                        {report.swotAnalysis.strengths.map((s, i) => (
                          <li key={i} className="flex items-start gap-1">
                            <span className="text-emerald-600 font-bold">·</span>
                            <span>{s}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="p-3.5 rounded-xl bg-amber-50/40 border border-amber-100 space-y-1">
                      <div className="font-semibold text-amber-900">Weaknesses (W)</div>
                      <ul className="space-y-1 text-slate-700">
                        {report.swotAnalysis.weaknesses.map((w, i) => (
                          <li key={i} className="flex items-start gap-1">
                            <span className="text-amber-600 font-bold">·</span>
                            <span>{w}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="p-3.5 rounded-xl bg-indigo-50/40 border border-indigo-100 space-y-1">
                      <div className="font-semibold text-indigo-900">Opportunities (O)</div>
                      <ul className="space-y-1 text-slate-700">
                        {report.swotAnalysis.opportunities.map((o, i) => (
                          <li key={i} className="flex items-start gap-1">
                            <span className="text-indigo-600 font-bold">·</span>
                            <span>{o}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="p-3.5 rounded-xl bg-rose-50/40 border border-rose-100 space-y-1">
                      <div className="font-semibold text-rose-900">Threats (T)</div>
                      <ul className="space-y-1 text-slate-700">
                        {report.swotAnalysis.threats.map((t, i) => (
                          <li key={i} className="flex items-start gap-1">
                            <span className="text-rose-600 font-bold">·</span>
                            <span>{t}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Content Gaps & Differentiators */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1.5">
                    <span className="font-semibold text-slate-900 block">Identified Content Gaps</span>
                    <ul className="space-y-1 text-slate-700">
                      {report.contentGaps.map((gap, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <span className="text-indigo-600 font-bold">→</span>
                          <span>{gap}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="p-3.5 rounded-xl bg-indigo-50/30 border border-indigo-100 space-y-1.5">
                    <span className="font-semibold text-indigo-950 block">Recommended Agency Differentiators</span>
                    <ul className="space-y-1 text-slate-700">
                      {report.recommendedDifferentiators.map((diff, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <span className="text-emerald-600 font-bold">✓</span>
                          <span>{diff}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Honest Source Disclosure */}
                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Sources: {report.sourcesDisclosed.join(' · ')}</span>
                  </div>
                  <span>Grounded in public domain crawl data</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. Website Audit Tab */}
      {activeTab === 'audit' && (
        <div className="space-y-6">
          <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs">
            <h3 className="font-display font-bold text-slate-900 text-sm mb-2">
              Run AI Website SEO & UX Audit
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Enter any client or competitor domain to evaluate on-page SEO, metadata, mobile speed, and conversion friction.
            </p>

            <form onSubmit={handleRunAudit} className="flex flex-col sm:flex-row gap-2">
              <div className="relative flex-1">
                <Globe className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="url"
                  required
                  placeholder="https://example.com"
                  value={urlInput}
                  onChange={(e) => setUrlInput(e.target.value)}
                  className="w-full text-xs pl-9 pr-3 py-2.5 border border-slate-200 rounded-xl outline-hidden focus:border-indigo-500 bg-slate-50/50"
                />
              </div>

              <button
                type="submit"
                disabled={isAuditing}
                className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-2 shadow-xs transition-colors shrink-0"
              >
                {isAuditing ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Crawling Site...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Analyze Domain</span>
                  </>
                )}
              </button>
            </form>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-4 bg-white border border-slate-200/90 rounded-2xl p-6 shadow-xs flex flex-col justify-between">
              <div>
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                  Overall SEO & UX Health
                </span>
                <div className="flex items-baseline gap-2 mt-2">
                  <span className="text-5xl font-bold font-display tracking-tight text-slate-900 tabular-nums">
                    {auditResult.score}
                  </span>
                  <span className="text-sm font-semibold text-slate-400">/ 100</span>
                </div>
                <div className="text-xs text-slate-600 mt-2">
                  Domain: <span className="font-mono text-slate-900">{auditResult.url}</span>
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  Crawled: {auditResult.crawlDate}
                </div>
              </div>

              <div className="pt-6 border-t border-slate-100 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Core Web Vitals</span>
                  <span className="font-semibold text-emerald-600">PASSED</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Mobile Responsive UX</span>
                  <span className="font-semibold text-emerald-600">OPTIMAL</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Structured Schema</span>
                  <span className="font-semibold text-amber-600">ACTION REQUIRED</span>
                </div>
              </div>
            </div>

            <div className="lg:col-span-8 bg-white border border-slate-200/90 rounded-2xl p-6 shadow-xs space-y-4">
              <h4 className="font-display font-bold text-slate-900 text-sm pb-2 border-b border-slate-100">
                Categorized Audit Findings & Action Plan
              </h4>

              <div className="p-3.5 rounded-xl bg-rose-50/50 border border-rose-100 space-y-1.5 text-xs">
                <div className="font-semibold text-rose-900 flex items-center gap-1.5">
                  <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
                  <span>Critical Bottlenecks (2)</span>
                </div>
                <ul className="space-y-1 text-slate-700">
                  {auditResult.criticalProblems.map((p, i) => (
                    <li key={i} className="flex items-start gap-1.5">
                      <span className="text-rose-500 font-bold">·</span>
                      <span>{p}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="p-3.5 rounded-xl bg-amber-50/50 border border-amber-100 space-y-1.5 text-xs">
                <div className="font-semibold text-amber-900 flex items-center gap-1.5">
                  <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
                  <span>High Priority Improvements (2)</span>
                </div>
                <ul className="space-y-1 text-slate-700">
                  {auditResult.highPriority.map((p, i) => (
                    <li key={i} className="flex items-start gap-1.5">
                      <span className="text-amber-500 font-bold">·</span>
                      <span>{p}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="p-3.5 rounded-xl bg-emerald-50/50 border border-emerald-100 space-y-1.5 text-xs">
                <div className="font-semibold text-emerald-900 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Quick Wins (High Impact / Low Effort)</span>
                </div>
                <ul className="space-y-1 text-slate-700">
                  {auditResult.quickWins.map((p, i) => (
                    <li key={i} className="flex items-start gap-1.5">
                      <span className="text-emerald-500 font-bold">·</span>
                      <span>{p}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4. Keyword Tracker Tab */}
      {activeTab === 'keywords' && (
        <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs space-y-4">
          <h3 className="font-display font-bold text-slate-900 text-sm">
            Agency High-Intent Keyword Trackers
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-100 text-[11px] text-slate-400 uppercase font-semibold">
                  <th className="pb-3 pl-2">Tracked Search Keyword</th>
                  <th className="pb-3">Client</th>
                  <th className="pb-3">Monthly Volume</th>
                  <th className="pb-3">KD Score</th>
                  <th className="pb-3 pr-2 text-right">SERP Position</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {trackedKeywords.map((k, i) => (
                  <tr key={i} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 pl-2 font-semibold text-slate-900">{k.keyword}</td>
                    <td className="py-3 text-slate-600">{k.client}</td>
                    <td className="py-3 font-mono text-slate-700">{k.volume}</td>
                    <td className="py-3 text-slate-600">{k.difficulty}</td>
                    <td className="py-3 pr-2 text-right font-mono font-bold text-emerald-600">
                      #{k.position}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 5. Meta Generator Tab */}
      {activeTab === 'metadata' && (
        <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs space-y-4 text-xs">
          <h3 className="font-display font-bold text-slate-900 text-sm">
            AI Meta Title & Description Generator
          </h3>
          <p className="text-slate-500">
            Generate high-CTR title tags and meta descriptions adhering to 60/160 character search engine limits.
          </p>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
            <div>
              <span className="text-[10px] font-semibold text-slate-400 uppercase">Generated Meta Title (58 chars)</span>
              <div className="font-semibold text-indigo-700 text-sm mt-0.5">
                Barrier Repair Serum | Dermatologist-Formulated Skincare | Lumina
              </div>
            </div>
            <div>
              <span className="text-[10px] font-semibold text-slate-400 uppercase">Generated Meta Description (148 chars)</span>
              <div className="text-slate-700 mt-0.5 leading-relaxed">
                Rebuild your skin lipid barrier in 14 days with clinically proven bio-fermented active botanicals. Clean, dermatologist-backed, zero fragrance.
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
