import React, { useState } from 'react';
import {
  CalendarDays,
  Plus,
  ChevronLeft,
  ChevronRight,
  Filter,
  Search,
  CheckCircle2,
  Clock,
  Sparkles,
  Eye,
} from 'lucide-react';
import { useAgency } from '../../context/AgencyContext';
import { ContentItem } from '../../types';

export const ContentCalendarView: React.FC = () => {
  const {
    contentItems,
    clients,
    selectedClientId,
    setSelectedClientId,
    setQuickModalType,
    updateContentStatus,
  } = useAgency();

  const [viewMode, setViewMode] = useState<'Month' | 'Week' | 'List'>('Month');
  const [platformFilter, setPlatformFilter] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [selectedItem, setSelectedItem] = useState<ContentItem | null>(contentItems[0] || null);

  const filteredItems = contentItems.filter((item) => {
    const matchesClient = !selectedClientId || item.clientId === selectedClientId;
    const matchesPlatform = platformFilter === 'All' || item.platform === platformFilter;
    const matchesStatus = statusFilter === 'All' || item.status === statusFilter;
    return matchesClient && matchesPlatform && matchesStatus;
  });

  // Calendar days generation for October 2026
  const calendarDays = Array.from({ length: 31 }, (_, i) => i + 1);

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* 1. Header & View Switcher */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="font-display font-bold text-slate-950 text-lg tracking-tight">
              Content Calendar & Publishing Grid
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 font-semibold">
              OCTOBER 2026
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Organize multi-client social posts, scheduled broadcasts, and creative approvals
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* View Mode Toggle */}
          <div className="flex items-center p-1 bg-slate-100 rounded-lg text-xs">
            <button
              onClick={() => setViewMode('Month')}
              className={`px-3 py-1 font-medium rounded-md transition-colors ${
                viewMode === 'Month' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              Month
            </button>
            <button
              onClick={() => setViewMode('Week')}
              className={`px-3 py-1 font-medium rounded-md transition-colors ${
                viewMode === 'Week' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              Week
            </button>
            <button
              onClick={() => setViewMode('List')}
              className={`px-3 py-1 font-medium rounded-md transition-colors ${
                viewMode === 'List' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              List
            </button>
          </div>

          <button
            onClick={() => setQuickModalType('content')}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold transition-colors shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Schedule Post</span>
          </button>
        </div>
      </div>

      {/* 2. Calendar Filters Strip */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-3.5 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-2">
          <select
            value={selectedClientId || ''}
            onChange={(e) => setSelectedClientId(e.target.value ? e.target.value : null)}
            className="border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 outline-hidden font-medium"
          >
            <option value="">All Agency Clients</option>
            {clients.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>

          <select
            value={platformFilter}
            onChange={(e) => setPlatformFilter(e.target.value)}
            className="border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 outline-hidden"
          >
            <option value="All">All Platforms</option>
            <option value="Instagram">Instagram</option>
            <option value="LinkedIn">LinkedIn</option>
            <option value="TikTok">TikTok</option>
            <option value="Facebook">Facebook</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 outline-hidden"
          >
            <option value="All">All Statuses</option>
            <option value="Idea">Idea</option>
            <option value="Draft">Draft</option>
            <option value="Review">Review</option>
            <option value="Approved">Approved</option>
            <option value="Scheduled">Scheduled</option>
            <option value="Published">Published</option>
          </select>
        </div>

        <div className="flex items-center gap-3 text-xs text-slate-500 font-medium">
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Scheduled: 2</span>
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-amber-500" />
            <span>In Review: 1</span>
          </span>
        </div>
      </div>

      {/* 3. Monthly Calendar Grid */}
      {viewMode === 'Month' ? (
        <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs">
          <div className="grid grid-cols-7 gap-px bg-slate-200 rounded-xl overflow-hidden text-xs">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
              <div key={day} className="bg-slate-50 p-2.5 text-center font-semibold text-slate-500">
                {day}
              </div>
            ))}

            {/* October 2026 starts on Thursday (pad 4 days) */}
            {[27, 28, 29, 30].map((d) => (
              <div key={`prev-${d}`} className="bg-slate-50/40 p-2 min-h-[90px] text-slate-300">
                <span className="font-mono text-[10px]">{d}</span>
              </div>
            ))}

            {calendarDays.map((day) => {
              const dateStr = `2026-10-${day < 10 ? '0' + day : day}`;
              const dayItems = filteredItems.filter((i) => i.scheduledDate === dateStr);
              const isToday = day === 9;

              return (
                <div
                  key={day}
                  className={`bg-white p-2 min-h-[100px] flex flex-col justify-between transition-colors hover:bg-slate-50/50 ${
                    isToday ? 'ring-1 ring-inset ring-indigo-500 bg-indigo-50/20' : ''
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span
                      className={`font-mono text-[11px] font-semibold ${
                        isToday ? 'text-indigo-600' : 'text-slate-700'
                      }`}
                    >
                      {day}
                    </span>
                    {dayItems.length > 0 && (
                      <span className="w-1.5 h-1.5 rounded-full bg-indigo-600" />
                    )}
                  </div>

                  <div className="space-y-1 mt-1">
                    {dayItems.map((item) => (
                      <div
                        key={item.id}
                        onClick={() => setSelectedItem(item)}
                        className="p-1 rounded text-[10px] bg-indigo-50 hover:bg-indigo-100 text-indigo-900 border border-indigo-200/60 cursor-pointer truncate font-medium transition-colors"
                        title={item.title}
                      >
                        <span className="font-bold">{item.platform}:</span> {item.title}
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        /* List View */
        <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs space-y-3">
          <div className="divide-y divide-slate-100">
            {filteredItems.map((item) => (
              <div
                key={item.id}
                onClick={() => setSelectedItem(item)}
                className="py-3 px-2 flex items-center justify-between hover:bg-slate-50 rounded-lg cursor-pointer transition-colors"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-slate-900 text-xs">{item.title}</span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-100 text-slate-700">
                      {item.platform} {item.contentType}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    Client: {item.clientName} · Scheduled: {item.scheduledDate} at {item.scheduledTime}
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span
                    className={`text-[10px] font-semibold px-2 py-0.5 rounded ${
                      item.status === 'Scheduled' || item.status === 'Approved'
                        ? 'bg-emerald-50 text-emerald-700'
                        : 'bg-amber-50 text-amber-700'
                    }`}
                  >
                    {item.status}
                  </span>
                  <span className="text-xs text-slate-400">Assignee: {item.assignedTo}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. Selected Content Brief Inspector */}
      {selectedItem && (
        <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-display font-bold text-slate-900 text-sm">
                  {selectedItem.title}
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 font-semibold">
                  {selectedItem.platform} · {selectedItem.contentType}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Client: {selectedItem.clientName} · Scheduled {selectedItem.scheduledDate} at {selectedItem.scheduledTime}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs font-medium text-slate-600">Approval State:</span>
              <span className="text-xs font-semibold text-indigo-600">
                {selectedItem.approvalStatus}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1">
              <div className="font-semibold text-slate-900">Hook & Primary Caption</div>
              <p className="text-slate-800 whitespace-pre-wrap leading-relaxed">{selectedItem.caption}</p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2">
              <div>
                <span className="font-semibold text-slate-900 block">Creative Brief Specs</span>
                <p className="text-slate-600 mt-0.5">{selectedItem.creativeBrief}</p>
              </div>
              <div>
                <span className="font-semibold text-slate-900 block">CTA</span>
                <p className="text-indigo-600 mt-0.5 font-medium">{selectedItem.cta}</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
