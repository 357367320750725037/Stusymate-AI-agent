import React, { useState } from 'react';
import {
  BarChart3,
  TrendingUp,
  DollarSign,
  Users,
  Target,
  Sparkles,
  PieChart,
  ArrowUpRight,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';
import { useAgency } from '../../context/AgencyContext';

export const AnalyticsView: React.FC = () => {
  const { clients, campaigns, leads } = useAgency();

  const totalMRR = clients.reduce((acc, c) => acc + c.monthlyRetainer, 0);
  const avgClientValue = (totalMRR / (clients.length || 1)).toFixed(0);

  const servicesBreakdown = [
    { service: 'Full Omnichannel Retainer (Paid Ads + SEO)', revenue: 38500, share: 45, margin: '74%' },
    { service: 'Paid Performance Media Buying (Meta + Google)', revenue: 26500, share: 31, margin: '82%' },
    { service: 'Content Studio & Video Scripting', revenue: 12200, share: 14, margin: '68%' },
    { service: 'Technical SEO & Website UX Optimization', revenue: 7500, share: 10, margin: '86%' },
  ];

  const channelAttribution = [
    { channel: 'Meta Ads', share: 48, roas: '3.6x', spend: '$58,000' },
    { channel: 'Google Search Ads', share: 34, roas: '4.8x', spend: '$48,000' },
    { channel: 'TikTok Ads', share: 10, roas: '3.2x', spend: '$14,000' },
    { channel: 'Organic SEO & Email', share: 8, roas: '9.4x', spend: '$6,000' },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* 1. Header */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="font-display font-bold text-slate-950 text-lg tracking-tight">
              Business Intelligence & Agency Analytics
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 font-semibold">
              EXECUTIVE TELEMETRY
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Unit economics, retainer margins, client retention rate, and service line profitability
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-500">Period:</span>
          <span className="font-semibold text-slate-800 bg-slate-100 px-2.5 py-1 rounded-lg">
            Q3–Q4 2026 Consolidated
          </span>
        </div>
      </div>

      {/* 2. Top Metric Quad */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs">
          <span className="text-xs font-medium text-slate-500">Monthly Recurring Revenue</span>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-2xl font-bold font-display text-slate-900 tabular-nums">
              ${totalMRR.toLocaleString()}
            </span>
            <span className="text-xs font-semibold text-emerald-600">+14.2%</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-2">Guaranteed monthly retainers</div>
        </div>

        <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs">
          <span className="text-xs font-medium text-slate-500">Client Retention Rate</span>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-2xl font-bold font-display text-slate-900 tabular-nums">
              94.2%
            </span>
            <span className="text-xs font-semibold text-emerald-600">Top Quartile</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-2">Average client tenure: 11.4 mos</div>
        </div>

        <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs">
          <span className="text-xs font-medium text-slate-500">Average Client Value (ACV)</span>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-2xl font-bold font-display text-slate-900 tabular-nums">
              ${avgClientValue}
            </span>
            <span className="text-xs font-semibold text-indigo-600">/ mo</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-2">Up from $4,800 baseline</div>
        </div>

        <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs">
          <span className="text-xs font-medium text-slate-500">Lead Conversion Rate</span>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-2xl font-bold font-display text-slate-900 tabular-nums">
              64.8%
            </span>
            <span className="text-xs font-semibold text-emerald-600">+18% YoY</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-2">Discovery call to signed proposal</div>
        </div>
      </div>

      {/* 3. Service Profitability & Channel Allocation Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Service Profitability Table */}
        <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <h3 className="font-display font-bold text-slate-900 text-sm">
              Service Line Profitability Matrix
            </h3>
            <span className="text-[10px] font-mono text-slate-400">NET MARGINS</span>
          </div>

          <div className="space-y-3">
            {servicesBreakdown.map((s, idx) => (
              <div key={idx} className="p-3 rounded-xl bg-slate-50/70 border border-slate-100 text-xs">
                <div className="flex items-center justify-between mb-1.5 font-semibold text-slate-900">
                  <span>{s.service}</span>
                  <span className="font-mono">${s.revenue.toLocaleString()}/mo</span>
                </div>
                <div className="flex items-center justify-between text-[11px] text-slate-500">
                  <span>Share of Agency MRR: {s.share}%</span>
                  <span className="text-emerald-700 font-semibold font-mono">Gross Margin: {s.margin}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Paid Channel Allocation */}
        <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <h3 className="font-display font-bold text-slate-900 text-sm">
              Paid Channel Attribution & Efficiency
            </h3>
            <span className="text-[10px] font-mono text-slate-400">BLENDED ROAS</span>
          </div>

          <div className="space-y-3">
            {channelAttribution.map((c, idx) => (
              <div key={idx} className="p-3 rounded-xl bg-slate-50/70 border border-slate-100 text-xs">
                <div className="flex items-center justify-between mb-1.5 font-semibold text-slate-900">
                  <span>{c.channel}</span>
                  <span className="font-mono text-emerald-600 font-bold">{c.roas} ROAS</span>
                </div>
                <div className="flex items-center justify-between text-[11px] text-slate-500">
                  <span>Spend: {c.spend}</span>
                  <span>Portfolio Volume: {c.share}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
