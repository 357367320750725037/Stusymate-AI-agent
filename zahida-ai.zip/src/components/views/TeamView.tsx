import React from 'react';
import {
  UserCheck,
  Plus,
  Mail,
  Shield,
  Briefcase,
  CheckCircle2,
  Calendar,
} from 'lucide-react';
import { useAgency } from '../../context/AgencyContext';

export const TeamView: React.FC = () => {
  const { teamMembers } = useAgency();

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* 1. Header */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="font-display font-bold text-slate-950 text-lg tracking-tight">
              Agency Team & Workload Allocation
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 font-semibold">
              ROLES & PERMISSIONS
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage agency personnel, role-based access control, active account capacity, and deliverable velocity
          </p>
        </div>

        <button
          onClick={() => alert('Phase 1 Notice: Team invitation module ready. Connect user invite flow in settings.')}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold transition-colors shadow-xs self-start sm:self-auto"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Invite Team Member</span>
        </button>
      </div>

      {/* 2. Team Roster Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {teamMembers.map((member) => (
          <div
            key={member.id}
            className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs flex flex-col justify-between space-y-4"
          >
            <div>
              <div className="flex items-start justify-between gap-3 mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full overflow-hidden bg-slate-100 ring-1 ring-slate-200 shrink-0">
                    {member.avatarUrl ? (
                      <img
                        src={member.avatarUrl}
                        alt={member.name}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                        onError={(e) => {
                          (e.target as HTMLElement).style.display = 'none';
                        }}
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center font-bold text-xs text-indigo-700 bg-indigo-50">
                        {member.name.slice(0, 2).toUpperCase()}
                      </div>
                    )}
                  </div>

                  <div>
                    <div className="font-display font-bold text-slate-900 text-sm">
                      {member.name}
                    </div>
                    <div className="text-[11px] text-slate-500">{member.email}</div>
                  </div>
                </div>

                <span
                  className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                    member.role === 'Owner'
                      ? 'bg-slate-900 text-white'
                      : 'bg-indigo-50 text-indigo-700'
                  }`}
                >
                  {member.role}
                </span>
              </div>

              {/* Workload Capacity Bar */}
              <div className="space-y-1 text-xs">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-slate-500">Active Workload</span>
                  <span className="font-mono font-semibold text-slate-800">
                    {member.workloadPercentage}% Capacity
                  </span>
                </div>
                <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                  <div
                    style={{ width: `${member.workloadPercentage}%` }}
                    className={`h-full rounded-full ${
                      member.workloadPercentage > 90
                        ? 'bg-rose-500'
                        : member.workloadPercentage > 75
                        ? 'bg-amber-500'
                        : 'bg-emerald-500'
                    }`}
                  />
                </div>
              </div>

              {/* Accounts Assigned */}
              <div className="mt-4 pt-3 border-t border-slate-100 text-xs">
                <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                  Active Client Accounts ({member.activeAccounts.length})
                </span>
                <div className="flex flex-wrap gap-1">
                  {member.activeAccounts.map((acc, i) => (
                    <span
                      key={i}
                      className="text-[11px] bg-slate-50 border border-slate-200 text-slate-700 px-2 py-0.5 rounded"
                    >
                      {acc}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
              <span>{member.tasksAssigned} tasks assigned</span>
              <span className="font-mono text-emerald-600 font-semibold">Active</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
