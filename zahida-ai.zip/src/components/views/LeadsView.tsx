import React, { useState } from 'react';
import {
  Target,
  Plus,
  Search,
  Filter,
  Sparkles,
  ArrowRight,
  Phone,
  Mail,
  DollarSign,
  TrendingUp,
  Flame,
  CheckCircle,
  Clock,
} from 'lucide-react';
import { useAgency } from '../../context/AgencyContext';
import { Lead } from '../../types';

export const LeadsView: React.FC = () => {
  const { leads, updateLeadStatus, setQuickModalType, sendAiMessage, setIsAskZaiOpen } = useAgency();

  const [search, setSearch] = useState('');
  const [selectedLead, setSelectedLead] = useState<Lead | null>(leads[0] || null);
  const [viewMode, setViewMode] = useState<'Kanban' | 'List'>('Kanban');

  const stages: Array<Lead['status']> = [
    'New',
    'Contacted',
    'Qualified',
    'Proposal',
    'Negotiation',
    'Won',
  ];

  const filteredLeads = leads.filter(
    (l) =>
      l.name.toLowerCase().includes(search.toLowerCase()) ||
      l.company.toLowerCase().includes(search.toLowerCase()) ||
      l.serviceInterest.toLowerCase().includes(search.toLowerCase())
  );

  const totalPipelineValue = leads.reduce((acc, l) => acc + (l.status !== 'Lost' ? l.budgetEst : 0), 0);
  const hotLeads = leads.filter((l) => l.scoreTier === 'HOT');

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* 1. Header Bar */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="font-display font-bold text-slate-950 text-lg tracking-tight">
              Lead CRM & AI Opportunity Scoring
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 font-semibold">
              ${totalPipelineValue.toLocaleString()}/mo PIPELINE
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            AI-scored prospective clients, intake qualification breakdown, and deal pipeline
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Kanban / List Toggle */}
          <div className="flex items-center p-1 bg-slate-100 rounded-lg text-xs">
            <button
              onClick={() => setViewMode('Kanban')}
              className={`px-3 py-1 font-medium rounded-md transition-colors ${
                viewMode === 'Kanban' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              Pipeline Board
            </button>
            <button
              onClick={() => setViewMode('List')}
              className={`px-3 py-1 font-medium rounded-md transition-colors ${
                viewMode === 'List' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              Table View
            </button>
          </div>

          <button
            onClick={() => setQuickModalType('lead')}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold transition-colors shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Lead</span>
          </button>
        </div>
      </div>

      {/* 2. Top Lead Intel Strip */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white border border-slate-200/90 rounded-2xl p-4 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-400 uppercase font-semibold">Hot Qualified Deals</span>
            <div className="font-display font-bold text-xl text-slate-900 mt-0.5">
              {hotLeads.length} High Intent
            </div>
            <div className="text-[11px] text-emerald-600 mt-1">Ready for proposal presentation</div>
          </div>
          <div className="p-2.5 rounded-xl bg-amber-50 text-amber-600">
            <Flame className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white border border-slate-200/90 rounded-2xl p-4 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-400 uppercase font-semibold">Active Retainer Potential</span>
            <div className="font-display font-bold text-xl text-slate-900 mt-0.5">
              ${totalPipelineValue.toLocaleString()}/mo
            </div>
            <div className="text-[11px] text-slate-500 mt-1">Weighted conversion est. 64%</div>
          </div>
          <div className="p-2.5 rounded-xl bg-indigo-50 text-indigo-600">
            <DollarSign className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white border border-slate-200/90 rounded-2xl p-4 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-400 uppercase font-semibold">Average Inbound Score</span>
            <div className="font-display font-bold text-xl text-slate-900 mt-0.5">
              74.2 / 100
            </div>
            <div className="text-[11px] text-slate-500 mt-1">Evaluated by ZAI Lead Agent</div>
          </div>
          <div className="p-2.5 rounded-xl bg-emerald-50 text-emerald-600">
            <TrendingUp className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* 3. Pipeline Kanban Board or Table */}
      {viewMode === 'Kanban' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-3 min-h-[520px]">
          {stages.map((stage) => {
            const stageLeads = filteredLeads.filter((l) => l.status === stage);
            const stageTotal = stageLeads.reduce((acc, l) => acc + l.budgetEst, 0);

            return (
              <div
                key={stage}
                className="bg-slate-50/80 rounded-2xl p-3 border border-slate-200/80 flex flex-col"
              >
                {/* Column Header */}
                <div className="flex items-center justify-between pb-2.5 mb-2 border-b border-slate-200 text-xs">
                  <div>
                    <span className="font-semibold text-slate-900">{stage}</span>
                    <span className="text-[10px] text-slate-400 ml-1.5 font-mono">({stageLeads.length})</span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-500">${stageTotal.toLocaleString()}</span>
                </div>

                {/* Lead Cards */}
                <div className="space-y-2.5 flex-1 overflow-y-auto">
                  {stageLeads.map((lead) => (
                    <div
                      key={lead.id}
                      onClick={() => setSelectedLead(lead)}
                      className={`p-3 rounded-xl bg-white border cursor-pointer transition-all ${
                        selectedLead?.id === lead.id
                          ? 'border-indigo-500 shadow-xs ring-1 ring-indigo-500/20'
                          : 'border-slate-200/90 hover:border-slate-300 shadow-2xs'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <span
                          className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                            lead.scoreTier === 'HOT'
                              ? 'bg-rose-50 text-rose-700'
                              : lead.scoreTier === 'WARM'
                              ? 'bg-amber-50 text-amber-700'
                              : 'bg-slate-100 text-slate-600'
                          }`}
                        >
                          {lead.scoreTier} · {lead.score}/100
                        </span>
                        <span className="font-mono text-[10px] text-slate-600">
                          ${lead.budgetEst}/mo
                        </span>
                      </div>

                      <div className="font-semibold text-slate-900 text-xs truncate">{lead.company}</div>
                      <div className="text-[10px] text-slate-500 truncate mb-2">{lead.name}</div>

                      <div className="text-[10px] text-slate-400 truncate border-t border-slate-100 pt-1.5">
                        {lead.serviceInterest}
                      </div>

                      {/* Quick stage mover */}
                      <div className="mt-2 pt-1.5 border-t border-slate-100 flex items-center justify-between">
                        <select
                          value={lead.status}
                          onClick={(e) => e.stopPropagation()}
                          onChange={(e) => updateLeadStatus(lead.id, e.target.value as any)}
                          className="text-[10px] bg-slate-50 border border-slate-200 rounded px-1.5 py-0.5 text-slate-700 outline-hidden"
                        >
                          {stages.map((s) => (
                            <option key={s} value={s}>
                              Move: {s}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Table View */
        <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-100 text-[11px] text-slate-400 uppercase font-semibold">
                <th className="pb-3 pl-2">Company & Contact</th>
                <th className="pb-3">Source</th>
                <th className="pb-3">Est. Retainer</th>
                <th className="pb-3">AI Score</th>
                <th className="pb-3">Service Interest</th>
                <th className="pb-3">Stage</th>
                <th className="pb-3">Next Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredLeads.map((lead) => (
                <tr
                  key={lead.id}
                  onClick={() => setSelectedLead(lead)}
                  className="hover:bg-slate-50/80 cursor-pointer transition-colors"
                >
                  <td className="py-3 pl-2">
                    <div className="font-semibold text-slate-900">{lead.company}</div>
                    <div className="text-[10px] text-slate-500">{lead.name} · {lead.email}</div>
                  </td>
                  <td className="py-3 text-slate-600">{lead.source}</td>
                  <td className="py-3 font-mono font-bold text-slate-900 tabular-nums">
                    ${lead.budgetEst}/mo
                  </td>
                  <td className="py-3">
                    <span
                      className={`font-mono text-[10px] font-bold px-2 py-0.5 rounded ${
                        lead.scoreTier === 'HOT'
                          ? 'bg-rose-50 text-rose-700'
                          : lead.scoreTier === 'WARM'
                          ? 'bg-amber-50 text-amber-700'
                          : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      {lead.scoreTier} ({lead.score}/100)
                    </span>
                  </td>
                  <td className="py-3 text-slate-600">{lead.serviceInterest}</td>
                  <td className="py-3 font-medium text-slate-900">{lead.status}</td>
                  <td className="py-3 text-slate-600 max-w-xs truncate">{lead.nextAction}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* 4. Selected Lead Deep-Dive Drawer */}
      {selectedLead && (
        <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 mb-4">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-display font-bold text-slate-900 text-base">
                  {selectedLead.company} — {selectedLead.name}
                </h3>
                <span className="text-xs text-slate-400">·</span>
                <span className="font-mono text-xs text-emerald-600 font-semibold">
                  Est. ${selectedLead.budgetEst}/mo Retainer
                </span>
              </div>
              <div className="flex items-center gap-3 text-xs text-slate-500 mt-1">
                <span>{selectedLead.email}</span>
                <span>·</span>
                <span>{selectedLead.phone}</span>
                <span>·</span>
                <span>Source: {selectedLead.source}</span>
              </div>
            </div>

            <button
              onClick={() => {
                sendAiMessage(`Generate custom client proposal for ${selectedLead.company} (${selectedLead.name}). Service interest: ${selectedLead.serviceInterest}, Budget: $${selectedLead.budgetEst}/mo.`);
                setIsAskZaiOpen(true);
              }}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-700 transition-colors shadow-xs self-start sm:self-auto"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Generate AI Proposal with ZAI</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            {/* AI Score Explanation */}
            <div className="p-3.5 rounded-xl bg-indigo-50/30 border border-indigo-100 space-y-1.5">
              <div className="font-bold text-indigo-900 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                <span>ZAI Lead Qualification Breakdown: {selectedLead.scoreTier} ({selectedLead.score}/100)</span>
              </div>
              <p className="text-slate-700 leading-relaxed">{selectedLead.scoreExplanation}</p>
            </div>

            {/* Next Steps */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1.5">
              <div className="font-bold text-slate-900 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-slate-600" />
                <span>Recommended Next Action</span>
              </div>
              <p className="text-slate-700 leading-relaxed">{selectedLead.nextAction}</p>
              <div className="text-[10px] text-slate-400 mt-1">
                Last contact recorded: {selectedLead.lastContactDate}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
