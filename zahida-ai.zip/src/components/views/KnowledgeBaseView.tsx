import React, { useState } from 'react';
import {
  BookOpen,
  Search,
  Plus,
  FileText,
  Sparkles,
  ExternalLink,
  Tag,
  CheckCircle2,
} from 'lucide-react';
import { useAgency } from '../../context/AgencyContext';
import { KnowledgeDocument } from '../../types';

export const KnowledgeBaseView: React.FC = () => {
  const { knowledgeDocs, addKnowledgeDoc, sendAiMessage, setIsAskZaiOpen } = useAgency();

  const [search, setSearch] = useState('');
  const [selectedDoc, setSelectedDoc] = useState<KnowledgeDocument | null>(knowledgeDocs[0] || null);
  const [testQuery, setTestQuery] = useState('');

  const filteredDocs = knowledgeDocs.filter(
    (d) =>
      d.title.toLowerCase().includes(search.toLowerCase()) ||
      d.category.toLowerCase().includes(search.toLowerCase()) ||
      d.summary.toLowerCase().includes(search.toLowerCase())
  );

  const handleTestRetrieval = (e: React.FormEvent) => {
    e.preventDefault();
    if (!testQuery.trim()) return;

    sendAiMessage(`Based strictly on our agency SOPs and knowledge base documents: ${testQuery}`);
    setIsAskZaiOpen(true);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* 1. Header */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="font-display font-bold text-slate-950 text-lg tracking-tight">
              Company Knowledge Base & Agency SOPs
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 font-semibold">
              RAG VECTOR STORE
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Internal playbooks, pricing frameworks, creative testing procedures, and client communication standards
          </p>
        </div>

        <button
          onClick={() => {
            const title = prompt('Enter document title:');
            if (title) {
              addKnowledgeDoc({
                title,
                category: 'SOP',
                summary: 'Custom agency standard operating procedure.',
                fileType: 'MARKDOWN',
                contentSnippet: 'Standard guidelines established by Zahida Digital Marketing.',
              });
            }
          }}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold transition-colors shadow-xs self-start sm:self-auto"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Upload Document</span>
        </button>
      </div>

      {/* 2. Semantic Search & Retrieval Q&A Test Bar */}
      <div className="bg-indigo-50/30 border border-indigo-100 rounded-2xl p-5 shadow-xs space-y-3">
        <div className="flex items-center gap-2 text-xs font-bold text-indigo-950">
          <Sparkles className="w-4 h-4 text-indigo-600" />
          <span>Ask ZAI From Company Knowledge (Grounded In Real Documents)</span>
        </div>
        <p className="text-xs text-slate-600">
          ZAI answers questions directly using your verified documents without hallucinating information.
        </p>

        <form onSubmit={handleTestRetrieval} className="flex gap-2">
          <input
            type="text"
            placeholder="e.g. 'What is our standard social media package pricing?' or 'What is our ad fatigue protocol?'"
            value={testQuery}
            onChange={(e) => setTestQuery(e.target.value)}
            className="flex-1 text-xs border border-indigo-200 rounded-xl px-3.5 py-2.5 bg-white outline-hidden focus:border-indigo-500"
          />
          <button
            type="submit"
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-xl transition-colors shadow-xs shrink-0"
          >
            Query Knowledge Base
          </button>
        </form>
      </div>

      {/* 3. Document Directory & Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left List (5 cols) */}
        <div className="lg:col-span-5 space-y-3">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search documents by title or topic..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full text-xs pl-8 pr-3 py-2 border border-slate-200 rounded-xl outline-hidden focus:border-indigo-500 bg-white"
            />
          </div>

          <div className="space-y-2">
            {filteredDocs.map((doc) => {
              const isSelected = selectedDoc?.id === doc.id;

              return (
                <div
                  key={doc.id}
                  onClick={() => setSelectedDoc(doc)}
                  className={`p-4 rounded-xl border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-indigo-50/50 border-indigo-500 shadow-xs ring-1 ring-indigo-500/20'
                      : 'bg-white border-slate-200/90 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between text-[10px] text-slate-400 mb-1">
                    <span className="font-semibold text-indigo-700 bg-indigo-50 px-1.5 py-0.5 rounded">
                      {doc.category}
                    </span>
                    <span className="font-mono">{doc.fileType}</span>
                  </div>

                  <h3 className="font-display font-semibold text-slate-900 text-xs">{doc.title}</h3>
                  <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">{doc.summary}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Reader (7 cols) */}
        {selectedDoc && (
          <div className="lg:col-span-7 bg-white border border-slate-200/90 rounded-2xl p-6 shadow-xs space-y-4">
            <div className="pb-3 border-b border-slate-100 flex items-start justify-between">
              <div>
                <span className="text-[10px] font-mono text-indigo-600 font-bold uppercase">
                  {selectedDoc.category}
                </span>
                <h3 className="font-display font-bold text-slate-900 text-base mt-0.5">
                  {selectedDoc.title}
                </h3>
                <div className="text-xs text-slate-400 mt-0.5">Last updated: {selectedDoc.lastUpdated}</div>
              </div>

              <span className="text-[10px] font-mono px-2 py-1 bg-slate-100 rounded text-slate-700">
                {selectedDoc.fileType} DOCUMENT
              </span>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 text-xs text-slate-800 font-mono whitespace-pre-wrap leading-relaxed">
              {selectedDoc.contentSnippet}
            </div>

            <div className="pt-2 flex items-center justify-between text-xs text-slate-500">
              <span>Grounding status: Active in ZAI retrieval index</span>
              <button
                onClick={() => {
                  sendAiMessage(`Summarize key operational takeaways from "${selectedDoc.title}".`);
                  setIsAskZaiOpen(true);
                }}
                className="text-indigo-600 font-semibold hover:underline"
              >
                Summarize with ZAI →
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
