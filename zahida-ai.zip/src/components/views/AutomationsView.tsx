import React, { useState } from 'react';
import {
  Workflow,
  Plus,
  Play,
  Pause,
  Clock,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Sliders,
} from 'lucide-react';
import { useAgency } from '../../context/AgencyContext';
import { MarketingAutomation } from '../../types';

export const AutomationsView: React.FC = () => {
  const { automations, toggleAutomation, sendAiMessage, setIsAskZaiOpen, approvals } = useAgency();

  const [executingId, setExecutingId] = useState<string | null>(null);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  const handleRunNow = (automation: MarketingAutomation) => {
    setExecutingId(automation.id);
    setTimeout(() => {
      setExecutingId(null);
      setSuccessToast(`Automation "${automation.name}" executed successfully. Action items synced.`);
      setTimeout(() => setSuccessToast(null), 3000);
    }, 1200);
  };

  const activeCount = automations.filter((a) => a.status === 'Active').length;

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* 1. Header */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="font-display font-bold text-slate-950 text-lg tracking-tight">
              Agency Automation Center
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 font-semibold">
              {activeCount} ACTIVE WORKFLOWS
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Configurable autonomous marketing jobs, scheduled briefing synthesizers, and approval SLA reminders
          </p>
        </div>

        {successToast && (
          <div className="flex items-center gap-1.5 text-xs text-emerald-800 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            <span>{successToast}</span>
          </div>
        )}
      </div>

      {/* 2. Safety Governance Notice */}
      <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-slate-600">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>
            <strong>Human-in-the-Loop Safeguard:</strong> Autonomous workflows generate internal tasks and staging drafts automatically. External publishing or ad budget scaling always halts at the <strong>Approval Center</strong>.
          </span>
        </div>
        <span className="font-mono text-[11px] text-slate-400 shrink-0">Zero Unattended Actions</span>
      </div>

      {/* 3. Automation Workflows List */}
      <div className="space-y-3">
        {automations.map((auto) => {
          const isActive = auto.status === 'Active';
          const isRunning = executingId === auto.id;

          return (
            <div
              key={auto.id}
              className={`p-5 rounded-2xl border transition-all ${
                isActive
                  ? 'bg-white border-slate-200/90 shadow-xs'
                  : 'bg-slate-50/60 border-slate-200/60 opacity-75'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                        isActive
                          ? 'bg-emerald-50 text-emerald-700'
                          : 'bg-slate-200 text-slate-700'
                      }`}
                    >
                      {auto.status.toUpperCase()}
                    </span>
                    <span className="text-xs text-slate-400">·</span>
                    <span className="text-xs font-semibold text-slate-700">
                      Trigger: {auto.trigger}
                    </span>
                  </div>

                  <h3 className="font-display font-bold text-slate-900 text-sm">
                    {auto.name}
                  </h3>

                  <p className="text-xs text-slate-600 leading-relaxed max-w-3xl">
                    {auto.action}
                  </p>
                </div>

                {/* Status Toggle & Manual Trigger */}
                <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
                  <button
                    onClick={() => handleRunNow(auto)}
                    disabled={isRunning || !isActive}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold transition-colors disabled:opacity-40"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isRunning ? 'animate-spin' : ''}`} />
                    <span>{isRunning ? 'Executing...' : 'Run Now'}</span>
                  </button>

                  <button
                    onClick={() => toggleAutomation(auto.id)}
                    className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                      isActive
                        ? 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                        : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                    }`}
                  >
                    {isActive ? (
                      <>
                        <Pause className="w-3.5 h-3.5" />
                        <span>Pause</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-3.5 h-3.5" />
                        <span>Activate</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Execution telemetry footer */}
              <div className="mt-3 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between text-[11px] text-slate-400 gap-2">
                <div className="flex items-center gap-3">
                  <span>Last run: <strong className="text-slate-600">{auto.lastRun}</strong></span>
                  <span>·</span>
                  <span>Executions: <strong className="text-slate-600 font-mono">{auto.executionCount}</strong></span>
                </div>

                <div className="flex items-center gap-1 text-emerald-700 font-medium">
                  <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                  <span>SLA Verified</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
