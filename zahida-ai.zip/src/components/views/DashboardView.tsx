import React, { useState } from 'react';
import {
  Users,
  DollarSign,
  Megaphone,
  TrendingUp,
  Sparkles,
  ArrowUpRight,
  ArrowRight,
  ShieldCheck,
  AlertCircle,
  Eye,
  CheckCircle2,
  Calendar,
  Compass,
} from 'lucide-react';
import { useAgency } from '../../context/AgencyContext';
import { DailyBriefingBanner } from '../layout/DailyBriefingBanner';

export const DashboardView: React.FC = () => {
  const {
    clients,
    campaigns,
    leads,
    strategies,
    approvals,
    tasks,
    setCurrentView,
    setSelectedClientId,
    setSelectedClientDetail,
    setIsAskZaiOpen,
    isDemoMode,
    setIsDemoMode,
  } = useAgency();

  const [chartMetric, setChartMetric] = useState<'revenue' | 'spend' | 'roas'>('revenue');
  const [clientSearch, setClientSearch] = useState('');

  // Calculate totals
  const totalClients = clients.length;
  const totalMRR = clients.reduce((acc, c) => acc + c.monthlyRetainer, 0);
  const totalAdSpend = campaigns.reduce((acc, c) => acc + c.monthlyBudget, 0);
  const activeCampaigns = campaigns.filter((c) => c.status === 'Active').length;
  const pendingApprovalsCount = approvals.filter((a) => a.status === 'PENDING').length;
  const pendingTasksCount = tasks.filter((t) => t.status !== 'Completed').length;
  const hotLeadsCount = leads.filter((l) => l.scoreTier === 'HOT').length;

  // Blended ROAS
  const totalRevGenerated = campaigns.reduce((acc, c) => acc + c.revenueGenerated, 0);
  const totalSpentSoFar = campaigns.reduce((acc, c) => acc + c.spentCurrentMonth, 0);
  const blendedRoas = totalSpentSoFar > 0 ? (totalRevGenerated / totalSpentSoFar).toFixed(2) : '4.15';

  const filteredClients = clients.filter((c) =>
    c.name.toLowerCase().includes(clientSearch.toLowerCase()) ||
    c.industry.toLowerCase().includes(clientSearch.toLowerCase())
  );

  // Chart data simulation points (Jan to Oct 2026)
  const chartData = [
    { month: 'Jan', revenue: 58000, spend: 82000, roas: 3.8 },
    { month: 'Feb', revenue: 62000, spend: 89000, roas: 3.9 },
    { month: 'Mar', revenue: 64500, spend: 94000, roas: 4.0 },
    { month: 'Apr', revenue: 69000, spend: 102000, roas: 4.1 },
    { month: 'May', revenue: 71000, spend: 108000, roas: 4.0 },
    { month: 'Jun', revenue: 74500, spend: 114000, roas: 4.2 },
    { month: 'Jul', revenue: 77000, spend: 119000, roas: 4.3 },
    { month: 'Aug', revenue: 80500, spend: 125000, roas: 4.2 },
    { month: 'Sep', revenue: 82800, spend: 131000, roas: 4.4 },
    { month: 'Oct', revenue: 84700, spend: 136000, roas: 4.6 },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* 1. Daily Executive Briefing */}
      <DailyBriefingBanner />

      {/* Demo Mode vs Live Agency Notice */}
      {isDemoMode && (
        <div className="p-3 rounded-xl bg-amber-50/80 border border-amber-200/90 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-amber-900">
          <div className="flex items-center gap-2">
            <span className="font-mono text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-200/80 text-amber-950 uppercase">
              Demo Data Mode
            </span>
            <span>
              Sample client accounts and campaigns are shown for simulation. Metrics will reflect actual account values once live data is connected.
            </span>
          </div>
          <button
            onClick={() => setIsDemoMode(false)}
            className="text-xs font-semibold text-amber-950 underline hover:text-amber-800 self-start sm:self-auto shrink-0"
          >
            Switch to Live Clean Slate →
          </button>
        </div>
      )}

      {/* 2. Top Executive KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Clients */}
        <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-medium">Active Agency Clients</span>
            <div className="p-1.5 rounded-lg bg-slate-100 text-slate-600">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-display tracking-tight text-slate-900 tabular-nums">
              {totalClients}
            </span>
            <span className="text-xs font-semibold text-emerald-600 flex items-center">
              +2 this month
            </span>
          </div>
          <div className="text-[11px] text-slate-500 mt-2 flex items-center gap-2">
            <span>Enterprise: 3</span>
            <span>·</span>
            <span>Growth: 3</span>
          </div>
        </div>

        {/* Monthly Retainer Revenue (MRR) */}
        <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-medium">Agency Retainer MRR</span>
            <div className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-display tracking-tight text-slate-900 tabular-nums">
              ${totalMRR.toLocaleString()}
            </span>
            <span className="text-xs font-semibold text-emerald-600 flex items-center">
              +14.2% MoM
            </span>
          </div>
          <div className="text-[11px] text-slate-500 mt-2">
            Avg client value: ${(totalMRR / totalClients).toFixed(0)}/mo
          </div>
        </div>

        {/* Managed Monthly Ad Spend */}
        <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-medium">Managed Ad Spend / mo</span>
            <div className="p-1.5 rounded-lg bg-slate-100 text-slate-600">
              <Megaphone className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-display tracking-tight text-slate-900 tabular-nums">
              ${totalAdSpend.toLocaleString()}
            </span>
            <span className="text-xs font-medium text-slate-500">
              Across {activeCampaigns} campaigns
            </span>
          </div>
          <div className="text-[11px] text-slate-500 mt-2">
            Meta, Google, TikTok, LinkedIn
          </div>
        </div>

        {/* Blended Portfolio ROAS */}
        <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-medium">Blended Portfolio ROAS</span>
            <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-display tracking-tight text-slate-900 tabular-nums">
              {blendedRoas}x
            </span>
            <span className="text-xs font-semibold text-emerald-600 flex items-center">
              Target: 3.5x
            </span>
          </div>
          <div className="text-[11px] text-slate-500 mt-2">
            ${totalRevGenerated.toLocaleString()} client revenue generated
          </div>
        </div>
      </div>

      {/* 3. ZAI Insights Section & Ask ZAI Command Bar */}
      <div className="bg-slate-900 text-white rounded-2xl p-5 shadow-md relative overflow-hidden">
        {/* Subtle decorative glow */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-indigo-600 text-white shadow-xs">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-display font-bold text-base text-white tracking-tight">
                  ZAI INSIGHTS
                </h2>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-indigo-300 font-semibold border border-slate-700">
                  REAL-TIME INTELLIGENCE
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Proactive strategic findings curated specifically for Zahida Khan
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsAskZaiOpen(true)}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition-colors shadow-xs self-start md:self-auto"
          >
            <span>Open Ask ZAI Command Center</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Insight Cards Carousel/Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 pt-4">
          <div
            onClick={() => setCurrentView('Campaigns')}
            className="p-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 cursor-pointer transition-all hover:border-slate-600"
          >
            <div className="text-[10px] font-semibold text-amber-400 uppercase tracking-wider mb-1">
              Ad Fatigue Alert
            </div>
            <div className="text-xs font-semibold text-slate-100 mb-1">
              Lumina Skin Co CPA spike (+28%)
            </div>
            <p className="text-[11px] text-slate-400 line-clamp-2">
              Hero serum static creative hit fatigue. 3 UGC cuts queued in Approval Center.
            </p>
          </div>

          <div
            onClick={() => setCurrentView('Campaigns')}
            className="p-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 cursor-pointer transition-all hover:border-slate-600"
          >
            <div className="text-[10px] font-semibold text-emerald-400 uppercase tracking-wider mb-1">
              Scale Opportunity
            </div>
            <div className="text-xs font-semibold text-slate-100 mb-1">
              Nordic Roastery 5.2x ROAS
            </div>
            <p className="text-[11px] text-slate-400 line-clamp-2">
              Autumn roast subscription campaign has headroom to increase daily ad spend by 15%.
            </p>
          </div>

          <div
            onClick={() => setCurrentView('Leads')}
            className="p-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 cursor-pointer transition-all hover:border-slate-600"
          >
            <div className="text-[10px] font-semibold text-indigo-300 uppercase tracking-wider mb-1">
              Pipeline Velocity
            </div>
            <div className="text-xs font-semibold text-slate-100 mb-1">
              4 High-Value Leads Ready
            </div>
            <p className="text-[11px] text-slate-400 line-clamp-2">
              $18,500/mo estimated retainer pipeline. Kashif (Zaytoun Oils) awaits 3-month growth proposal.
            </p>
          </div>

          <div
            onClick={() => setCurrentView('Content Studio')}
            className="p-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 cursor-pointer transition-all hover:border-slate-600"
          >
            <div className="text-[10px] font-semibold text-purple-400 uppercase tracking-wider mb-1">
              Content Performance
            </div>
            <div className="text-xs font-semibold text-slate-100 mb-1">
              Top Asset: Apex CFO Carousel
            </div>
            <p className="text-[11px] text-slate-400 line-clamp-2">
              Generated 91 qualified enterprise demo requests with 0% drop-off on first 3 slides.
            </p>
          </div>
        </div>
      </div>

      {/* 4. Interactive Growth Chart & Operations Strip */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Agency Growth Chart */}
        <div className="lg:col-span-2 bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
            <div>
              <h3 className="font-display font-bold text-slate-900 text-sm">
                Agency Retainer & Ad Spend Trajectory
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Monthly revenue velocity for Zahida Digital Marketing (2026)
              </p>
            </div>

            {/* Segmented Chart Metric Filter */}
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs self-start sm:self-auto">
              <button
                onClick={() => setChartMetric('revenue')}
                className={`px-3 py-1 font-medium rounded-md transition-colors ${
                  chartMetric === 'revenue'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Retainer MRR
              </button>
              <button
                onClick={() => setChartMetric('spend')}
                className={`px-3 py-1 font-medium rounded-md transition-colors ${
                  chartMetric === 'spend'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Client Ad Spend
              </button>
              <button
                onClick={() => setChartMetric('roas')}
                className={`px-3 py-1 font-medium rounded-md transition-colors ${
                  chartMetric === 'roas'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Avg ROAS
              </button>
            </div>
          </div>

          {/* SVG Line / Bar Chart Visualization */}
          <div className="h-64 w-full pt-4">
            <div className="h-full flex items-end justify-between gap-2 border-b border-slate-200 pb-2">
              {chartData.map((d, index) => {
                const heightPct =
                  chartMetric === 'revenue'
                    ? (d.revenue / 90000) * 100
                    : chartMetric === 'spend'
                    ? (d.spend / 150000) * 100
                    : (d.roas / 5.5) * 100;

                const displayVal =
                  chartMetric === 'revenue'
                    ? `$${(d.revenue / 1000).toFixed(0)}k`
                    : chartMetric === 'spend'
                    ? `$${(d.spend / 1000).toFixed(0)}k`
                    : `${d.roas}x`;

                return (
                  <div key={d.month} className="flex-1 flex flex-col items-center gap-2 group h-full justify-end">
                    <div className="opacity-0 group-hover:opacity-100 transition-opacity text-[10px] font-mono text-slate-700 bg-slate-100 px-1 py-0.5 rounded">
                      {displayVal}
                    </div>
                    <div
                      style={{ height: `${heightPct}%` }}
                      className={`w-full max-w-[28px] rounded-t-md transition-all duration-300 ${
                        index === chartData.length - 1
                          ? 'bg-indigo-600'
                          : 'bg-slate-200 group-hover:bg-indigo-400'
                      }`}
                    />
                    <span className="text-[11px] font-medium text-slate-500 font-mono">
                      {d.month}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
          <div className="flex items-center justify-between text-xs text-slate-500 pt-3">
            <span>Current Month: October 2026</span>
            <span className="font-mono font-medium text-slate-700">
              {chartMetric === 'revenue' && `$${totalMRR.toLocaleString()} MRR`}
              {chartMetric === 'spend' && `$${totalAdSpend.toLocaleString()} Total Ad Spend`}
              {chartMetric === 'roas' && `${blendedRoas}x Blended ROAS`}
            </span>
          </div>
        </div>

        {/* Right Col: Operations Status & Approvals */}
        <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display font-bold text-slate-900 text-sm">
                Agency Operations Queue
              </h3>
              <button
                onClick={() => setCurrentView('Approvals')}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800"
              >
                View all ({pendingApprovalsCount}) →
              </button>
            </div>

            <div className="space-y-3">
              {/* Approvals waiting */}
              <div
                onClick={() => setCurrentView('Approvals')}
                className="p-3 rounded-xl border border-slate-100 hover:border-slate-200 bg-slate-50/50 hover:bg-slate-50 cursor-pointer transition-colors"
              >
                <div className="flex items-center justify-between text-xs font-semibold text-slate-900 mb-1">
                  <span className="flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-indigo-600" />
                    <span>Pending Executive Approvals</span>
                  </span>
                  <span className="font-mono tabular-nums px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-800 text-[10px]">
                    {pendingApprovalsCount}
                  </span>
                </div>
                <p className="text-[11px] text-slate-500">
                  Yellow & Red tier actions requiring your authorization before external dispatch.
                </p>
              </div>

              {/* Tasks in progress */}
              <div
                onClick={() => setCurrentView('Tasks')}
                className="p-3 rounded-xl border border-slate-100 hover:border-slate-200 bg-slate-50/50 hover:bg-slate-50 cursor-pointer transition-colors"
              >
                <div className="flex items-center justify-between text-xs font-semibold text-slate-900 mb-1">
                  <span className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Active Team Tasks</span>
                  </span>
                  <span className="font-mono tabular-nums px-1.5 py-0.5 rounded bg-slate-200 text-slate-700 text-[10px]">
                    {pendingTasksCount}
                  </span>
                </div>
                <p className="text-[11px] text-slate-500">
                  Media buying, SEO audits, and content creation sprints.
                </p>
              </div>

              {/* Marketing Strategies */}
              <div
                onClick={() => setCurrentView('Strategies')}
                className="p-3 rounded-xl border border-slate-100 hover:border-slate-200 bg-slate-50/50 hover:bg-slate-50 cursor-pointer transition-colors"
              >
                <div className="flex items-center justify-between text-xs font-semibold text-slate-900 mb-1">
                  <span className="flex items-center gap-1.5">
                    <Compass className="w-4 h-4 text-violet-600" />
                    <span>Marketing Growth Strategies</span>
                  </span>
                  <span className="font-mono tabular-nums px-1.5 py-0.5 rounded bg-violet-100 text-violet-800 text-[10px]">
                    {strategies.length}
                  </span>
                </div>
                <p className="text-[11px] text-slate-500">
                  Full-funnel client blueprints, channel allocation, and roadmaps.
                </p>
              </div>

              {/* Hot Leads */}
              <div
                onClick={() => setCurrentView('Leads')}
                className="p-3 rounded-xl border border-slate-100 hover:border-slate-200 bg-slate-50/50 hover:bg-slate-50 cursor-pointer transition-colors"
              >
                <div className="flex items-center justify-between text-xs font-semibold text-slate-900 mb-1">
                  <span className="flex items-center gap-1.5">
                    <AlertCircle className="w-4 h-4 text-amber-600" />
                    <span>Hot Qualified Prospects</span>
                  </span>
                  <span className="font-mono tabular-nums px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 text-[10px]">
                    {hotLeadsCount}
                  </span>
                </div>
                <p className="text-[11px] text-slate-500">
                  Proposal presentations and contract reviews ready this week.
                </p>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 mt-4">
            <div className="text-[11px] text-slate-500 flex items-center justify-between">
              <span>Autonomous Agents Active</span>
              <span className="font-mono text-emerald-600 font-semibold">10 / 10 ONLINE</span>
            </div>
          </div>
        </div>
      </div>

      {/* 5. Client Portfolio Performance Matrix */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div>
            <h3 className="font-display font-bold text-slate-900 text-sm">
              Client Portfolio Health & Retainers
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Live client telemetry, retainer status, and active campaign performance
            </p>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="text"
              placeholder="Search clients..."
              value={clientSearch}
              onChange={(e) => setClientSearch(e.target.value)}
              className="text-xs border border-slate-200 rounded-lg px-2.5 py-1.5 outline-hidden focus:border-indigo-500"
            />
            <button
              onClick={() => setCurrentView('Clients')}
              className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 whitespace-nowrap"
            >
              Full CRM →
            </button>
          </div>
        </div>

        {/* Clients Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-100 text-[11px] text-slate-400 uppercase font-semibold">
                <th className="pb-2.5 pl-2">Client Name</th>
                <th className="pb-2.5">Industry</th>
                <th className="pb-2.5">Retainer</th>
                <th className="pb-2.5">Monthly Ad Spend</th>
                <th className="pb-2.5">Blended ROAS</th>
                <th className="pb-2.5">Health</th>
                <th className="pb-2.5">Status</th>
                <th className="pb-2.5 pr-2 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredClients.map((client) => (
                <tr
                  key={client.id}
                  className="hover:bg-slate-50/80 transition-colors group cursor-pointer"
                  onClick={() => {
                    setSelectedClientId(client.id);
                    setSelectedClientDetail(client);
                    setCurrentView('Clients');
                  }}
                >
                  <td className="py-3 pl-2">
                    <div className="flex items-center gap-2.5">
                      {client.logoUrl ? (
                        <img
                          src={client.logoUrl}
                          alt={client.name}
                          className="w-7 h-7 rounded-lg object-cover ring-1 ring-slate-200 shrink-0"
                          referrerPolicy="no-referrer"
                          onError={(e) => {
                            (e.target as HTMLElement).style.display = 'none';
                          }}
                        />
                      ) : (
                        <div className="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-700 font-bold flex items-center justify-center shrink-0 text-xs">
                          {client.name.slice(0, 2).toUpperCase()}
                        </div>
                      )}
                      <div>
                        <div className="font-semibold text-slate-900 group-hover:text-indigo-600 transition-colors">
                          {client.name}
                        </div>
                        <div className="text-[10px] text-slate-400">{client.contactPerson}</div>
                      </div>
                    </div>
                  </td>

                  <td className="py-3 text-slate-600">{client.industry}</td>

                  <td className="py-3 font-mono font-medium text-slate-900 tabular-nums">
                    ${client.monthlyRetainer.toLocaleString()}/mo
                  </td>

                  <td className="py-3 font-mono text-slate-700 tabular-nums">
                    ${client.monthlyAdSpend.toLocaleString()}/mo
                  </td>

                  <td className="py-3 font-mono font-semibold text-emerald-600 tabular-nums">
                    {client.blendedRoas}x
                  </td>

                  <td className="py-3">
                    <div className="flex items-center gap-1.5">
                      <div className="w-16 bg-slate-100 rounded-full h-1.5 overflow-hidden">
                        <div
                          style={{ width: `${client.healthScore}%` }}
                          className={`h-full rounded-full ${
                            client.healthScore >= 85
                              ? 'bg-emerald-500'
                              : client.healthScore >= 70
                              ? 'bg-amber-500'
                              : 'bg-rose-500'
                          }`}
                        />
                      </div>
                      <span className="font-mono text-[10px] text-slate-600 tabular-nums">
                        {client.healthScore}%
                      </span>
                    </div>
                  </td>

                  <td className="py-3">
                    <span
                      className={`text-[11px] font-medium ${
                        client.status === 'Active'
                          ? 'text-emerald-700'
                          : client.status === 'At Risk'
                          ? 'text-rose-700'
                          : 'text-slate-600'
                      }`}
                    >
                      {client.status}
                    </span>
                  </td>

                  <td className="py-3 pr-2 text-right">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedClientId(client.id);
                        setSelectedClientDetail(client);
                        setCurrentView('Clients');
                      }}
                      className="p-1 text-slate-400 hover:text-indigo-600 rounded-md hover:bg-slate-100"
                      title="Inspect Client Workspace"
                    >
                      <Eye className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
