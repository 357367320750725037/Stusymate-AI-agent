import React, { useState } from 'react';
import { AgencyProvider, useAgency } from './context/AgencyContext';
import { Sidebar } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { CommandPalette } from './components/common/CommandPalette';
import { AskZaiDrawer } from './components/common/AskZaiDrawer';
import { QuickActionModal } from './components/modals/QuickActionModal';

// Views
import { DashboardView } from './components/views/DashboardView';
import { AiCommandCenterView } from './components/views/AiCommandCenterView';
import { StrategiesView } from './components/views/StrategiesView';
import { ClientsView } from './components/views/ClientsView';
import { LeadsView } from './components/views/LeadsView';
import { CampaignsView } from './components/views/CampaignsView';
import { ContentStudioView } from './components/views/ContentStudioView';
import { ContentCalendarView } from './components/views/ContentCalendarView';
import { SeoResearchView } from './components/views/SeoResearchView';
import { AnalyticsView } from './components/views/AnalyticsView';
import { ReportsView } from './components/views/ReportsView';
import { TasksView } from './components/views/TasksView';
import { ApprovalsView } from './components/views/ApprovalsView';
import { AutomationsView } from './components/views/AutomationsView';
import { KnowledgeBaseView } from './components/views/KnowledgeBaseView';
import { TeamView } from './components/views/TeamView';
import { SettingsView } from './components/views/SettingsView';

const MainContent: React.FC = () => {
  const { currentView } = useAgency();
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  const renderActiveView = () => {
    switch (currentView) {
      case 'Dashboard':
        return <DashboardView />;
      case 'AI Command Center':
        return <AiCommandCenterView />;
      case 'Strategies':
        return <StrategiesView />;
      case 'Clients':
        return <ClientsView />;
      case 'Leads':
        return <LeadsView />;
      case 'Campaigns':
        return <CampaignsView />;
      case 'Content Studio':
        return <ContentStudioView />;
      case 'Content Calendar':
        return <ContentCalendarView />;
      case 'SEO & Research':
        return <SeoResearchView />;
      case 'Analytics':
        return <AnalyticsView />;
      case 'Reports':
        return <ReportsView />;
      case 'Tasks':
        return <TasksView />;
      case 'Approvals':
        return <ApprovalsView />;
      case 'Automations':
        return <AutomationsView />;
      case 'Knowledge Base':
        return <KnowledgeBaseView />;
      case 'Team':
        return <TeamView />;
      case 'Settings':
        return <SettingsView />;
      default:
        return <DashboardView />;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-[#F8F9FA] text-[#0F172A]">
      {/* Persistent Left Sidebar (Desktop) & Responsive Drawer (Mobile) */}
      <Sidebar
        isMobileOpen={isMobileOpen}
        onCloseMobile={() => setIsMobileOpen(false)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Header */}
        <Header onOpenMobile={() => setIsMobileOpen(true)} />

        {/* Scrollable Viewport */}
        <main className="flex-1 overflow-y-auto px-4 sm:px-6 lg:px-8 py-6">
          {renderActiveView()}
        </main>
      </div>

      {/* Global Interactive Overlays */}
      <CommandPalette />
      <AskZaiDrawer />
      <QuickActionModal />
    </div>
  );
};

export default function App() {
  return (
    <AgencyProvider>
      <MainContent />
    </AgencyProvider>
  );
}
