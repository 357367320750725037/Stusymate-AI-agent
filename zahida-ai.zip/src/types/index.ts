export type NavView =
  | 'Dashboard'
  | 'AI Command Center'
  | 'Strategies'
  | 'Clients'
  | 'Leads'
  | 'Campaigns'
  | 'Content Studio'
  | 'Content Calendar'
  | 'SEO & Research'
  | 'Analytics'
  | 'Reports'
  | 'Tasks'
  | 'Approvals'
  | 'Automations'
  | 'Knowledge Base'
  | 'Team'
  | 'Settings';

export type ContentLanguage = 'English' | 'Urdu' | 'Roman Urdu';

export type ContentFormatType =
  | 'Instagram Caption'
  | 'Facebook Post'
  | 'LinkedIn Thought Leadership'
  | 'Reel / Short Script'
  | 'TikTok Script'
  | 'YouTube Outline'
  | 'Blog Article'
  | 'Landing Page Copy'
  | 'Email Campaign'
  | 'Ad Copy Variations'
  | 'Product Description'
  | 'Call to Action'
  | 'Content Repurposing'
  | 'Promotional Image Prompt';

export interface CompetitorResearchReport {
  id: string;
  competitorName: string;
  websiteUrl: string;
  analysisDate: string;
  positioningSummary: string;
  coreOffers: string[];
  contentGaps: string[];
  swotAnalysis: {
    strengths: string[];
    weaknesses: string[];
    opportunities: string[];
    threats: string[];
  };
  recommendedDifferentiators: string[];
  sourcesDisclosed: string[];
}

export interface MarketingAutomation {
  id: string;
  name: string;
  trigger: string;
  action: string;
  status: 'Active' | 'Paused';
  lastRun: string;
  executionCount: number;
  errorLog?: string;
}

export type ApprovalTier = 'GREEN' | 'YELLOW' | 'RED';
export type ApprovalStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'EXECUTED';

export interface ApprovalItem {
  id: string;
  title: string;
  description: string;
  tier: ApprovalTier;
  category: 'CAMPAIGN' | 'CONTENT' | 'BUDGET' | 'CLIENT_COMMS' | 'PROPOSAL' | 'SYSTEM';
  clientName: string;
  clientId: string;
  createdAt: string;
  requestedByAgent: string;
  status: ApprovalStatus;
  proposedAction: {
    actionType: string;
    details: string;
    impactSummary: string;
    payload?: any;
  };
  auditLog?: {
    reviewedAt?: string;
    reviewedBy?: string;
    decisionNote?: string;
  };
}

export interface ClientMemory {
  industry: string;
  targetAudience: string;
  location: string;
  primaryGoal: string;
  mainPlatform: string;
  secondaryPlatform: string;
  brandTone: string;
  brandColors: string[];
  monthlyAdBudget: number;
  currency: string;
  keyDifferentiators: string[];
  competitors: string[];
  prohibitedWords: string[];
  notes: string;
}

export interface Client {
  id: string;
  name: string;
  logoUrl?: string;
  industry: string;
  contactPerson: string;
  email: string;
  phone: string;
  website: string;
  monthlyRetainer: number;
  monthlyAdSpend: number;
  tier: 'Enterprise' | 'Growth' | 'Starter';
  healthScore: number; // 0-100
  status: 'Active' | 'Onboarding' | 'Paused' | 'At Risk';
  assignedLead: string;
  activeCampaignsCount: number;
  blendedRoas: number;
  memory: ClientMemory;
  tags: string[];
  joinedDate: string;
}

export interface Lead {
  id: string;
  name: string;
  company: string;
  email: string;
  phone: string;
  source: 'Referral' | 'Inbound Organic' | 'LinkedIn' | 'Meta Ad' | 'Event';
  serviceInterest: string;
  budgetEst: number;
  score: number; // 0-100
  scoreTier: 'HOT' | 'WARM' | 'COLD';
  scoreExplanation: string;
  status: 'New' | 'Contacted' | 'Qualified' | 'Proposal' | 'Negotiation' | 'Won' | 'Lost';
  lastContactDate: string;
  nextAction: string;
  notes: string;
}

export interface Campaign {
  id: string;
  name: string;
  clientId: string;
  clientName: string;
  platform: 'Meta Ads' | 'Google Ads' | 'TikTok Ads' | 'Email' | 'Organic Search';
  objective: 'Conversions' | 'Lead Generation' | 'ROAS Scaling' | 'Brand Awareness' | 'Traffic';
  status: 'Active' | 'Paused' | 'In Review' | 'Scheduled' | 'Draft';
  monthlyBudget: number;
  spentCurrentMonth: number;
  impressions: number;
  clicks: number;
  ctr: number;
  cpc: number;
  cpa: number;
  conversions: number;
  revenueGenerated: number;
  roas: number;
  health: 'Optimal' | 'Caution' | 'Action Required';
  aiObservation?: {
    finding: string;
    recommendation: string;
    actionablePlan: string;
  };
}

export type ContentStatus = 'Idea' | 'Draft' | 'Review' | 'Approved' | 'Scheduled' | 'Published';

export interface ContentItem {
  id: string;
  clientId: string;
  clientName: string;
  platform: 'Instagram' | 'LinkedIn' | 'Facebook' | 'TikTok' | 'Blog' | 'Email' | 'WhatsApp';
  contentType: 'Post' | 'Reel' | 'Carousel' | 'Article' | 'Ad Copy' | 'Story' | 'Broadcast';
  title: string;
  hook: string;
  caption: string;
  body: string;
  cta: string;
  hashtags: string[];
  creativeBrief: string;
  scheduledDate: string;
  scheduledTime: string;
  status: ContentStatus;
  approvalStatus: 'Not Requested' | 'Pending Approval' | 'Approved' | 'Changes Requested';
  assignedTo: string;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  priority: 'Urgent' | 'High' | 'Medium' | 'Low';
  status: 'To Do' | 'In Progress' | 'Review' | 'Completed';
  assignee: string;
  deadline: string;
  clientId?: string;
  clientName?: string;
  sourceStrategy?: string;
}

export interface TeamMember {
  id: string;
  name: string;
  role: 'Owner' | 'Admin' | 'Manager' | 'Senior Media Buyer' | 'Creative Strategist' | 'SEO Lead' | 'Content Specialist';
  email: string;
  avatarUrl?: string;
  workloadPercentage: number;
  activeAccounts: string[];
  tasksAssigned: number;
}

export interface KnowledgeDocument {
  id: string;
  title: string;
  category: 'SOP' | 'Brand Voice' | 'Pricing Framework' | 'Media Playbook' | 'Case Study' | 'Template';
  summary: string;
  lastUpdated: string;
  fileType: 'PDF' | 'DOCX' | 'MARKDOWN';
  contentSnippet: string;
}

export interface SeoAuditReport {
  targetUrl: string;
  overallScore: number;
  crawlDate: string;
  criticalProblems: string[];
  highPriorityImprovements: string[];
  mediumPriorityImprovements: string[];
  quickWins: string[];
  topKeywordOpportunities: Array<{ keyword: string; volume: string; difficulty: string; position: number }>;
}

export interface AgentLog {
  id: string;
  timestamp: string;
  agent: string;
  action: string;
  details: string;
  requiresHumanReview: boolean;
}

export interface DailyBriefing {
  date: string;
  highestPriorityTask: string;
  importantClientIssue: string;
  campaignAlert: string;
  hotLeadSummary: string;
  pendingApprovalsCount: number;
  yesterdaysWins: string[];
  yesterdaysProblems: string[];
  todaysOpportunities: string[];
}

export interface StrategicPillar {
  title: string;
  description: string;
  tactics: string[];
}

export interface StrategyBudgetAllocation {
  channel: string;
  percentage: number;
  amount: number;
}

export interface StrategyKpi {
  metric: string;
  target: string;
  current: string;
}

export interface StrategyRoadmapPhase {
  phase: string;
  duration: string;
  tasks: string[];
  status: 'Done' | 'In Progress' | 'Upcoming';
}

export interface MarketingStrategy {
  id: string;
  title: string;
  clientId: string;
  clientName: string;
  category: 'Full-Funnel' | 'Paid Media' | 'Organic & SEO' | 'Conversion Optimization' | 'Retention & Lifecycle' | 'Brand Authority';
  stage: 'Planning' | 'Active Execution' | 'Optimizing' | 'Completed';
  targetAudience: string;
  primaryObjective: string;
  expectedRoas: string;
  budgetAllocation: StrategyBudgetAllocation[];
  strategicPillars: StrategicPillar[];
  channelMix: string[];
  kpis: StrategyKpi[];
  actionRoadmap: StrategyRoadmapPhase[];
  aiStrategicRationale: string;
  createdAt: string;
  lastUpdated: string;
}

export interface ReportItem {
  id: string;
  clientId: string;
  clientName: string;
  title: string;
  period: string;
  category: 'Executive Performance' | 'Paid Media & Attribution' | 'CRO & Funnel Audit' | 'SEO Authority' | 'Quarterly QBR';
  dateGenerated: string;
  preparedBy: string;
  executiveSummary: string;
  keyHighlights: string[];
  criticalIssues: string[];
  metrics: {
    spend: number;
    revenue: number;
    roas: number;
    conversions: number;
    cpa: number;
    ctr: number;
  };
  channelBreakdown: Array<{
    channel: string;
    spend: number;
    revenue: number;
    roas: number;
    status: string;
  }>;
  strategicNextSteps: string[];
}

